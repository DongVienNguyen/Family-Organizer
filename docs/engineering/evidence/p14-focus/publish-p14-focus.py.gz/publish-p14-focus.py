from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
root=Path('/workspace/Family-Organizer');ev=Path('/workspace/family-evidence');out=root/'docs/engineering/evidence/p14-focus';out.mkdir(exist_ok=True)
sha='b3f6a6d64aee65afa92a9f285b4ce85e001db19f';base='b69939d1091954f57221cd2a5a9b836808e3fa5f';h=lambda value:hashlib.sha256(value).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==sha
full=json.loads((ev/'p14-focus-full.json').read_text());assert full['success'] and full['numTotalTests']==full['numPassedTests']==8793 and len(full['testResults'])==556 and full['numFailedTests']==full['numPendingTests']==full.get('numTodoTests',0)==0
cases=ET.parse(ev/'p14-focus-full.junit.xml').getroot().findall('.//testcase');assert len(cases)==8793 and not any(c.find(tag)is not None for c in cases for tag in ['failure','error','skipped'])
def identities(report):
 result=collections.Counter()
 for file in report['testResults']:
  name=str(Path(file['name']).relative_to(root))
  for case in file['assertionResults']:
   assert case['status']=='passed';title=case['fullName']
   if name=='server/recoveryRetention.test.ts':title=re.sub(r'/tmp/fo test synthetic [A-Za-z0-9]+(?=/|$)','/tmp/fo test synthetic <fixture>',title)
   result[(name,title)]+=1
 return result
before=identities(json.loads((ev/'p13-data-full.json').read_text()));after=identities(full);assert sum(before.values())==8749 and not before-after,before-after
assert sum((after-before).values())==44
for stem in ['p14-focus-full','p14-focus-build-qualified','p14-focus-lint-qualified','p14-focus-recovery-v3']+[f'p14-qualified-browser-{name}'for name in ['focus','data','attachments','content','templates','notifications','collaboration','calendar']]:assert (ev/(stem+'.exit')).read_text().strip()=='0',stem
browser={}
for feature,count,version in [('focus',4,19),('data',4,18),('attachments',3,17),('content',4,16),('templates',3,15),('notifications',4,14),('collaboration',3,13),('calendar',4,13)]:
 folder=root/'reports'/feature/'chromium';report=json.loads((folder/'browser.json').read_text());fixture=json.loads((folder/'fixture.json').read_text());assert report['stats']['expected']==count and report['stats']['unexpected']==report['stats']['flaky']==report['stats']['skipped']==0
 assert fixture['commitSha']==sha and fixture['seed']['productivityVersion']==version and fixture['nodeVersion']=='v24.21.0' and fixture['platform']=='linux' and all(fixture[k]for k in ['synthetic','databaseClosed','fixtureRemoved','legacyPreserved']) and fixture['integrity']=='ok' and fixture['error']is None and not fixture['networkAttempts'] and fixture['serverExitCode']==fixture['browserExitCode']==0
 for key,name in [('server','dist/server.cjs'),('index','dist/index.html')]:assert fixture['build'][key]==h((root/name).read_bytes())
 def check(suites):
  for suite in suites:
   for spec in suite.get('specs',[]):
    for t in spec['tests']:assert t['status']=='expected' and len(t['results'])==1 and t['results'][0]['status']=='passed'
   check(suite.get('suites',[]))
 check(report['suites']);testcases=ET.parse(folder/'browser.junit.xml').getroot().findall('.//testcase');assert len(testcases)==count and not any(c.find(tag)is not None for c in testcases for tag in ['failure','error','skipped'])
 browser[feature]={'passed':count,'firstAttemptsOnly':True,'fixture':fixture}
source={}
for name in subprocess.check_output(['git','diff','--name-only',base,sha],cwd=root,text=True).splitlines():
 data=subprocess.check_output(['git','show',sha+':'+name],cwd=root);assert (root/name).read_bytes()==data,name;source[name]=h(data)
for name in ['schema.ts','migrate.ts','tagSchema.ts','pinSchema.ts','viewSchema.ts','matrixSchema.ts','boardSchema.ts','seriesSchema.ts','occurrenceSchema.ts','occurrenceSkipSchema.ts','legacyCutoverSchema.ts','notificationSchema.ts','templateSchema.ts','contentSchema.ts','taskAttachmentSchema.ts','importSchema.ts']:
 assert subprocess.check_output(['git','show',base+':server/productivity/'+name],cwd=root)==subprocess.check_output(['git','show',sha+':server/productivity/'+name],cwd=root),name
for ref in [base,sha]:
 text=subprocess.check_output(['git','show',ref+':server/productivity/structureSchema.ts'],cwd=root,text=True);sql=re.search(r'export const structureSchemaSql=`(.*?)`;',text,re.S).group(1)
 if ref==base:frozenSql=sql
 else:assert sql==frozenSql
for name in ['package.json','package-lock.json']:
 assert subprocess.check_output(['git','show',base+':'+name],cwd=root)==(root/name).read_bytes()
assert h((root/'package-lock.json').read_bytes())=='17e305b217c2dbd6543d66e2e600c20251425c5b4d0eb66fa903cbd13ecc6ec7'
retained={}
def retain(file,name):
 data=file.read_bytes();target=out/(name+'.gz');target.write_bytes(gzip.compress(data,mtime=0));retained[name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes()),'uncompressedSha256':h(data)}
for file in sorted(ev.glob('p14-*')):
 if file.is_file()and file.suffix in ['.json','.xml','.log','.exit','.txt']:retain(file,file.name)
for feature in browser:
 for name in ['browser.json','browser.junit.xml','fixture.json','runtime.json','run.log','server.log']:retain(root/'reports'/feature/'chromium'/name,feature+'-final-'+name)
for file in (ev/'p14-focus-browser-first-artifacts').rglob('*'):
 if file.is_file()and file.suffix in ['.json','.xml','.log','.md','.zip','.png']:retain(file,'browser-first-'+str(file.relative_to(ev/'p14-focus-browser-first-artifacts')).replace('/','__'))
for file in (root/'reports/focus/chromium').glob('*390-*.png'):
 target=out/file.name;target.write_bytes(file.read_bytes());retained[file.name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes()),'visuallyInspected':True,'scope':'Actual390px viewport at Focus form or audited correction; light and dark. First element captures were clipped by the app scroll container and remain only historical raw artifacts.'}
retain(ev/'publish-p14-focus.py','publish-p14-focus.py')
proof={'taskId':'P14 private Focus functional slice','sourceCommit':sha,'backendSource':subprocess.check_output(['git','rev-parse','a9dad4f'],cwd=root,text=True).strip(),'uiSource':'71de6a76388ccf4f9b4b13996554236603c4263f','fullRegressionSource':sha,'prUrl':None,'ciRunUrl':None,'qualification':'Cloud functional development only; final composed Windows pending','fullRegression':{'passed':8793,'files':556,'junitCases':8793,'failed':0,'skipped':0,'todo':0,'parentPassed':8749,'added':44,'removed':0},'lintExitCode':0,'buildExitCode':0,'buildSource':sha,'browser':browser,'sourceFiles':source,'schema':{'explicitPilotVersion':19,'defaultVersion':6,'frozen1to18Preserved':True,'packageCapsChanged':False},'review':{'independent':False,'scope':'Author review of owner/session/current-target ACL before cached receipts, segment/cap/state invariants, real shared durable job execution, pause/resume and replacement recovery, P12 mute/quiet/digest reuse, private notice claims, stable import undo fingerprints with later references, live DTO SDK validation and pending-command/logout/revocation fences. No independent-review claim.'},'developmentFailures':['Cold native/API/SDK/workspace checkpoints failed because modules or endpoints did not yet exist; some suites could not collect tests. Raw native exit codes and reporter status are retained, not called functional passes.','Adding empty Focus FK tables initially changed old18 import fingerprints and incorrectly kept an unchanged Task. Freeze the original18 fingerprint shape and independently protect nonempty later Task references. Both native old/new cases pass.','An early deadline read the clock twice across a millisecond boundary and produced negative requeue delay. One captured clock now controls each deadline/delivery decision.','Replacement recovery initially wrote partial audit objects that the actual SDK rejected. A shared full audit projection now covers ordinary and restore events. Native snapshot plus actual SDK regression passes.','A late completion followed by a backward clock attempted a digest with a future timestamp/local-date mismatch. Delivery defers until its persisted clock fence, then uses the current local day.','Equal-timestamp manual/correction audit entries sorted by random UUID, producing a real HTTP failure. Audit revision now determines semantic order. No assertions were removed.','TypeScript checkpoints for normalized unknown payloads, unsupported FancySelect disabled props, and a settings JSX/SQL quoting edit failed and were corrected; raw exit1/2 artifacts retained.','First four browser journeys passed at71de6a7. Final4plus25parent journeys passed first attempts at the qualified source. Historical element captures were clipped; final screenshots capture actual390px viewports. No retry/timeout/skip relaxation.'],'scope':['One running or paused owner session, default25/5/15 and long break after4 fully completed Pomodoros, explicit next phase, stopwatch cap24h. Integer-millisecond pause segments, live server clocks, manual0..86400 and reasoned duration overrides preserve original segments.','Focus only writes owner Focus records, never completes Tasks, awards/reverses points or posts Wallet. Current Task/root reference and immutable quadrant-at-start support later insights; revoked target labels are hidden while the owner can stop their own timer. Habit link is intentionally refused until real P15 authority/storage is implemented.','One shared AppJobs command per deadline/notice, no per-second persistent timer writes. Actual native HTTP job execution and registry pause/resume are tested. Browser reload/visibility wake is exercised; full process restart and physical OS suspend are not claimed by those cases.','P12 mute/quiet/daily preferences govern generic owner-only inbox notices. The existing I01/outbox adapter deduplicates per-session or owner/local-day digest without exposing Task titles or calling live providers.','Replacement snapshot pauses at validated capture time, credits only pre-capture elapsed and consumes historic pending notices, without auto-completion/counter/notification replay. Ordinary restart keeps durable deadlines.','Global vi/en/zh widget, Task drawer start, note/estimate, extra time, manual record, settings, paged100 history and audited corrections. Offline view is read-only; monotonic display adds elapsed since an already-live DTO exactly once; wake refreshes the native clock. Unknown ACK retains original payload/revision/nonce through navigation; scope/logout fences late effects. Audit view exposes at most the first100 changes.'],'retainedEvidence':retained,'remaining':['P15 habit integration, P15–P18, remaining Wallet/W18/M1/I02/I03 and capacity/performance are open.','Final mandatory Windows Node22/24/three browsers, all parent suites, ZIP/service/performance and explicit pilot acceptance. New eight feature harnesses are not yet wired into mandatory Windows.','No new PR/Actions run for this feature-first group. Actual Server2019 R02 separate/unrun. Release/tag/VPS/PC runner not performed.']}
(root/'docs/engineering/evidence/p14-focus-development.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
(root/'docs/engineering/productivity-focus.md').write_text('''# P14 private Focus sessions

Sourceb3f6a6d adds explicit pilot19. Default6, frozen1–18 SQL/checksums and
Windows package capability13 remain unchanged. This is Cloud functional proof;
new-source Windows and full master-plan acceptance remain pending.

The global Focus widget and Task drawer support Pomodoro/stopwatch, default
25/5/15-minute phases and a long break after4 complete Pomodoros. Starting the
next phase is explicit. One running or paused session belongs to each user.
Notes, estimates, extra time, manual0–86400 seconds and reasoned duration
corrections are separate Focus data. Original time segments and ordered audit
revisions remain intact; the UI shows at most the first100 audit changes.

Integer-millisecond segments exclude pause gaps. Server deadlines and live
elapsed DTOs remain authoritative. The display adds monotonic time since receipt
once; wake/visibility/pageshow refresh its anchor. Offline controls are read-only.
The provider keeps unknown commands and their original source/revision/nonce
across navigation, clears revoked targets and fences late logout responses.
Current ACL is checked before cached target receipts and when presenting labels.
The owner can end their timer after losing the Task link. Habit links wait for
P15 storage and actual permissions; no placeholder habit authority is granted.

Focus never completes Tasks, awards points or posts Wallet money. Task/root and
quadrant-at-start are retained for later authorized insights. Shared AppJobs owns
one durable deadline/notice command per phase; display ticks do not write jobs.
P12 mute/quiet/daily preferences govern generic private owner notices using the
existing I01 inbox/outbox. Stable claims/digests deduplicate; no live provider is
called by tests. A backward clock defers delivery to its persisted clock fence.

Shared restore policies now receive one immutable validated capture timestamp.
Replacement recovery credits only pre-capture elapsed, pauses the session for
review and consumes historical pending notices, without replaying completion,
cycle counters or notifications. Ordinary restart retains durable deadlines.
Adding later FK tables preserves the original18 import-undo fingerprint shape;
actual later Focus references protect an otherwise unchanged imported Task.

Full8793tests556files/matchingJUnit,0failed-skipped-todo; all8749 parent cases
plus44 retained. Lint/build0. Same-build first-attempt Chromium29/29 includes
Focus4 plus all25 Calendar/collaboration/reminder/template/Notes/file/data flows.
Owned19/18/17/16/15/14/13/13 fixtures used offline adapters and normal shutdown,
integrity/closed-handle/cleanup checks. Four actual390px form/correction viewport
screenshots were inspected in light and dark. Full process restart and physical
OS suspend are not implied by registry pause/resume or browser wake tests.

[Evidence and retained failures](evidence/p14-focus-development.json) distinguish
real regressions, missing-module/typing checkpoints and successful qualification.
No assertions, timeouts, retries or quotas were weakened. Review is author-only.
Next P15–P18, remaining Wallet/W18/M1/I02/I03, then composed Windows qualification.
No new PR/Actions run, Server2019 acceptance, release, tag, VPS or PC runner.
''')
with (root/'docs/engineering/implementation-status.md').open('a')as file:file.write('''\n\n### P14 private Focus Cloud checkpoint (2026-10-18)\n\n- Sourceb3f6a6d64aee65afa92a9f285b4ce85e001db19f (backenda9dad4f/UI71de6a7), source PR URL/CI run URL not created for the feature-first group. Explicit pilot19/default6/frozen1–18/packagecaps13 preserved. Owner Pomodoro/stopwatch, segments, notes/estimates/extra/manual/audited edits, private P12 notices and capture-clock restore are usable through internal auth/API/global widget. No Task completion/reward/Wallet effects. Habit linking waits for real P15 authority.\n- Full8793tests556files/matchingJUnit/0failed-skipped-todo, all8749parent+44 retained; lint/build0. Chromium29/29 same-source/build firstattempts, owned19/18/17/16/15/14/13/13/offline/normalstop/integrity/closed/cleaned. Four actual390px form/audit viewports inspected across light/dark. Actual old18 undo fingerprint, negative early delay, restore audit DTO, backward-clock digest and equal-timestamp audit ordering failures retained/fixed. No assertion/timeout/retry reduction. [Evidence](evidence/p14-focus-development.json).\n- Next P15 Habits/Countdowns, then P16–P18/remainingWallet/W18/M1/I02/I03 and final composed Windows Node22/24/three engines/package/service/performance/pilot acceptance. New eight feature browser harnesses not yet mandatoryCI. Registry pause/resume/browser wake are not full process restart/physical OS suspend proof. No new PR/Actions/Windows/sourcepackage acceptance or full-master claim. R02 Server2019 separate/unrun; no release/tag/VPS/PC runner.\n''')
print('Validated8793full/29browser; retained',len(retained),'artifacts')
