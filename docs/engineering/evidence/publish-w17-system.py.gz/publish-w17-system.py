from pathlib import Path
import subprocess,json,gzip,hashlib,xml.etree.ElementTree as ET
r=Path('/workspace/Family-Organizer');e=Path('/workspace/family-evidence');d=r/'docs/engineering/evidence';sha='6c60ef308d249dc49de8d09ea4af118efa62247e';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==sha
for n in ['w17-system-qualified','w17-system-qualified-lint']:assert(e/(n+'.exit')).read_text().strip()=='0'
tests=json.loads((e/'w17-system-qualified.json').read_text());assert tests['success'] and tests['numTotalTests']==tests['numPassedTests']==2 and tests['numFailedTests']==tests['numPendingTests']==tests.get('numTodoTests',0)==0
cases=ET.parse(e/'w17-system-qualified.junit.xml').getroot().findall('.//testcase');assert len(cases)==2 and not any(c.find(t)is not None for c in cases for t in ['failure','error','skipped'])
h=lambda b:hashlib.sha256(b).hexdigest();retained={}
for file in sorted([*e.glob('w17-system-*'),e/'publish-w17-system.py']):
 if file.suffix in ['.log','.json','.xml','.exit','.py']:
  target=d/(file.name+'.gz');target.write_bytes(gzip.compress(file.read_bytes(),mtime=0));retained[file.name]={'path':str(target.relative_to(r)),'sha256':h(target.read_bytes())}
changed=subprocess.check_output(['git','diff','--name-only','7cae94a',sha],cwd=r,text=True).splitlines();assert all(f.startswith('docs/')or f in ['tests/wallet-system.test.ts','tests/wallet-system-seed.ts']for f in changed)
proof={'taskId':'W17 protected complete-schema recovery subset','sourceCommit':sha,'qualification':'Cloud synthetic functional checks, not Windows or complete100k recovery acceptance','prUrl':None,'ciRunUrl':None,'checks':{'targetedTests':2,'files':1,'junitCases':2,'failed':0,'skipped':0,'todo':0,'lintExitCode':0},'productionSourcesUnchangedFrom':'7cae94af340ac4596f1fe8f12e754d33bd548cec','aggregate':'Prior8409/498 plus separate2system checks; no new full aggregate/browser/build run for test-only additions. Prior65Chromium and build bind unchanged production sources.','sourceFiles':{f:h(subprocess.check_output(['git','show',sha+':'+f],cwd=r))for f in ['tests/wallet-system.test.ts','tests/wallet-system-seed.ts']},'retainedEvidence':retained,'verified':['Explicit schema16 fixture only; no production cap/activation change.','Actual runtime captures encrypted live WAL without closing its handle, then normal shutdown closes the connection.','Independent target restore retains every Wallet table row, exact int64 Money, receipt bytes, object grants, personal settings, confirmed occurrences, imported provenance, positions and quotes; target historical native session is revoked.','Restored target runtime starts ready and closes normally; recovery envelope remains unchanged; zero external requests.','Tampered trade cash remains invalid after recomputing transport checksum and reencrypting; target database bytes remain unchanged and no restore journal appears.'],'review':{'independent':False,'scope':'author inspection of owned synthetic roots/process lifecycle/network boundary and whole-table/media comparisons'},'remaining':['100k complete recovery cannot be inferred from100k query benchmark: shared snapshot100000total-row budget counts ledger plus related rows. W18 capacity/retention policy must preserve backup eligibility; current per-table import guard alone is insufficient.','W18 legacy bridge, Asset binding/unified networth, remaining P/M1/I02/I03/master and final Windows qualification remain.','Server2019 R02 unrun; no release/tag/VPS access or deployment.']};(d/'w17-system-development.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/engineering/implementation-status.md';s=p.read_text();anchor='## Current direction — 2026-10-18 (UTC)\n\n';entry=f'''**W17 protected recovery subset (2026-10-18):** source `{sha}` adds two
synthetic system checks and lint0, JSON/JUnit/native0. Actual live WAL encrypted
capture → independent installation restore → runtime restart preserves every
schema16 Wallet row, exact Money, receipts, ACL, settings, occurrences and trades;
a pre-existing target session is revoked. Rechecksummed/reencrypted corrupt trade
cash is rejected before target writes. Offline/owned roots/closed/cleaned.
Test-only additions: production sources unchanged from7cae94a; prior8409/498,
build and65Chromium remain separate evidence, no new aggregate claimed.
[Proof](evidence/w17-system-development.json). PR/CI URLs:none; author inspection,
backup branch only. Next W18 must address shared100000total-row backup capacity
before claiming100k complete recovery; per-table import guard is insufficient.
Legacy bridge/Asset/networth, remaining P/M1/I02/I03/master/final Windows remain.
Server2019 R02 unrun; no release/tag/VPS.

''';assert '**W17 protected recovery subset (2026-10-18):**'not in s;p.write_text(s.replace(anchor,anchor+entry,1))
p=r/'docs/engineering/wallet-performance.md';p.write_text(p.read_text().rstrip()+'\n\n## Complete-schema protected recovery\n\n'+entry.rstrip()+'\n')
print({'source':sha,'targetedPassed':2,'retained':len(retained)})
