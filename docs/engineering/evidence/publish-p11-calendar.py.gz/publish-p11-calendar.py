from pathlib import Path
import subprocess,json,gzip,hashlib,collections,re,xml.etree.ElementTree as ET
r=Path('/workspace/Family-Organizer');e=Path('/workspace/family-evidence');d=r/'docs/engineering/evidence';sha='c84376879fea854f5d3b03d16fb34ab6fd6aa4a0'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==sha
h=lambda b:hashlib.sha256(b).hexdigest()
current=json.loads((e/'p11-calendar-full.json').read_text());old=json.loads((e/'w17-import-full.json').read_text());assert current['success'] and current['numTotalTests']==current['numPassedTests']==8459 and current['numFailedTests']==current['numPendingTests']==current.get('numTodoTests',0)==0
cases=ET.parse(e/'p11-calendar-full.junit.xml').getroot().findall('.//testcase');assert len(cases)==8459 and not any(c.find(tag)is not None for c in cases for tag in ['failure','error','skipped'])
def identities(report):
 out=collections.Counter()
 for file in report['testResults']:
  name=str(Path(file['name']).relative_to(r))
  for case in file['assertionResults']:
   assert case['status']=='passed';title=case['fullName']
   if name=='server/recoveryRetention.test.ts':title=re.sub(r'/tmp/fo test synthetic [A-Za-z0-9]+(?=/|$)','/tmp/fo test synthetic <fixture>',title)
   out[(name,title)]+=1
 return out
prev,now=identities(old),identities(current);assert not prev-now,prev-now;assert sum(prev.values())==8409 and sum((now-prev).values())==50
for stem in ['p11-calendar-full','p11-calendar-final-lint','p11-calendar-second-source-build','p11-calendar-browser-whole']:assert(e/(stem+'.exit')).read_text().strip()=='0',stem
b=r/'reports/calendar/chromium';browser=json.loads((b/'browser.json').read_text());fixture=json.loads((b/'fixture.json').read_text());assert fixture['commitSha']==sha and fixture['seed']['productivityVersion']==13 and fixture['seed']['synthetic']
for key in ['databaseClosed','fixtureRemoved','legacyPreserved']:assert fixture[key],key
assert fixture['integrity']=='ok' and not fixture['networkAttempts'] and fixture['error']is None and fixture['serverExitCode']==fixture['browserExitCode']==0 and fixture['serverSignal']==fixture['browserSignal']==None
assert browser['stats']['expected']==4 and browser['stats']['unexpected']==browser['stats']['flaky']==browser['stats']['skipped']==0
bc=ET.parse(b/'browser.junit.xml').getroot().findall('.//testcase');assert len(bc)==4 and not any(c.find(tag)is not None for c in bc for tag in ['failure','error','skipped'])
for name,file in {'server':'dist/server.cjs','index':'dist/index.html'}.items():assert fixture['build'][name]==h((r/file).read_bytes())
files=subprocess.check_output(['git','diff','--name-only','3dafd00',sha],cwd=r,text=True).splitlines();assert 'package-lock.json'not in files and not any(name.endswith('Schema.ts')or name=='server/productivity/schema.ts'for name in files)
source={file:h(subprocess.check_output(['git','show',sha+':'+file],cwd=r))for file in files}
for file,digest in source.items():assert h((r/file).read_bytes())==digest,file
retained={}
for file in sorted([*e.glob('p11-calendar-*'),e/'publish-p11-calendar.py']):
 if file.is_file()and file.suffix in ['.json','.xml','.log','.exit','.py']:
  target=d/(file.name+'.gz');target.write_bytes(gzip.compress(file.read_bytes(),mtime=0));retained[file.name]={'path':str(target.relative_to(r)),'sha256':h(target.read_bytes())}
for label,folder in [('whole',b),('first-failed',e/'p11-calendar-browser-first-artifacts'),('second',e/'p11-calendar-browser-second-artifacts')]:
 for name in ['browser.json','browser.junit.xml','fixture.json','runtime.json','run.log','server.log']:
  file=folder/name
  if file.exists():
   target=d/('p11-calendar-'+label+'.'+name+'.gz');target.write_bytes(gzip.compress(file.read_bytes(),mtime=0));retained[label+'/'+name]={'path':str(target.relative_to(r)),'sha256':h(target.read_bytes())}
for file in b.glob('calendar-390-*.png'):
 target=d/('p11-'+file.name);target.write_bytes(file.read_bytes());retained[file.name]={'path':str(target.relative_to(r)),'sha256':h(target.read_bytes()),'visuallyInspected':True}
for file in (e/'p11-calendar-browser-first-artifacts').rglob('*'):
 if file.is_file()and file.suffix in ['.zip','.md']:
  target=d/('p11-calendar-first-failed-'+h(str(file.relative_to(e)).encode())[:10]+'-'+file.name+('.gz'if file.suffix=='.md'else''));target.write_bytes(gzip.compress(file.read_bytes(),mtime=0)if file.suffix=='.md'else file.read_bytes());retained[str(file.relative_to(e))]={'path':str(target.relative_to(r)),'sha256':h(target.read_bytes())}
aggregate={'parentPassed':8409,'passed':8459,'files':len(current['testResults']),'added':50,'removed':0,'junitCases':len(cases),'failed':0,'skipped':0,'todo':0,'scope':'full Cloud;50added=2W17protectedrecovery+48P11','normalization':'only temporary root in recoveryRetention names; multiplicity retained'}
proof={'taskId':'P11 Calendar/Timeline functional core','sourceCommit':sha,'baseHead':'3dafd007c54cb23c4534e53c5fc97f234ffb05f1','qualification':'Cloud functional development; ICS import belongs toP13 and final Windows qualification remains','prUrl':None,'ciRunUrl':None,'sourceFiles':source,'aggregate':aggregate,'lintExitCode':0,'buildExitCode':0,'buildSource':'691ac58c5c8a4c55403506da71695f7d91d1b4c4; only new4thbrowsercase after build, no production change','browser':{'scope':'all4Calendar Chromium journeys','cases':4,'failed':0,'skipped':0,'flaky':0,'firstAttemptsOnly':True,'fixture':fixture},'retainedEvidence':retained,'findings':['First3-case browser run:2passed/1failed because the unknown-write review modal blocked navigation. Add explicit defer without discarding the session-owned reviewed request; native retry now retains identical body/key after actual tab navigation. No assertion/deadline/retry relaxation.','Initial390px month titles were unreadably narrow. Mobile count cells plus selected-day details preserve readable titles; inspected real light/dark390x844screens after native source/state assertions.','Seven actual SDK REDs exposed source/time/patch inconsistencies; identity/time/confirmation checks now refuse malformed confirmable results.','Calendar projection reuses canonical task filter/ACL and existing FamilyPlan policy, plans virtual slots without materialization. Timed intervals and deadline changes stay separate. One virtual drag→cancel→confirm creates one P10exception without changing currentTask/reward/cash.','Local wall times enumerate real named-zone choices including DST folds and half-hour transitions; gaps cannot silently shift.','Fresh internal query precedes bounded visible-window ICS download; UTF8folding and text escaping preserve Unicode and prevent property injection. No publicfeed credentials/provider.'],'review':{'independent':False,'scope':'author inspection of current SQL ACL/privacy retirement/session-owned immutable packet/I01 trustedseries composition/clock semantics/ICS and DESIGN tokens'},'remaining':['Not fullP11/P13: ICSimport and consolidatedcontent import tools remain P13. Future/allseries edits use the existing task recurrence editor; FamilyPlan editing uses the existing authorized source.','Existing42Productivity+nativeTouch and65Wallet browser suites were not repeated for this functional group; final composed Windows must include allparents and newCalendar harness.','NewCalendar browser harness is not yet wired to finalWindows CI; I03 must make it mandatory, not silently omit it.','W18 capacity/retention/legacybridge/Asset/networth/cutover, remainingP/M1/I02/I03/master remain.','Windows2022 Node22/24/otherengines/package/service and actualServer2019R02 are unrun for this source. No release/tag/VPS.']}
(d/'p11-calendar-development.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
entry=f'''**P11 Calendar/Timeline core (2026-10-18):** source `{sha}` adds four
views, current-ACL task/FamilyPlan/virtual projection, reviewed independent
timeboxes and one-cycle moves through I01/P10, explicit DST choices, navigation-
safe unknown requests, readable phone month details and fresh authorized ICS
window download. No schema/automatic activation/package-cap change.
Cloud full8459tests507files/matching JUnit, zero failed-skipped-todo;
all8409 parent cases +50 retained (2W17system+48P11), lint/build0.
Whole Calendar Chromium4/4/native0/firstattempt/offline/owned13Taskfixture/
normal-stop/integrity/closed/cleaned/source-build-bound. Actual modal navigation
and narrow mobile-title failures corrected; original failed reports/trace kept.
[Details](productivity-calendar.md), [proof](evidence/p11-calendar-development.json).
Author inspection only; PR/CI URLs:none for this source; backup branch.
P11ICSimport→P13; future/allseries edits reuse the existing task editor.
Next P12collaboration/reminders and remainingP/W18/M1/I02/I03, then final composed
Windows including allparents+Calendar harness. ActualServer2019R02 unrun;
no release/tag/VPS. Separate PR136 historical greenCI is not this source's CI.

'''
p=r/'docs/engineering/implementation-status.md';s=p.read_text();anchor='## Current direction — 2026-10-18 (UTC)\n\n';assert '**P11 Calendar/Timeline core (2026-10-18):**'not in s;p.write_text(s.replace(anchor,anchor+entry,1))
(r/'docs/engineering/productivity-calendar.md').write_text('''# Calendar and Timeline — P11 functional core

'''+entry+'''The Calendar button beside List/Matrix/Kanban opens Month, Week, Agenda or
Timeline. Month uses readable selected-day details on phones. Existing task
filters select the same canonical task IDs; FamilyPlans keep their existing
source and visibility policy. FamilyPlan wall times retain the documented
Asia/Saigon assumption. All-day dates remain their original calendar date across
viewing timezones; scheduled intervals do not replace the stored deadline.

Dragging or using Reschedule opens an editable draft and read-only server preview.
Deadline edits need an additional explicit confirmation. A future occurrence
creates one durable exception through P10; editing the whole series remains in
the existing task drawer. No action completes or rewards a task or posts money.
Invalid/gap wall times are rejected; repeated DST wall times require a choice.

Unknown write results keep the exact reviewed body and key in the authenticated
TaskProvider. Check later hides the modal without discarding the request; opening
Calendar again restores it. Logout or fresh authoritative revocation clears it.
No device financial cache/offline write queue is enabled. PLANS_UPDATE invalidates
the projection before another read, including revoked plan bodies.

Download visible calendar performs a fresh authorized internal query first and
exports the selected window to a local ICS file. It does not create a public
feed or encode credentials/recipients. Virtual entries are tentative snapshots,
not an RRULE promise. Unresolved timestamps must be reviewed before export.
ICSimport and lossless task-content roundtrip remain P13.

The current browser harness is portable and synthetic. It has not yet joined the
mandatory final Windows batch; I03 must wire it alongside all existing suites.
Cloud and Windows2022 checks do not qualify WindowsServer2019; R02 remains unrun.
''')
print({'source':sha,'aggregate':aggregate,'browser':4,'retained':len(retained)})
