from pathlib import Path
import json,hashlib,gzip,subprocess,xml.etree.ElementTree as ET
r=Path('/workspace/Family-Organizer');e=Path('/workspace/family-evidence');d=r/'docs/engineering/evidence';sha=(e/'w17-query-qualified-source.sha').read_text().strip();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==sha
current=json.loads((e/'w17-reference-query-benchmark.json').read_text());baseline=json.loads((e/'w17-query-baseline-second.json').read_text());tests=json.loads((e/'w17-query-qualified-targeted.json').read_text());digest=lambda b:hashlib.sha256(b).hexdigest()
assert current['sourceCommit']==sha and not current['workingTreeDirty'] and not current['errors'] and current['records']==current['count']==100000 and current['iterations']==20 and current['warmupIterations']==3
for key in ['databaseClosed','fixtureRemoved','networkBoundaryConfigured','referenceDataset','meetsMeasuredTargets']:assert current[key],key
assert current['networkAttempts']==0 and current['integrity']=='ok' and not current['windowsPerformanceAccepted']
for file,h in current['sourceFiles'].items():assert digest(subprocess.check_output(['git','show',sha+':'+file],cwd=r))==h,file
assert tests['success'] and tests['numPassedTests']==tests['numTotalTests']==200 and tests['numFailedTests']==tests['numPendingTests']==tests.get('numTodoTests',0)==0
cases=ET.parse(e/'w17-query-qualified-targeted.junit.xml').getroot().findall('.//testcase');assert len(cases)==200;assert not any(case.find(key)is not None for case in cases for key in ['failure','error','skipped'])
for name in ['w17-query-qualified-targeted','w17-benchmark-exact-lint','w17-query-final-build','w17-reference-query-benchmark']:assert (e/(name+'.exit')).read_text().strip()=='0',name
# Preserve the full physical SQL query and both current-authority reads.
old=subprocess.check_output(['git','show','e80effb:server/wallet/query.ts'],cwd=r,text=True);new=(r/'server/wallet/query.ts').read_text();sql=lambda source:source[source.index('const sql = `'):source.index('`;',source.index('const sql = `'))+2];assert sql(old)==sql(new)
retained={}
for file in sorted([*e.glob('w17-*'),e/'wallet-query.cpuprofile']):
 if file.is_file() and file.suffix in ['.json','.log','.exit','.xml','.mts','.ts','.cpuprofile','.py','.sha']:
  target=d/(file.name+'.gz');target.write_bytes(gzip.compress(file.read_bytes(),mtime=0));retained[file.name]={'path':str(target.relative_to(r)),'sha256':digest(target.read_bytes())}
files=subprocess.check_output(['git','diff','--name-only','e80effb',sha],cwd=r,text=True).splitlines();source={name:digest(subprocess.check_output(['git','show',sha+':'+name],cwd=r))for name in files}
proof={'taskId':'W17 query-performance subset','qualification':'Cloud reference workload only; not full W17 or Windows acceptance','sourceCommit':sha,'baseHead':'e80effb3d96b9c31d5d30c39960cc3e2a48e5f47','prUrl':None,'ciRunUrl':None,'sourceFiles':source,'benchmark':current,'baseline':baseline,'pageP95Speedup':baseline['metrics']['page50']['p95Milliseconds']/current['metrics']['page50']['p95Milliseconds'],'reportP95Speedup':baseline['metrics']['monthReport']['p95Milliseconds']/current['metrics']['monthReport']['p95Milliseconds'],'tests':{'passed':200,'files':len(tests['testResults']),'junitCases':len(cases),'failed':0,'skipped':0,'todo':0,'scope':'targeted date/filter/query/report/budget/records/metadata/portfolio snapshot and portable benchmark CLI regressions; not full aggregate'},'lintExitCode':0,'buildExitCode':0,'sqlTemplateUnchanged':True,'bothAuthorityReadsRetained':True,'retainedEvidence':retained,'review':{'independent':False,'scope':'author inspection of validation-only timezone reuse, captured predicates, descriptor-only cache, fresh decoded values/current ACL fences and synthetic benchmark safety'},'findings':['100k baseline measured page50 p95~712ms and month-report p95~2209ms on this Cloud reference host.','A new regression reproduced1000 ICU constructions for1000 period validations. Reuse the existing bounded validation-only named-zone path; public timezoneFormatter instances remain caller-owned.','An initial pass missed the other period resolver call and needed a constructor-forwarding native Intl spy; all actual failed reports are retained, then the original calendar/budget tests pass.','CPU profile identified repeated metadata descriptor conversion and full SQL reads. Physical SQL, both authority scans and exact per-record validation are retained; only immutable descriptor names are reused, with fresh values/audit JSON.','Compiled predicates snapshot input scope/category ancestry/query/bounds once per evaluation. Caller mutation cannot broaden the approved filter.','Portable benchmark checks actual unique month rows, independent exact income/expense/count totals,20measured samples plus3warmups, integrity/closed/cleanup/network policy and source/host identity. Windows reference CLI fails when its qualified runtime/source/dataset/latency conditions do not pass.'],'remaining':['No full aggregate/browser run for this subset; previous8391/493+65Chromium belongs to W16. Final composed checks remain required.','Current100k reference is one synthetic VND account, alternating income/expense across2026 with no FX/provider/labels/splits; this is not a claim for every filter or full100k recovery workload.','10000-row import still needs bounded writer work and responsiveness qualification; preserve every financial/nonce/audit/rollback/source-duplicate invariant.','W17 system/protected recovery/Windows package-service and W18 canonical legacy bridge/retention/capacity/cutover remain, along with remaining Productivity/M1/I02/I03/master.','No automatic migration/activation or production package-cap change. Actual Server2019 R02 remains unrun; no release/tag/VPS.']}
(d/'w17-query-performance-development.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n')
p95=current['metrics'];(r/'docs/engineering/wallet-performance.md').write_text(f'''# Wallet query reference — W17 subset

Source `{sha}` preserves the physical query SQL, both current-authority
reads, exact Money validation, cursor/signature fences and all data/ACL checks.
Validation reuses the existing bounded named-timezone path; public formatters
remain fresh. Predicates capture reviewed filter inputs once; metadata caches
only descriptor names and always creates fresh values and nested audit JSON.

The portable `scripts/benchmark-wallet.ts` creates its own synthetic temporary
DATA_DIR/config, applies explicit pilot schema16, uses one I01 store, and closes/
removes only that fixture. It starts no runtime/jobs and calls no providers.
Reference data:100000 records, one private VND account, alternating income/
expense across2026, null historical metadata, no FX/labels/splits. Twenty measured
samples follow three warmups. Exact monthly counts/totals and50unique in-period
rows are checked independently. Hardware/runtime/source/samples/RSS/integrity/
network/cleanup are recorded; p95 uses nearest rank. This workload does not
qualify every filter,100k complete recovery or actual Server2019.

| Metric | Baseline Cloud p95 | Current Cloud p95 | Required reference Windows target |
| --- | ---: | ---: | ---: |
| Page50 | {baseline['metrics']['page50']['p95Milliseconds']:.1f}ms | {p95['page50']['p95Milliseconds']:.1f}ms | <500ms |
| Month report | {baseline['metrics']['monthReport']['p95Milliseconds']:.1f}ms | {p95['monthReport']['p95Milliseconds']:.1f}ms | <1000ms |

Current Cloud host:Node24.21.0/x64/better-sqlite3 13.0.3, four available CPUs.
The full machine and20samples are in the proof. Both Cloud targets are measured
below the reference limits; **Windows performance remains unqualified**.
A Windows reference CLI run must use the pinned runtime, clean source,100k data,
20iterations and network boundary, and exits nonzero if qualification fails.
A1000-row diagnostic test never becomes a Windows acceptance result.

Targeted200tests/13files and matching JUnit, zero failures/skips/todo, lint/build0;
exact-HEAD benchmark and retained CPU profile/development failures. No full
aggregate or browser repeat for this subset; W16’s8391/493+65Chromium remains
separate historical evidence. No PR/CI URL, backup branch only.
[Proof](evidence/w17-query-performance-development.json).

Next:10k import responsiveness, complete recovery/system/Windows qualification,
W18 legacy bridge/capacity/retention/cutover and remaining P/M1/I02/I03/master.
No release/tag/VPS access or deployment. Actual Server2019 R02 remains separate.
''')
status=r/'docs/engineering/implementation-status.md';s=status.read_text();anchor='## Current direction — 2026-10-18 (UTC)\n\n';entry=f'''**W17 query-performance subset (2026-10-18):** source `{sha}`
adds portable synthetic benchmark and reduces repeated ICU/filter/metadata
allocation while retaining physical SQL and both ACL/data fences. Reference100k
Cloud p95 page50 {p95['page50']['p95Milliseconds']:.1f}ms (baseline711.9), month
{p95['monthReport']['p95Milliseconds']:.1f}ms (baseline2209.0);20samples/3warmups,
exact totals/ID count, integrity/closed/cleaned/offline/source-bound.
Targeted200/13 JSON/JUnit, zero failures/skips/todo; lint/build0. No new full
aggregate/browser or Windows acceptance; W16 evidence remains separate.
[Details](wallet-performance.md), [proof](evidence/w17-query-performance-development.json).
PR/CI URLs:none; author inspection only; backup branch. W17 incomplete:10k
import responsiveness and full recovery/system; W18, remaining P/M1/I02/I03/master
and final Windows batch remain. No release/tag/VPS;Server2019 R02 unrun.

''';assert '**W17 query-performance subset (2026-10-18):**'not in s;status.write_text(s.replace(anchor,anchor+entry,1));print(json.dumps({'source':sha,'retained':len(retained),'targeted':200,'pageP95':p95['page50']['p95Milliseconds'],'reportP95':p95['monthReport']['p95Milliseconds']}))
