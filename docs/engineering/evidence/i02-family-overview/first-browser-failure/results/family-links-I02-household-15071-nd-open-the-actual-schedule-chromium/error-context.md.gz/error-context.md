# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: family-links.spec.ts >> I02 household overview matches native root counts, finance dates remain typed read-only in Calendar and open the actual schedule
- Location: tests/e2e/family-links.spec.ts:16:1

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator: getByRole('textbox', { name: 'Tên lịch', exact: true })
Expected: "Synthetic I02 admin calendar bill"
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toHaveValue" getByRole('textbox', { name: 'Tên lịch', exact: true }) with timeout 10000ms
  - waiting for getByRole('textbox', { name: 'Tên lịch', exact: true })

```

```yaml
- complementary:
  - text: Family Organizer Không gian gia đình
  - navigation:
    - button "Tổng quan"
    - button "Nhóm Task"
    - button "Chi tiêu"
    - button "Lập Lịch"
    - button "Ghi chú"
    - button "Đi chợ"
    - button "Sức khỏe gia đình"
    - button "Giấy tờ"
    - button "Quản lý Server"
    - button "Thiết lập"
  - button "Mở hồ sơ của Synthetic admin": S Synthetic admin Quản lý (Admin) • v1.1.0
  - button "Đăng xuất"
- banner:
  - text: "Đồng bộ: Đang kết nối"
  - button "Tìm kiếm toàn cục"
  - button "Chuyển sang Giao diện Tối"
  - button "5"
- main:
  - group: Tập trung
  - group "Sổ tài khoản":
    - button "Tài khoản"
    - button "Ghi chép"
    - button "Danh mục"
    - button "Báo cáo Wallet"
    - button "Nhập dữ liệu"
    - button "Quy tắc phân loại"
    - button "Lập kế hoạch" [pressed]
    - button "Danh mục đầu tư"
    - button "Thiết lập Wallet"
    - button "Tổng quan Wallet"
  - region "Lập kế hoạch":
    - heading "Lập kế hoạch" [level=2]
    - button "Tải lại tài khoản"
    - button "Tạo lịch định kỳ"
    - paragraph: Lịch theo dõi thu, chi và chuyển khoản. Tự động ghi chỉ cập nhật sổ theo dõi; không chuyển tiền hay thanh toán hóa đơn thật.
    - list:
      - listitem:
        - button "Synthetic I02 admin calendar bill" [pressed]
        - paragraph: Xác nhận thủ công · Đang hoạt động
        - button "Sửa lịch"
        - button "Tạm dừng"
        - button "Lưu trữ"
    - region "Các kỳ định kỳ":
      - heading "Synthetic I02 admin calendar bill" [level=3]
      - button "Cập nhật kỳ chờ xác nhận"
      - list:
        - listitem:
          - paragraph: 2026-10-19 · Asia/Saigon · Chờ xác nhận
          - paragraph: Chi tiêu · 12.345 ₫
          - paragraph
          - group:
            - button "Tạo bản ghi sổ mới"
            - button "Bỏ qua kỳ này"
            - button "Tìm bản ghi có sẵn cùng ngày"
  - region "Ngân sách và dự báo":
    - heading "Ngân sách và dự báo" [level=2]
    - button "Tải lại tài khoản"
    - button "Tạo ngân sách"
    - paragraph: Ngân sách cá nhân chỉ đo chi tiêu bạn được phép xem. Dự báo và chuyển số dư ngân sách không tạo giao dịch tiền.
    - group:
      - text: Tháng ngân sách
      - textbox "Tháng ngân sách": 2026-10
      - text: Cách dự báo chi tiêu
      - button "Cách dự báo chi tiêu": Chỉ lịch chưa thanh toán
    - paragraph: Tạo ngân sách để theo dõi hạn mức, thực chi và khoản dự kiến.
    - list
    - region "Dự báo số dư tài khoản":
      - heading "Dự báo số dư tài khoản" [level=3]
      - paragraph: Chọn rõ tài khoản và tháng đích trong 12 tháng tới. Đây là kịch bản tham khảo, không phải số tiền bảo đảm.
      - group:
        - checkbox "Synthetic family USD · USD"
        - text: Synthetic family USD · USD
        - checkbox "Synthetic shared family book · VND"
        - text: Synthetic shared family book · VND
        - checkbox "Synthetic family cash · VND"
        - text: Synthetic family cash · VND
        - checkbox "PRIVATE_I02_ACCOUNT_LABEL · VND"
        - text: PRIVATE_I02_ACCOUNT_LABEL · VND Tháng đích
        - textbox "Tháng đích": 2026-10
        - text: Tiền tệ quy đổi
        - button "Tiền tệ quy đổi": VND
        - text: Kịch bản dự báo
        - button "Kịch bản dự báo": Chỉ lịch chưa thanh toán
        - button "Tính dự báo số dư" [disabled]
  - region "Liên kết nợ và tiết kiệm":
    - heading "Liên kết nợ và tiết kiệm" [level=2]
    - button "Tải lại liên kết"
    - paragraph: Dùng tài khoản hiện có để trả nợ và góp tiết kiệm. Lịch sử cũ chỉ được nối với sổ khi bạn chủ động liên kết. Khoản nợ và mục tiêu cũ dùng VND.
    - heading "Khoản vay và cho vay" [level=3]
    - paragraph: Tạo khoản nợ hoặc mục tiêu trong Tài chính trước.
    - heading "Mục tiêu tiết kiệm" [level=3]
    - paragraph: Tạo khoản nợ hoặc mục tiêu trong Tài chính trước.
    - heading "Lịch sử liên kết của tôi" [level=3]
    - paragraph: Chưa có lần trả nợ hoặc góp được liên kết.
  - region "Bộ lọc và biểu đồ cá nhân":
    - heading "Bộ lọc và biểu đồ cá nhân" [level=3]
    - button "Lưu bộ lọc đang áp dụng"
    - group:
      - button "Chọn cấu hình đã lưu"
  - button "Thu chi & ngân sách"
  - button "Tài sản gia đình"
  - button "Tháng"
  - button "Quý"
  - button "Năm"
  - button "So sánh"
  - button "Kỳ trước"
  - paragraph: Tháng 10/2026
  - text: Kỳ hiện tại
  - button "Kỳ sau" [disabled]
  - text: Cân đối kỳ này
  - heading "+0 VNĐ" [level=3]
  - text: — so kỳ trước Nguồn thu trong kỳ
  - heading "+0 VNĐ" [level=3]
  - text: — so kỳ trước Chi tiêu trong kỳ
  - heading "-0 VNĐ" [level=3]
  - text: — so kỳ trước Tiền mặt 💵 0 đ Ngân hàng 💳 0 đ Ví điện tử 📱 0 đ
  - heading "Ngân sách Tháng 10/2026" [level=3]
  - text: 0 hạn mức
  - button "Hạng mục ngân sách": Ăn uống 🍲
  - textbox "Hạn mức"
  - button "Lưu"
  - paragraph: Chưa có ngân sách cho kỳ này.
  - heading "Hóa đơn định kỳ" [level=3]
  - text: 0 khoản
  - textbox "Tên hóa đơn"
  - textbox "Số tiền"
  - textbox "dd/mm/yyyy": 18/10/2026
  - button "Chọn ngày từ lịch"
  - button "Tần suất hóa đơn": Hàng tháng
  - button "Hạng mục hóa đơn": Điện nước
  - button "Lưu"
  - paragraph: Chưa có hóa đơn lặp lại.
  - heading "Mục tiêu tiết kiệm" [level=3]
  - button "Mục tiêu"
  - paragraph: Chưa có mục tiêu tiết kiệm. Tạo quỹ để dành cho Tết, du lịch, học phí...
  - heading "Vay / Cho mượn" [level=3]
  - button "Khoản nợ"
  - paragraph: Chưa có khoản vay/cho mượn nào.
  - textbox "Tìm miêu tả khoản chi, mua đồ đạc gia đình..."
  - text: Loại quỹ
  - button "Lọc theo loại quỹ": Khoản thu & chi
  - text: Hạng mục chi
  - button "Lọc theo hạng mục": Mọi hạng mục
  - text: Ví tài khoản
  - button "Lọc theo ví tài khoản": Mọi ví tài khoản
  - text: Thành viên thực hiện
  - button "Lọc theo thành viên": Cả gia đình
  - paragraph: Không có giao dịch nào trong Tháng 10/2026 khớp bộ lọc.
- button "AI assistant"
- button "Thêm khoản thu chi nhanh"
```

# Test source

```ts
  1  | import {loginProductivityActor as login} from './productivity-actor-login.js';import {test as base,expect,type Page} from '@playwright/test';import {installOfflineNetworkBoundary} from './offline-network-boundary.js';import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
  2  | const seed=JSON.parse(process.env.FO_FAMILY_SEED??'null'),drawer=(page:Page)=>page.getByRole('dialog',{name:'Chi tiết công việc',exact:true}),panel=(page:Page)=>page.getByTestId('task-family-panel');
  3  | const test=base.extend<{boundary:void}>({boundary:[async({context,page,baseURL},use)=>{if(!baseURL||!seed?.synthetic||seed.productivityVersion!==24||seed.walletVersion!==16)throw Error('Owned synthetic Family24/Wallet16 fixture required');const external:string[]=[],errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));await installOfflineNetworkBoundary(context,baseURL,external);await context.addInitScript(()=>{if(['http:','https:'].includes(location.protocol))localStorage.setItem('family_lang','vi');});await use();expect(external).toEqual([]);expect(errors).toEqual([]);},{auto:true}]});
  4  | test.beforeAll(async({browser,browserName})=>{const folder=path.join('reports/family',browserName);fs.mkdirSync(folder,{recursive:true});fs.writeFileSync(path.join(folder,'runtime.json'),JSON.stringify({browserName,browserVersion:browser.version(),executableSha256:createHash('sha256').update(fs.readFileSync(browser.browserType().executablePath())).digest('hex'),node:process.version,platform:process.platform,architecture:process.arch}));});
  5  | async function request(page:Page,url:string,method='GET',body?:unknown,token?:string,key?:string){return page.evaluate(async({url,method,body,token,key})=>{const response=await fetch('/api/'+url,{method,headers:{Authorization:'Bearer '+(token??localStorage.getItem('family_token')),'Content-Type':'application/json','x-request-id':key??crypto.randomUUID()},...(body===undefined?{}:{body:JSON.stringify(body)})});return {status:response.status,body:await response.json()};},{url,method,body,token,key});}
  6  | async function create(page:Page,title:string,listId='legacy-family',isShared=true){const value=await request(page,'productivity/tasks','POST',{expectedRevision:0,input:{listId,title,isShared,due:{kind:'none'}}});expect(value.status,JSON.stringify(value.body)).toBe(200);return value.body.task;}
  7  | async function scheduleForOverview(page:Page,role='admin',accountId=seed.familyFixture.cashAccountId){const source=await create(page,'Synthetic I02 overview clock'),clock=(await request(page,'productivity/tasks/'+source.id+'/wallet-payment-draft')).body.clock,date=new Intl.DateTimeFormat('en-CA',{timeZone:clock.timezone,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(clock.nowUtc)),name='Synthetic I02 '+role+' calendar bill',created=await request(page,'wallet/schedules','POST',{expectedRevision:0,draft:{name,record:{kind:'expense',accountId,money:{minor:'12345',currency:'VND'},effectiveDate:date,timezone:clock.timezone,note:'',payee:'',paymentMethod:'',occurredAt:null,reviewedAt:null,settlementStatus:'uncleared',categoryId:null,labelIds:[]},recurrence:{anchorDate:date,timezone:clock.timezone,frequency:'monthly',interval:1,monthEndPolicy:'clamp'},mode:'manual',reminderDays:[3,0],paused:false}});expect(created.status,JSON.stringify(created.body)).toBe(200);return {id:created.body.id,name,date,clock};}
  8  | async function open(page:Page,task:any){await page.locator('[data-task-id="'+task.id+'"]').first().click();await expect(drawer(page)).toBeVisible();await expect(panel(page).getByRole('button',{name:'Chuẩn bị chi khoản từ công việc',exact:true})).toBeEnabled();}
  9  | async function begin(page:Page,accountName='Synthetic family cash',amount='1.000',memo=''){await panel(page).getByRole('button',{name:'Chuẩn bị chi khoản từ công việc',exact:true}).click();await expect(panel(page).getByRole('textbox',{name:'Ghi chú trên sổ tài khoản',exact:true})).toHaveValue('');await panel(page).getByRole('button',{name:'Tài khoản ghi chi',exact:true}).click();await page.getByRole('option',{name:accountName+' · VND',exact:true}).click();await panel(page).getByRole('textbox',{name:'Số tiền ghi chi',exact:true}).fill(amount);if(memo)await panel(page).getByRole('textbox',{name:'Ghi chú trên sổ tài khoản',exact:true}).fill(memo);await panel(page).getByRole('button',{name:'Xem lại khoản chi riêng',exact:true}).click();if(amount!=='0')await expect(panel(page).getByRole('region',{name:'Xem lại khoản chi riêng',exact:true})).toBeVisible();}
  10 | async function balance(page:Page,id:string,date:string){const value=await request(page,'wallet/accounts/'+id+'/balance?'+new URLSearchParams({date}));expect(value.status,JSON.stringify(value.body)).toBe(200);return value.body;}
  11 | test('I02 Task completion and payment previewcancel post zero money; original lost acknowledgement retries one expense and opens the actual Wallet source',async({page})=>{await login(page);const task=await create(page,'Synthetic I02 actual bill'),nativeDraft=(await request(page,'productivity/tasks/'+task.id+'/wallet-payment-draft')).body,date=nativeDraft.payment.effectiveDate,before=await balance(page,seed.familyFixture.cashAccountId,date);await open(page,task);const completed=await request(page,'productivity/tasks/'+task.id+'/complete','POST',{expectedRevision:1});expect(completed.status,JSON.stringify(completed.body)).toBe(200);await expect(panel(page).getByRole('button',{name:'Chuẩn bị chi khoản từ công việc',exact:true})).toBeEnabled();expect(await balance(page,seed.familyFixture.cashAccountId,date)).toEqual(before);await begin(page);await panel(page).getByRole('region',{name:'Xem lại khoản chi riêng',exact:true}).getByRole('button',{name:'Hủy',exact:true}).click();expect(await balance(page,seed.familyFixture.cashAccountId,date)).toEqual(before);await panel(page).getByRole('textbox',{name:'Ghi chú trên sổ tài khoản',exact:true}).fill('Synthetic I02 confirmed expense 中文 🧪');await panel(page).getByRole('button',{name:'Xem lại khoản chi riêng',exact:true}).click();const calls:any[]=[],results:any[]=[];await page.route('**/api/productivity/tasks/'+task.id+'/wallet-payment',async route=>{calls.push({key:route.request().headers()['x-request-id'],body:route.request().postDataJSON()});const response=await route.fetch();expect(response.status()).toBe(200);results.push(await response.json());if(calls.length===1)await route.abort('failed');else await route.fulfill({response});});await panel(page).getByRole('button',{name:'Xác nhận ghi chi',exact:true}).click();await expect(panel(page).getByRole('button',{name:'Kiểm tra khoản chi đã gửi',exact:true})).toBeEnabled();await drawer(page).getByRole('button',{name:'Đóng',exact:true}).click();await page.getByTestId('task-projections').getByRole('button',{name:'Lịch công việc',exact:true}).click();await page.getByTestId('task-projections').getByRole('button',{name:'Danh sách',exact:true}).click();await page.getByRole('button',{name:'Góc nhìn công việc',exact:true}).click();await page.getByRole('option',{name:'Đã hoàn thành',exact:true}).click();await page.locator('[data-task-id="'+task.id+'"]').first().click();await expect(panel(page).getByRole('button',{name:'Kiểm tra khoản chi đã gửi',exact:true})).toBeEnabled();await panel(page).getByRole('button',{name:'Kiểm tra khoản chi đã gửi',exact:true}).click();await expect(panel(page).getByRole('form',{name:'Bản nháp chi khoản riêng',exact:true})).toHaveCount(0);expect(calls).toHaveLength(2);expect(calls[1]).toEqual(calls[0]);expect(results[1].recordId).toBe(results[0].recordId);expect(calls[0].body.input).toMatchObject({taskId:task.id,taskRevision:completed.body.task.revision,confirmed:true,payment:{money:{minor:'1000',currency:'VND'}}});const record=(await request(page,'wallet/records/'+results[0].recordId)).body;expect(record.postings).toMatchObject([{deltaMinor:'-1000'}]);expect((await request(page,'productivity/tasks/'+task.id)).body.task).toMatchObject({lifecycle:'completed',revision:completed.body.task.revision});await panel(page).getByRole('button',{name:'Synthetic I02 confirmed expense 中文 🧪',exact:true}).click();await expect(page.getByRole('region',{name:'Chi tiết ghi chép',exact:true})).toContainText('Synthetic I02 confirmed expense 中文 🧪');});
  12 | test('I02 private Task source stays out of a shared ledger memo and Child cannot open a financial draft or infer the private reference',async({page})=>{await login(page);const list=await request(page,'productivity/lists','POST',{expectedRevision:0,input:{title:'Synthetic I02 private source list',isShared:false}});expect(list.status).toBe(200);const title='PRIVATE_I02_SHARED_LEDGER_SOURCE',task=await create(page,title,list.body.list.id,false),account=await request(page,'wallet/accounts','POST',{expectedRevision:0,input:{name:'Synthetic shared family book',type:'cash',currency:'VND',openingMinor:'10000',openingDate:'2026-01-01',accessMode:'shared'}});expect(account.status).toBe(200);await open(page,task);await begin(page,'Synthetic shared family book','10');let receipt:any;await page.route('**/api/productivity/tasks/'+task.id+'/wallet-payment',async route=>{const response=await route.fetch();expect(response.status()).toBe(200);receipt=await response.json();await route.fulfill({response});});await panel(page).getByRole('button',{name:'Xác nhận ghi chi',exact:true}).click();await expect.poll(()=>!!receipt).toBe(true);await expect(panel(page)).toContainText('Đã xác nhận khoản chi.');await login(page,'member');const visible=await request(page,'wallet/records/'+receipt.recordId);expect(visible.status).toBe(200);expect(visible.body.record.note).toBe('');expect(JSON.stringify(visible.body)).not.toContain(title);expect((await request(page,'productivity/domain-links/'+receipt.link.link.id)).status).toBe(404);await login(page,'child');const denied=await request(page,'productivity/tasks/'+task.id+'/wallet-payment-draft');expect(denied.status).toBe(403);expect(JSON.stringify(denied.body)).not.toContain(title);expect((await request(page,'wallet/records/'+receipt.recordId)).status).toBe(403);});
  13 | test('I02 current Task grant revocation clears payment source/account labels and fences a held old response; accepted original nonce cannot bypass it',async({page})=>{const admin=await login(page),list=await request(page,'productivity/lists','POST',{expectedRevision:0,input:{title:'Synthetic I02 revocable payment list',isShared:false}}),title='PRIVATE_I02_REVOKED_PAYMENT_TASK',task=await create(page,title,list.body.list.id,false),grant=await request(page,'productivity/lists/'+list.body.list.id+'/grant','POST',{expectedRevision:1,input:{userId:'browser-member',permission:'read'}}),account=await request(page,'wallet/accounts','POST',{expectedRevision:0,input:{name:'PRIVATE_I02_ACCOUNT_LABEL',type:'cash',currency:'VND',openingMinor:'10000',openingDate:'2026-01-01',accessMode:'private'}});expect(account.status).toBe(200);expect((await request(page,'wallet/accounts/'+account.body.account.id+'/grants/browser-member','PUT',{expectedRevision:1,permission:'contribute'})).status).toBe(200);await login(page,'member');await open(page,task);await begin(page,'PRIVATE_I02_ACCOUNT_LABEL','10','Synthetic own source-bound memo');let original:any;await page.route('**/api/productivity/tasks/'+task.id+'/wallet-payment',async route=>{original={key:route.request().headers()['x-request-id'],body:route.request().postDataJSON()};expect((await route.fetch()).status()).toBe(200);await route.abort('failed');});await panel(page).getByRole('button',{name:'Xác nhận ghi chi',exact:true}).click();await expect(panel(page).getByRole('button',{name:'Kiểm tra khoản chi đã gửi',exact:true})).toBeEnabled();let release:()=>void=()=>{},captured=false,delivered=false;const held=new Promise<void>(resolve=>{release=resolve;});await page.route('**/api/productivity/tasks/'+task.id+'/wallet-payment-draft',async route=>{if(captured){await route.continue();return;}const response=await route.fetch();expect(response.status()).toBe(200);expect(await response.text()).toContain(title);captured=true;await held;await route.fulfill({response});delivered=true;});await panel(page).getByRole('button',{name:'Tải lại tham chiếu và quyền',exact:true}).click();await expect.poll(()=>captured).toBe(true);expect((await request(page,'productivity/lists/'+list.body.list.id+'/grant','POST',{expectedRevision:grant.body.list.revision,input:{userId:'browser-member',permission:null}},admin)).status).toBe(200);await expect(page.getByText(title,{exact:true})).toHaveCount(0);release();await expect.poll(()=>delivered).toBe(true);await expect(page.getByText('PRIVATE_I02_ACCOUNT_LABEL',{exact:false})).toHaveCount(0);await expect(page.getByText(title,{exact:true})).toHaveCount(0);await page.unroute('**/api/productivity/tasks/'+task.id+'/wallet-payment');const denied=await request(page,'productivity/tasks/'+task.id+'/wallet-payment','POST',original.body,undefined,original.key);expect(denied.status).toBe(404);expect(JSON.stringify(denied.body)).not.toContain(title);});
  14 | test('I02 expense fields and explicit review fit390px light/dark; invalid amount remains editable and closing unsent draft leaves no money effect',async({page})=>{await login(page);const task=await create(page,'Synthetic I02 phone expense');await page.setViewportSize({width:390,height:844});for(const theme of['light','dark']){await page.evaluate(theme=>localStorage.setItem('family_theme',theme),theme);await page.reload();await open(page,task);await begin(page,'Synthetic family cash','0');await expect(panel(page)).toContainText('Số tiền, ngày hoặc tài khoản chưa hợp lệ.');await panel(page).getByRole('textbox',{name:'Số tiền ghi chi',exact:true}).fill('1.000');await panel(page).getByRole('button',{name:'Xem lại khoản chi riêng',exact:true}).click();const preview=panel(page).getByRole('region',{name:'Xem lại khoản chi riêng',exact:true});await expect(preview).toBeVisible();await preview.scrollIntoViewIfNeeded();expect(await preview.evaluate(element=>element.getBoundingClientRect().right<=innerWidth)).toBe(true);await page.screenshot({path:path.join('reports/family',test.info().project.name,'payment-review-390-'+theme+'.png')});await preview.getByRole('button',{name:'Hủy',exact:true}).click();await panel(page).getByRole('textbox',{name:'Ghi chú trên sổ tài khoản',exact:true}).scrollIntoViewIfNeeded();expect(await panel(page).evaluate(element=>element.scrollWidth<=element.clientWidth)).toBe(true);await page.screenshot({path:path.join('reports/family',test.info().project.name,'payment-editor-390-'+theme+'.png')});await panel(page).getByRole('button',{name:'Đóng bản nháp chi khoản',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Bỏ bản nháp chi khoản',exact:true}).click();expect((await request(page,'productivity/domain-links?kind=task&id='+task.id)).body.total).toBe(0);await drawer(page).getByRole('button',{name:'Đóng',exact:true}).click();}});
  15 | 
  16 | test('I02 household overview matches native root counts, finance dates remain typed read-only in Calendar and open the actual schedule',async({page})=>{
  17 |  await login(page);const bill=await scheduleForOverview(page),before=(await request(page,'productivity/tasks/'+(await create(page,'Synthetic I02 zero-calendar-effects')).id+'/wallet-payment-draft')).body.payment.effectiveDate,amount=await balance(page,seed.familyFixture.cashAccountId,before);
> 18 |  await page.goto('/?tab=dashboard');const home=page.getByTestId('family-overview');await expect(home.getByRole('heading',{name:'Tổng quan công việc gia đình',exact:true})).toBeVisible();await expect(home.getByRole('button',{name:bill.name,exact:true})).toBeVisible();const range={fromDate:bill.date,toDateExclusive:new Date(Date.parse(bill.date+'T00:00:00.000Z')+30*86400000).toISOString().slice(0,10),timezone:bill.clock.timezone},native=await request(page,'productivity/family-overview','POST',{range});expect(native.status).toBe(200);for(const key of['active','myTasks','q2','waitingReview'])await expect(home.locator('[data-family-count="'+key+'"]').first()).toHaveText(String(native.body.tasks[key]));await home.locator('[data-family-task]').first().click();await expect(drawer(page)).toBeVisible();await drawer(page).getByRole('button',{name:'Đóng',exact:true}).click();await page.getByTestId('task-projections').getByRole('button',{name:'Lịch công việc',exact:true}).click();const calendar=page.getByTestId('family-finance-calendar');await expect(calendar.getByRole('button',{name:bill.name,exact:true})).toBeVisible();await expect(calendar).toContainText('12.345');expect(await balance(page,seed.familyFixture.cashAccountId,before)).toEqual(amount);await calendar.getByRole('button',{name:bill.name,exact:true}).click();await expect(page.getByRole('textbox',{name:'Tên lịch',exact:true})).toHaveValue(bill.name);
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ^ Error: expect(locator).toHaveValue(expected) failed
  19 | });
  20 | 
  21 | test('I02 overview current account revocation masks a held old joined response and child sees no financial labels or counts',async({page})=>{
  22 |  const admin=await login(page),account=await request(page,'wallet/accounts','POST',{expectedRevision:0,input:{name:'PRIVATE_I02_OVERVIEW_CASH',type:'cash',currency:'VND',openingMinor:'10000',openingDate:'2026-01-01',accessMode:'private'}});expect(account.status).toBe(200);const id=account.body.account.id;expect((await request(page,'wallet/accounts/'+id+'/grants/browser-member','PUT',{expectedRevision:1,permission:'contribute'})).status).toBe(200);await login(page,'member');const bill=await scheduleForOverview(page,'member',id);await page.goto('/?tab=dashboard');const home=page.getByTestId('family-overview');await expect(home).toContainText('PRIVATE_I02_OVERVIEW_CASH');let captured=false,delivered=false,release=()=>{};const held=new Promise<void>(resolve=>{release=resolve;});await page.route('**/api/productivity/family-overview',async route=>{if(captured){await route.continue();return;}const response=await route.fetch();expect(response.status()).toBe(200);expect(await response.text()).toContain('PRIVATE_I02_OVERVIEW_CASH');captured=true;await held;await route.fulfill({response});delivered=true;});await home.getByRole('button',{name:'Thử lại',exact:true}).click();await expect.poll(()=>captured).toBe(true);expect((await request(page,'wallet/accounts/'+id+'/grants/browser-member','DELETE',{expectedRevision:2},admin)).status).toBe(200);await expect(home).not.toContainText('PRIVATE_I02_OVERVIEW_CASH');release();await expect.poll(()=>delivered).toBe(true);await expect(home).not.toContainText('PRIVATE_I02_OVERVIEW_CASH');await expect(home.getByRole('button',{name:bill.name,exact:true})).toHaveCount(0);await login(page,'child');await page.goto('/?tab=dashboard');const child=page.getByTestId('family-overview');await expect(child.getByRole('heading',{name:'Tổng quan công việc gia đình',exact:true})).toBeVisible();await expect(child).not.toContainText(bill.name);await expect(child).not.toContainText('PRIVATE_I02_OVERVIEW_CASH');await expect(child.locator('[data-family-due]')).toHaveCount(0);
  23 | });
  24 | 
  25 | test('I02 linked-source global search opens current Wallet record and overview fits390px in both themes',async({page})=>{
  26 |  await login(page);const task=await create(page,'Synthetic I02 search source'),draft=(await request(page,'productivity/tasks/'+task.id+'/wallet-payment-draft')).body,note='Synthetic I02 linked search 中文',confirmed=await request(page,'productivity/tasks/'+task.id+'/wallet-payment','POST',{expectedRevision:0,input:{taskId:task.id,taskRevision:task.revision,confirmed:true,payment:{kind:'expense',accountId:seed.familyFixture.cashAccountId,money:{minor:'7',currency:'VND'},effectiveDate:draft.payment.effectiveDate,timezone:draft.payment.timezone,note}}});expect(confirmed.status,JSON.stringify(confirmed.body)).toBe(200);await page.getByRole('button',{name:'Tìm kiếm toàn cục',exact:true}).click();const search=page.getByRole('dialog');await search.getByRole('textbox').fill('linked search');await search.getByRole('button').filter({hasText:note}).click();await expect(page.getByRole('region',{name:'Chi tiết ghi chép',exact:true})).toContainText(note);await page.setViewportSize({width:390,height:844});for(const theme of['light','dark']){await page.evaluate(theme=>localStorage.setItem('family_theme',theme),theme);await page.goto('/?tab=dashboard');const home=page.getByTestId('family-overview');await expect(home.locator('[data-family-count="active"]')).toBeVisible();await home.scrollIntoViewIfNeeded();expect(await home.evaluate(element=>element.scrollWidth<=element.clientWidth&&element.getBoundingClientRect().right<=innerWidth)).toBe(true);await page.screenshot({path:path.join('reports/family',test.info().project.name,'overview-390-'+theme+'.png')});}
  27 | });
  28 | 
  29 | test('I02 explicit Wallet locale controls Task payment parsing without changing app language or confirming money',async({page})=>{
  30 |  await login(page);const settings=await request(page,'wallet/settings');expect(settings.status).toBe(200);expect((await request(page,'wallet/settings','PUT',{expectedRevision:settings.body.revision,input:{...settings.body.settings,locale:'en-US'}})).status).toBe(200);const task=await create(page,'Synthetic I02 exact locale payment');await page.reload();await open(page,task);await panel(page).getByRole('button',{name:'Chuẩn bị chi khoản từ công việc',exact:true}).click();await panel(page).getByRole('button',{name:'Tài khoản ghi chi',exact:true}).click();await page.getByRole('option',{name:'Synthetic family USD · USD',exact:true}).click();await panel(page).getByRole('textbox',{name:'Số tiền ghi chi',exact:true}).fill('1.23');await panel(page).getByRole('button',{name:'Xem lại khoản chi riêng',exact:true}).click();const review=panel(page).getByRole('region',{name:'Xem lại khoản chi riêng',exact:true});await expect(review).toContainText('$1.23');await review.getByRole('button',{name:'Hủy',exact:true}).click();expect((await request(page,'productivity/domain-links?kind=task&id='+task.id)).body.total).toBe(0);
  31 | });
  32 | 
```