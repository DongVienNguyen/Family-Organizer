# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: collaboration.spec.ts >> P12 current grant revocation purges private comment draft/history through real SSE and direct HTTP refuses its body
- Location: tests/e2e/collaboration.spec.ts:23:1

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: getByRole('button', { name: 'Lịch công việc', exact: true })
Expected: enabled
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" getByRole('button', { name: 'Lịch công việc', exact: true }) with timeout 10000ms
  - waiting for getByRole('button', { name: 'Lịch công việc', exact: true })

```

```yaml
- main:
  - paragraph: Đang chuẩn bị phiên…
```

# Test source

```ts
  1  | import {test as base,expect,type Page} from '@playwright/test';
  2  | import {installOfflineNetworkBoundary} from './offline-network-boundary.js';
  3  | import fs from 'node:fs';
  4  | import path from 'node:path';
  5  | import {createHash} from 'node:crypto';
  6  | const seed=JSON.parse(process.env.FO_COLLABORATION_SEED??'null');
  7  | const test=base.extend<{boundary:void}>({boundary:[async({context,page,baseURL},use)=>{if(!baseURL||!seed?.synthetic||seed.productivityVersion!==13)throw Error('Owned synthetic collaboration fixture required');const external:string[]=[],errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));await installOfflineNetworkBoundary(context,baseURL,external);await context.addInitScript(()=>{localStorage.setItem('family_lang','vi');});await use();expect(external).toEqual([]);expect(errors).toEqual([]);},{auto:true}]});
  8  | test.beforeAll(async({browser,browserName})=>{const folder=path.join('reports/collaboration',browserName);fs.mkdirSync(folder,{recursive:true});fs.writeFileSync(path.join(folder,'runtime.json'),JSON.stringify({browserName,browserVersion:browser.version(),executableSha256:createHash('sha256').update(fs.readFileSync(browser.browserType().executablePath())).digest('hex'),node:process.version,platform:process.platform,architecture:process.arch}));});
> 9  | async function login(page:Page,role='admin'){const response=await page.request.post('/api/auth/login',{data:{username:'browser-'+role,password:'synthetic-browser-password'},maxRedirects:0});expect(response.status()).toBe(200);const body=await response.json();expect(body.user.id).toBe('browser-'+role);const origin=new URL(response.url()).origin;await page.context().setStorageState({cookies:[],origins:[{origin,localStorage:[{name:'family_token',value:body.token},{name:'family_lang',value:'vi'},{name:'family_theme',value:'light'}]}]});await page.goto('/?tab=tasks');await expect(page.getByRole('button',{name:'Lịch công việc',exact:true})).toBeEnabled();return body.token as string;}
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ^ Error: expect(locator).toBeEnabled() failed
  10 | async function request(page:Page,path:string,method='GET',body?:unknown){return page.evaluate(async({path,method,body})=>{const response=await fetch('/api/'+path,{method,headers:{Authorization:'Bearer '+localStorage.getItem('family_token'),'Content-Type':'application/json','x-request-id':crypto.randomUUID()},...(body===undefined?{}:{body:JSON.stringify(body)})});return {status:response.status,body:await response.json()};},{path,method,body});}
  11 | 
  12 | const drawer=(page:Page)=>page.getByRole('dialog',{name:'Chi tiết công việc',exact:true});
  13 | async function open(page:Page,task:any){const search=page.getByRole('textbox',{name:'Tìm trong công việc',exact:true});await search.fill(task.title);await page.getByRole('button',{name:'Tìm',exact:true}).click();await page.locator('button[data-task-id="'+task.id+'"]').click();await expect(drawer(page)).toBeVisible();}
  14 | async function create(page:Page,title:string,listId='legacy-family',isShared=true){const response=await request(page,'productivity/tasks','POST',{expectedRevision:0,input:{listId,title,isShared}});expect(response.status).toBe(200);return response.body.task;}
  15 | async function privateList(page:Page,title:string){const response=await request(page,'productivity/lists','POST',{expectedRevision:0,input:{title,isShared:false}});expect(response.status).toBe(200);return response.body.list;}
  16 | test('P12 comment lost ACK retains exact revision body and nonce across Calendar navigation and saves one Unicode comment/mention',async({page})=>{
  17 |  await login(page);const task=await create(page,'Synthetic P12 comment lost ACK');await open(page,task);const text='Synthetic Tiếng Việt 中文 🧪 exact comment',panel=()=>drawer(page).getByRole('region',{name:'Bình luận',exact:true});await panel().getByRole('textbox',{name:'Nội dung bình luận',exact:true}).fill(text);await panel().getByRole('checkbox',{name:'Synthetic member',exact:true}).check();const calls:{body:string;key:string}[]=[];await page.route('**/api/productivity/tasks/'+task.id+'/comments',async route=>{if(route.request().method()!=='POST'){await route.continue();return;}calls.push({body:route.request().postData()??'',key:route.request().headers()['x-request-id']});if(calls.length===1){expect((await route.fetch()).status()).toBe(200);await route.abort('failed');}else await route.continue();});await panel().getByRole('button',{name:'Gửi bình luận',exact:true}).click();await expect(panel().getByRole('button',{name:'Kiểm tra kết quả bình luận',exact:true})).toBeEnabled();await expect(panel().getByRole('textbox',{name:'Nội dung bình luận',exact:true})).toBeDisabled();await drawer(page).getByRole('button',{name:'Đóng',exact:true}).click();await page.getByTestId('task-projections').getByRole('button',{name:'Lịch công việc',exact:true}).click();await page.getByTestId('task-projections').getByRole('button',{name:'Danh sách',exact:true}).click();await open(page,task);await panel().getByRole('button',{name:'Kiểm tra kết quả bình luận',exact:true}).click();await expect(panel().getByRole('textbox',{name:'Nội dung bình luận',exact:true})).toHaveValue('');expect(calls).toHaveLength(2);expect(calls[1]).toEqual(calls[0]);const comments=await request(page,'productivity/tasks/'+task.id+'/comments');expect(comments.body.totalUnique).toBe(1);expect(comments.body.items[0].content).toBe(text);expect((await request(page,'productivity/tasks/'+task.id)).body.task.revision).toBe(2);expect((await request(page,'finance')).body.transactions??[]).toHaveLength(0);
  18 |  await page.setViewportSize({width:390,height:844});for(const theme of ['light','dark']){await drawer(page).getByRole('button',{name:'Đóng',exact:true}).click();await page.evaluate(theme=>localStorage.setItem('family_theme',theme),theme);await page.reload();await open(page,task);await expect(panel().getByText(text,{exact:true})).toBeVisible();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBe(true);expect(await page.evaluate(()=>document.documentElement.classList.contains('dark'))).toBe(theme==='dark');await panel().screenshot({path:'reports/collaboration/'+test.info().project.name+'/comments-390-'+theme+'.png'});}
  19 | });
  20 | test('P12 sharing reviews the existing member permission and retries one unchanged grant after a lost ACK and drawer navigation',async({page})=>{
  21 |  await login(page);const list=await privateList(page,'Synthetic P12 private list'),task=await create(page,'Synthetic P12 sharing review',list.id,false);await open(page,task);const panel=()=>drawer(page).getByRole('region',{name:'Chia sẻ danh sách',exact:true});await panel().getByRole('button',{name:'Thành viên',exact:true}).click();await page.getByRole('option',{name:'Synthetic member',exact:true}).click();await panel().getByRole('button',{name:'Quyền danh sách',exact:true}).click();await page.getByRole('option',{name:'Đóng góp',exact:true}).click();const calls:any[]=[];await page.route('**/api/productivity/lists/'+list.id+'/grant',async route=>{calls.push({body:route.request().postData(),key:route.request().headers()['x-request-id']});if(calls.length===1){expect((await route.fetch()).status()).toBe(200);await route.abort('failed');}else await route.continue();});await panel().getByRole('button',{name:'Lưu',exact:true}).click();const confirm=page.getByRole('dialog',{name:'Xác nhận quyền danh sách',exact:true});await expect(confirm).toContainText('Không cấp riêng → Đóng góp');await confirm.getByRole('button',{name:'Lưu',exact:true}).click();await expect(panel().getByRole('button',{name:'Kiểm tra kết quả chia sẻ',exact:true})).toBeEnabled();await drawer(page).getByRole('button',{name:'Đóng',exact:true}).click();await open(page,task);await panel().getByRole('button',{name:'Kiểm tra kết quả chia sẻ',exact:true}).click();await expect(panel().getByText('Đã lưu quyền danh sách.',{exact:true})).toBeVisible();expect(calls).toHaveLength(2);expect(calls[1]).toEqual(calls[0]);expect(JSON.parse(calls[0].body)).toEqual({expectedRevision:1,input:{userId:'browser-member',permission:'write'}});const current=await request(page,'productivity/lists/'+list.id+'/grants');expect(current.body.list.revision).toBe(2);expect(current.body.grants).toEqual([{userId:'browser-member',permission:'write'}]);expect((await request(page,'productivity/tasks/'+task.id)).body.task.revision).toBe(1);
  22 | });
  23 | test('P12 current grant revocation purges private comment draft/history through real SSE and direct HTTP refuses its body',async({page})=>{
  24 |  const admin=await login(page),list=await privateList(page,'SYNTHETIC_P12_PRIVATE_LIST'),task=await create(page,'SYNTHETIC_P12_PRIVATE_TASK',list.id,false);expect((await request(page,'productivity/lists/'+list.id+'/grant','POST',{expectedRevision:1,input:{userId:'browser-member',permission:'write'}})).status).toBe(200);expect((await request(page,'productivity/tasks/'+task.id+'/comments','POST',{expectedRevision:1,input:{content:'SYNTHETIC_P12_PRIVATE_HISTORY'}})).status).toBe(200);await login(page,'member');await open(page,task);await expect(drawer(page).getByText('SYNTHETIC_P12_PRIVATE_HISTORY',{exact:true})).toBeVisible();await drawer(page).getByRole('textbox',{name:'Nội dung bình luận',exact:true}).fill('SYNTHETIC_P12_UNSENT_COMMENT');const revoke=await page.request.post('/api/productivity/lists/'+list.id+'/grant',{headers:{Authorization:'Bearer '+admin,'x-request-id':crypto.randomUUID()},data:{expectedRevision:2,input:{userId:'browser-member',permission:null}}});expect(revoke.status()).toBe(200);await expect(page.getByText('SYNTHETIC_P12_PRIVATE_TASK',{exact:true})).toHaveCount(0);await expect(page.getByText('SYNTHETIC_P12_PRIVATE_HISTORY',{exact:true})).toHaveCount(0);await expect(page.getByRole('textbox',{name:'Nội dung bình luận',exact:true})).toHaveCount(0);for(const suffix of ['/comments','/activities']){const hidden=await request(page,'productivity/tasks/'+task.id+suffix);expect(hidden.status).toBe(404);expect(JSON.stringify(hidden.body)).not.toContain(task.id);expect(JSON.stringify(hidden.body)).not.toContain('SYNTHETIC_P12_PRIVATE_HISTORY');}
  25 | });
  26 | 
```