from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
root=Path('/workspace/Family-Organizer');ev=Path('/workspace/family-evidence');out=root/'docs/engineering/evidence/p13-content';out.mkdir(exist_ok=True)
sha='627b5dcb855162cfb2506d1d97a6c41d18a58f0c';production='f9fb6989ff485ae02cacb1743ba25976f754c11e';base='51f7d06';fullParent='ceafc797038ce0471d9615dd0edb93fadcbad00b'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==sha
h=lambda value:hashlib.sha256(value).hexdigest()
full=json.loads((ev/'p13-content-full.json').read_text());parent=json.loads((ev/'p13-template-full.json').read_text());assert full['success'] and full['numTotalTests']==full['numPassedTests']==8630 and len(full['testResults'])==532
assert full['numFailedTests']==full['numPendingTests']==full.get('numTodoTests',0)==0
cases=ET.parse(ev/'p13-content-full.xml').getroot().findall('.//testcase');assert len(cases)==8630 and not any(case.find(tag)is not None for case in cases for tag in ['failure','error','skipped'])
def identities(report):
 result=collections.Counter()
 for file in report['testResults']:
  name=str(Path(file['name']).relative_to(root))
  for case in file['assertionResults']:
   assert case['status']=='passed';title=case['fullName']
   if name=='server/recoveryRetention.test.ts':title=re.sub(r'/tmp/fo test synthetic [A-Za-z0-9]+(?=/|$)','/tmp/fo test synthetic <fixture>',title)
   result[(name,title)]+=1
 return result
before,after=identities(parent),identities(full);assert sum(before.values())==8595 and not before-after,before-after
assert sum((after-before).values())==35
followupFiles=subprocess.check_output(['git','diff','--name-only',production,sha],cwd=root,text=True).splitlines();assert followupFiles and all(name.startswith('tests/e2e/')for name in followupFiles)
for stem in ['p13-content-full','p13-content-lint-final','p13-content-build-final','p13-content-browser-final','p13-content-lint-actor-final','p13-content-build-actor-final','p13-content-browser-actor-final','p13-content-parent-templates-actor-final','p13-content-parent-notifications-actor-final','p13-content-parent-collaboration-actor-final','p13-content-parent-calendar-actor-final']:assert(ev/(stem+'.exit')).read_text().strip()=='0',stem
browser={}
for feature,count,version in [('content',4,16),('templates',3,15),('notifications',4,14),('collaboration',3,13),('calendar',4,13)]:
 folder=root/'reports'/feature/'chromium';report=json.loads((folder/'browser.json').read_text());fixture=json.loads((folder/'fixture.json').read_text());assert report['stats']['expected']==count and report['stats']['unexpected']==report['stats']['flaky']==report['stats']['skipped']==0
 assert fixture['commitSha']==sha and fixture['nodeVersion']=='v24.21.0' and fixture['platform']=='linux' and fixture['seed']['productivityVersion']==version and fixture['seed']['synthetic']
 assert all(fixture[key]for key in ['databaseClosed','fixtureRemoved','legacyPreserved']) and fixture['integrity']=='ok' and fixture['error']is None and not fixture['networkAttempts'] and fixture['serverExitCode']==fixture['browserExitCode']==0 and fixture['browserSignal']==fixture['serverSignal']==None
 for key,name in [('server','dist/server.cjs'),('index','dist/index.html')]:assert fixture['build'][key]==h((root/name).read_bytes())
 def check(suites):
  for suite in suites:
   for spec in suite.get('specs',[]):
    for test in spec['tests']:assert test['status']=='expected' and len(test['results'])==1 and test['results'][0]['status']=='passed'
   check(suite.get('suites',[]))
 check(report['suites']);cases=ET.parse(folder/'browser.junit.xml').getroot().findall('.//testcase');assert len(cases)==count and not any(case.find(tag)is not None for case in cases for tag in ['failure','error','skipped'])
 browser[feature]={'passed':count,'firstAttemptsOnly':True,'fixture':fixture}
files=subprocess.check_output(['git','diff','--name-only',base,sha],cwd=root,text=True).splitlines();source={name:h(subprocess.check_output(['git','show',sha+':'+name],cwd=root))for name in files}
for name,digest in source.items():assert h((root/name).read_bytes())==digest,name
for name in ['schema.ts','migrate.ts','tagSchema.ts','pinSchema.ts','viewSchema.ts','matrixSchema.ts','boardSchema.ts','seriesSchema.ts','occurrenceSchema.ts','occurrenceSkipSchema.ts','legacyCutoverSchema.ts','notificationSchema.ts','templateSchema.ts']:
 assert subprocess.check_output(['git','show',base+':server/productivity/'+name],cwd=root)==subprocess.check_output(['git','show',sha+':server/productivity/'+name],cwd=root),name
assert h((root/'package-lock.json').read_bytes())=='17e305b217c2dbd6543d66e2e600c20251425c5b4d0eb66fa903cbd13ecc6ec7'
retained={}
def retain(file:Path,name:str):
 data=file.read_bytes();target=out/(name+'.gz');target.write_bytes(gzip.compress(data,mtime=0));retained[name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes()),'uncompressedSha256':h(data)}
for file in sorted(ev.glob('p13-content-*')):
 if file.is_file()and file.suffix in ['.json','.xml','.log','.exit','.sha']:retain(file,file.name)
retain(ev/'publish-p13-content.py','publish-p13-content.py')
for feature in browser:
 folder=root/'reports'/feature/'chromium'
 for name in ['browser.json','browser.junit.xml','fixture.json','runtime.json','run.log','server.log']:retain(folder/name,feature+'-final-'+name)
for prefix in ['p13-content-browser-first-artifacts','p13-content-collaboration-session-failure','p13-content-collaboration-session-diagnostic-artifacts']:
 for file in (ev/prefix).rglob('*'):
  if file.is_file()and file.suffix in ['.json','.xml','.log','.md','.zip','.png']:retain(file,prefix+'-'+str(file.relative_to(ev/prefix)).replace('/','__'))
for file in (root/'reports/content/chromium').glob('content-390-*.png'):
 target=out/file.name;target.write_bytes(file.read_bytes());retained[file.name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes()),'visuallyInspected':True}
proof={'taskId':'P13 canonical Notes and typed Task links functional slice','sourceCommit':sha,'productionSource':production,'fullRegressionSource':production,'prUrl':None,'ciRunUrl':None,'qualification':'Cloud only; final composed Windows and controlled pilot remain','fullRegression':{'passed':8630,'files':532,'junitCases':8630,'failed':0,'skipped':0,'todo':0,'parentPassed':8595,'added':35,'removed':0,'note':'All8595 template-base cases retained; added template-panel1, Note-identity1 and content33. Full run is f9fb698.627b5dc changes E2E fixtures only.'},'lintExitCode':0,'buildExitCode':0,'browser':browser,'sourceFiles':source,'fixtureOnlyFollowup':followupFiles,'schema':{'explicitPilotVersion':16,'defaultVersion':6,'frozen1to15Preserved':True,'packageCapsChanged':False},'review':{'independent':False,'scope':'Author review of canonical ownership, source/destination/current both-end ACL before receipt, retained source/history/grants, Notes FK-preserving writes/restore, trusted media source pairing, native invalid snapshot checks, session/late-confirm fencing, actual revocation DOM and eighteen final journeys.'},'findings':['Conversion is intentionally non-destructive: create a private linked counterpart and retain the original canonical Task/Note and history. Notes remain in legacy canonical APIs; no new Markdown store or synchronization engine. This choice is explicit in confirmation/UI.','Task-to-Note refuses active rewarded/pending/recurring Tasks until a separate archive policy. Accepted past rewards are neither repeated nor reversed; a real native completion/grant fixture verifies original Task/history/ledger/users unchanged. Note-to-Task creates fresh private unfinished Task without due/assignee/reward and refuses oversized text without truncation.','Two actual native failures showed unrelated Note edits and shared snapshot restore deleting typed links through FK cascade; a third missing-row error followed that failed restoration. The existing users retained-ID write path now also upserts Notes and deletes only removed IDs, inside the same gateway. Actual canonical Note deletion still prunes only its own links.','An actual Chromium revocation test showed a disabled button still exposing a revoked Note title even though the API returned an empty authorized list. Rendering now filters current peer scope before labels and re-fetches on current Note IDs; original no-title assertion remains.','One parent Collaboration actor bootstrap stopped in privacy cleanup before Member UI, with native HTTP200 and no functional-page assertion reached. The failed DOM/network/trace and read-only diagnostic run are retained. Synthetic actor bootstrap now unloads the previous app document before replacing storage; language init is origin-bound, real privacy worker/session startup/readiness/network/privacy assertions and deadlines remain. All eighteen final journeys pass first-attempt on clean owned fixtures. This does not claim a production auth fix.','The first additional past-reward test selected a nonexistent ledger.type field; the selector now uses the actual positive points model while retaining one-grant and exact ledger/users/history assertions. The failed report is retained. No parent assertions/skips/retries/deadlines were weakened.'],'retainedEvidence':retained,'remaining':['P13 files20MiB, JSON/CSV/ICS staging/commit/undo/export still pending.','P14–P18, remaining Wallet/W18/M1/I02/I03 and final comprehensive Windows are not complete.','New Calendar/Collaboration/Notifications/Templates/Content harnesses are not yet mandatory Windows CI; whole parent42Productivity/nativeTouch/65Wallet/three engines and Windows Node22/24/package/service/performance have not run for this group.','No new source PR/Actions run, release/tag/VPS/PC runner. ActualServer2019 R02 separate and unrun.']}
(root/'docs/engineering/evidence/p13-content-development.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
(root/'docs/engineering/productivity-content.md').write_text('''# P13 canonical Notes and typed Task links

Production sourcef9fb698 adds explicit pilot16; fixture follow-up627b5dc changes
E2E setup/diagnostics only. Default6, frozen1–15 migrations and Windows package
caps remain unchanged. P13 files/import/export and the full master remain open.

The Task drawer and existing canonical Notes reader create a linked private
counterpart. Confirmation states that the original content/history is retained.
There is no second Notes/Markdown store or automatic synchronization. A Task with
active rewards, pending approval or active recurrence cannot convert before a
separate archive policy. An accepted past grant remains unchanged. A Note creates
a fresh unfinished Task with no default due, assignee or reward; text over the
Task body bound is rejected without truncation. Both source and destination
versions/authority are fenced, including before cached receipts. Typed links
resolve current ACL at both ends before title/count, and copied records retain
their own explicitly authorized new ownership.

The SQLite Notes path now preserves retained IDs, using the existing users
upsert pattern inside I01. DELETE/reinsert of the whole collection used to cascade
away all links on unrelated edits and restore; actual failing native reports
are retained. Deleting a Note still prunes its own links while retaining a copied
Task. The shared snapshot/inspection/bootstrap validates16 tables, native FK and
direction provenance; no replacement restore owner is introduced.

Trusted media inheritance pairs one currently authorized canonical source with
its private new counterpart and verifies current/before bindings. Generic foreign
attachment copying remains denied. Current Task/Note visibility also fences the
browser's original command/revision/key through lost ACK/navigation. The Notes
reader derives content from current props rather than retaining an old private
object. An actual revocation browser test caught a disabled stale Note label;
labels now require current peer scope before rendering.

Full8630tests532files/matching JUnit, zero failed/skipped/todo, at f9fb698; all8595
prior template-base cases plus35 retained. Lint/build0. The fixture-only follow-up
has18/18 same-source/build first-attempt Chromium journeys: content4/templates3/
notifications4/collaboration3/calendar4, offline, owned16/15/14/13/13 fixtures,
normal stop, integrity, closed handles and cleanup. Both390px themes were viewed.
One parent Member bootstrap stall and read-only diagnostics are retained; actors
now load on a fresh document before storage replacement. Privacy worker/session,
readiness, network, source-privacy assertions and deadlines are unchanged. This
is a test bootstrap change, not a claimed production auth fix.

[Raw proof](evidence/p13-content-development.json). Author review only; no new-
source PR/Windows run. Final Windows qualification must compose all parent suites
and these new harnesses; Node22/24/package/service/performance and actualServer2019
R02 remain separate. No release/tag/VPS access or PC runner.
''')
p=root/'docs/engineering/implementation-status.md';s=p.read_text();marker='## Current direction — 2026-10-18 (UTC)\n';entry=f'''\n**P13 canonical Notes/Task links functional slice:** production `{production}`,\nfixture-only follow-up `{sha}`. Explicit16 retains canonical Notes and original\nTask/Note content/history while creating reviewed private counterparts; current\nboth-end ACL, I01 receipt/version fencing, FK-preserving Notes writes/restore,\ntrusted media inheritance and real accepted-grant retention verified. Actual\nnative cascade loss and browser revoked-label failures retained and fixed.\nFull8630tests532files/JUnit atf9fb698, zero failures/skips/todo, all8595parents +35;\nlint/build0. Final18/18 same627b5dc-build Chromium journeys (content4/templates3/\nnotifications4/collaboration3/calendar4), first attempts/offline/owned fixtures/\nnormal stop/integrity/closed/cleaned;390themes viewed. Actor-bootstrap failed\nparent run and read-only diagnostics retained; setup unloads the previous document\nbefore storage replacement, preserving all functional/privacy/readiness assertions.\nNo full-suite claim for fixture-only627b5dc. [Details](productivity-content.md),\n[proof](evidence/p13-content-development.json). PR URL/CI run URL:none for source;\nbackup branch, author review only. Next P13 files/import/export, then remaining\nP/W18/M1/I02/I03/final composed Windows. No release/tag/VPS/PC runner.\n''';assert '**P13 canonical Notes/Task links functional slice:**'not in s;p.write_text(s.replace(marker,marker+entry,1))
print(json.dumps({'source':sha,'production':production,'full':8630,'files':532,'browsers':18,'retained':len(retained)}))
