from pathlib import Path
import json,gzip,hashlib,subprocess,tarfile,io
r=Path('/workspace/Family-Organizer');e=Path('/workspace/family-evidence');d=r/'docs/engineering/evidence';proof=json.loads((e/'pr136-38987528125-qualified.json').read_text());merged=json.loads((e/'pr136-merged.json').read_text());assert merged['state']=='MERGED'and merged['headRefOid']==proof['sourceCommit']and merged['mergeCommit']['oid']=='036aecb9cf4b7050c3922de4c5104cb119d37fdd';assert (e/'pr136-merge.exit').read_text().strip()=='0';proof['merge']=merged;proof['mainAfterMerge']=merged['mergeCommit']['oid'];h=lambda b:hashlib.sha256(b).hexdigest();retained={}
for file in [e/'qualify-pr136.py',e/'publish-pr136-final.py',e/'pr136-premerge.json',e/'pr136-merged.json',e/'pr136-merge.log',e/'pr136-merge.exit',e/'pr136-38987528125-qualified.json',e/'pr136-qualification-eol-note.json',e/'pr136-changed-paths.txt',e/'pr136-38987528125-log.exit',e/'pr136-38987528125-download.exit',e/'pr136-38987528125-logs.exit']:
 target=d/(file.name+'.gz');target.write_bytes(gzip.compress(file.read_bytes(),mtime=0));retained[file.name]={'path':str(target.relative_to(r)),'sha256':h(target.read_bytes())}
source=e/'pr136-38987528125-logs.zip';target=d/'pr136-final-windows-logs.zip';target.write_bytes(source.read_bytes());retained['rawLogsZip']={'path':str(target.relative_to(r)),'sha256':h(target.read_bytes())}
a=e/'pr136-38987528125-artifacts';target=d/'pr136-final-windows-reports.tar.gz'
with target.open('wb')as output,gzip.GzipFile(fileobj=output,mode='wb',mtime=0)as compressed,tarfile.open(fileobj=compressed,mode='w')as archive:
 for name in proof['rawArtifacts']:
  file=a/name;raw=file.read_bytes();assert h(raw)==proof['rawArtifacts'][name]['sha256'];info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(raw))
retained['rawReportsArchive']={'path':str(target.relative_to(r)),'sha256':h(target.read_bytes()),'bytes':target.stat().st_size,'files':len(proof['rawArtifacts'])}
proof['retainedEvidence']=retained;proof['review']['followup']='Final fixtures only substitute real-session preparation for C27/C31 and owned Tasks deep link while retaining role/workspace/semantic assertions. Final29sourcehashes match the sealed author review plus documented repairs. No independent review claimed.';(d/'p09-pr136-final.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n')
p=r/'docs/engineering/implementation-status.md';s=p.read_text();anchor='## Current direction — 2026-10-18 (UTC)\n\n';entry='''**P09 PR136 accepted and merged (2026-10-18):** reviewed HEAD
`7e59abd0c682acf4dba80a7830e54c7e2e052a33`,
[PR136](https://github.com/DongVienNguyen/Family-Organizer/pull/136),
[CI38987528125](https://github.com/DongVienNguyen/Family-Organizer/actions/runs/38987528125).
All8checks success. Re-read16raw logs/14245lines and323reports from7artifacts:
each Node22/24 has6032tests326files/matchingJUnit/no failures-skips-todo/native0;
45legacy+126Productivity(42perengine)+1nativeTouch=172firstattempts, no retries/
flaky/skips; actual touch pointer trusted. Package/service reports and native
exits0 retained. Windows CRLF lock hash is derived exactly from the Git LF blob;
artifacts remain unchanged. No package ZIP was downloaded or executed in Cloud.
Previously closed26source SELF review +3 documented fixture repairs bind final29
source hashes; PR has no unresolved review threads. Author review, not independent.
Merge main `036aecb9cf4b7050c3922de4c5104cb119d37fdd` used the protected normal
merge path with exact-head matching, no admin bypass. Feature branch then merged
origin/main with zero tree changes. [Proof](evidence/p09-pr136-final.json).
The new feature-first P/W/I source is NOT Windows-qualified by this older run.
Any automatic main CI is separate; continue P12 and remaining features before the
final composed Windows batch. FullP09/M1/master and actualServer2019R02 remain
incomplete; no release/tag/VPS access or deployment.

''';assert '**P09 PR136 accepted and merged (2026-10-18):**'not in s;p.write_text(s.replace(anchor,anchor+entry,1));print({'head':proof['sourceCommit'],'merge':merged['mergeCommit']['oid'],'reports':len(proof['rawArtifacts']),'archiveBytes':target.stat().st_size})
