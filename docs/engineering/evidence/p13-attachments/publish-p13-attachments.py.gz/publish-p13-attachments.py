from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
root=Path('/workspace/Family-Organizer');ev=Path('/workspace/family-evidence');out=root/'docs/engineering/evidence/p13-attachments';out.mkdir(exist_ok=True)
sha='08773891665ef6eff59e7886f0aa1f56c1808c2c';base='78bef65e6570a4c0a9cbfac1c030642a0d3988ef';h=lambda data:hashlib.sha256(data).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==sha
full=json.loads((ev/'p13-attachment-full.json').read_text());assert full['success'] and full['numTotalTests']==full['numPassedTests']==8675 and len(full['testResults'])==539 and full['numFailedTests']==full['numPendingTests']==full.get('numTodoTests',0)==0
cases=ET.parse(ev/'p13-attachment-full.junit.xml').getroot().findall('.//testcase');assert len(cases)==8675 and not any(c.find(tag)is not None for c in cases for tag in ['failure','error','skipped'])
def identities(report):
 result=collections.Counter()
 for file in report['testResults']:
  name=str(Path(file['name']).relative_to(root))
  for c in file['assertionResults']:
   assert c['status']=='passed';title=c['fullName']
   if name=='server/recoveryRetention.test.ts':title=re.sub(r'/tmp/fo test synthetic [A-Za-z0-9]+(?=/|$)','/tmp/fo test synthetic <fixture>',title)
   result[(name,title)]+=1
 return result
before=identities(json.loads((ev/'p13-content-full.json').read_text()));after=identities(full);assert sum(before.values())==8630 and not before-after,before-after
assert sum((after-before).values())==45
for stem in ['p13-attachment-full','p13-attachment-build','p13-attachment-browser-first','p13-attachment-backend-final','p13-attachment-ui-functional']+[f'p13-attachment-parent-{feature}'for feature in ['content','templates','notifications','collaboration','calendar']]:assert (ev/(stem+'.exit')).read_text().strip()=='0',stem
assert 'error TS'not in(ev/'p13-attachment-lint-final.log').read_text()
browser={}
for feature,count,version in [('attachments',3,17),('content',4,16),('templates',3,15),('notifications',4,14),('collaboration',3,13),('calendar',4,13)]:
 folder=root/'reports'/feature/'chromium';report=json.loads((folder/'browser.json').read_text());fixture=json.loads((folder/'fixture.json').read_text());assert report['stats']['expected']==count and report['stats']['unexpected']==report['stats']['flaky']==report['stats']['skipped']==0
 assert fixture['commitSha']==sha and fixture['seed']['productivityVersion']==version and fixture['nodeVersion']=='v24.21.0' and fixture['platform']=='linux' and all(fixture[k]for k in ['synthetic','databaseClosed','fixtureRemoved','legacyPreserved']) and fixture['integrity']=='ok' and fixture['error']is None and not fixture['networkAttempts'] and fixture['serverExitCode']==fixture['browserExitCode']==0
 for key,name in [('server','dist/server.cjs'),('index','dist/index.html')]:assert fixture['build'][key]==h((root/name).read_bytes())
 def check(suites):
  for suite in suites:
   for spec in suite.get('specs',[]):
    for t in spec['tests']:assert t['status']=='expected' and len(t['results'])==1 and t['results'][0]['status']=='passed'
   check(suite.get('suites',[]))
 check(report['suites']);cases=ET.parse(folder/'browser.junit.xml').getroot().findall('.//testcase');assert len(cases)==count and not any(c.find(tag)is not None for c in cases for tag in ['failure','error','skipped'])
 browser[feature]={'passed':count,'firstAttemptsOnly':True,'fixture':fixture}
source={}
for name in subprocess.check_output(['git','diff','--name-only',base,sha],cwd=root,text=True).splitlines():
 data=subprocess.check_output(['git','show',sha+':'+name],cwd=root);assert(root/name).read_bytes()==data,name;source[name]=h(data)
for name in ['schema.ts','migrate.ts','tagSchema.ts','pinSchema.ts','viewSchema.ts','matrixSchema.ts','boardSchema.ts','seriesSchema.ts','occurrenceSchema.ts','occurrenceSkipSchema.ts','legacyCutoverSchema.ts','notificationSchema.ts','templateSchema.ts','contentSchema.ts']:
 assert subprocess.check_output(['git','show',base+':server/productivity/'+name],cwd=root)==subprocess.check_output(['git','show',sha+':server/productivity/'+name],cwd=root),name
assert h((root/'package-lock.json').read_bytes())=='17e305b217c2dbd6543d66e2e600c20251425c5b4d0eb66fa903cbd13ecc6ec7'
retained={}
def retain(file,name):
 data=file.read_bytes();target=out/(name+'.gz');target.write_bytes(gzip.compress(data,mtime=0));retained[name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes()),'uncompressedSha256':h(data)}
for file in sorted(ev.glob('p13-attachment-*')):
 if file.is_file()and file.suffix in ['.json','.xml','.log','.exit','.txt']:retain(file,file.name)
for feature in browser:
 for name in ['browser.json','browser.junit.xml','fixture.json','runtime.json','run.log','server.log']:retain(root/'reports'/feature/'chromium'/name,feature+'-final-'+name)
for file in(root/'reports/attachments/chromium').glob('attachments-390-*.png'):
 target=out/file.name;target.write_bytes(file.read_bytes());retained[file.name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes()),'visuallyInspected':True}
retain(ev/'publish-p13-attachments.py','publish-p13-attachments.py')
proof={'taskId':'P13 private Task attachments functional slice','sourceCommit':sha,'backendSource':'5e4715017344922b50dc2e3abfd74889fe3da2c4','prUrl':None,'ciRunUrl':None,'qualification':'Cloud only; final composed Windows pending','fullRegression':{'passed':8675,'files':539,'junitCases':8675,'failed':0,'skipped':0,'todo':0,'parentPassed':8630,'added':45,'removed':0},'lintExitCode':0,'buildExitCode':0,'browser':browser,'sourceFiles':source,'schema':{'explicitPilotVersion':17,'defaultVersion':6,'frozen1to16Preserved':True,'packageCapsChanged':False},'review':{'independent':False,'scope':'Author review of current Task ACL before receipts, raw byte limits, dedicated namespace denial, ownership/rollback/inode/digest, snapshots, retained unknown-ACK Blob/session fencing, actual download and revoked replay; no independent-review claim.'},'developmentFailures':['Initial three suites failed because implementation did not exist.','Initial 20MiB Buffer deep equality exhausted Vitest workers and exited1 despite misleading reporter success/pending counts. Never accepted. Native Buffer.compare still checks every byte; exact20MiB boundaries and same-length tail corruption assertions remain. No heap/timeout/retry increase.','Actual native generic media cleanup deleted a new private attachment. Dedicated case-insensitive _task_files guards now deny generic read/delete while retaining original media/Wallet receipt limits;134 related tests passed.','One new API fixture expected403 for generic media, while existing source concealment contract is404. Corrected fixture keeps exact404 and no-bytes assertions;32 backend cases passed.'], 'remaining':['P13 JSON/CSV/ICS actor-owned preview, commit, conditional undo and exports next.','P14–P18/remaining Wallet/W18/M1/I02/I03 and final Windows incomplete.','New six feature harnesses not yet wired into mandatory Windows. No new PR/Actions/package qualification for this source.','Server2019 R02 separate and unrun; no release/tag/VPS/PC runner.'],'retainedEvidence':retained}
(root/'docs/engineering/evidence/p13-attachments-development.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
(root/'docs/engineering/productivity-attachments.md').write_text('''# P13 private Task attachments

Source0877389 adds the Task drawer upload/download/delete flow and explicit
pilot17 metadata. Default6, frozen1–16 migrations and package capability13 remain
unchanged. React/Express/SQLite and the single I01 writer are retained.

PNG/JPEG/GIF/WebP/PDF files are limited to20MiB each and32 active files per Task.
Names follow Windows traversal/reserved-name/Unicode rules; actual bytes must
match MIME and extension. Auth/edit checks precede raw-body buffering. Uploads
use a local binary route, without base64/global JSON-limit changes. Downloads
require current Task scope and verify complete length/SHA/MIME before attachment
response. Files live in dedicated private _task_files storage; generic media
reads/deletion cannot access it. Existing image4MiB/PDF10MiB and Wallet limits
remain unchanged. No new dependency or lockfile change was needed.

Upload owns its stage/inode and rolls back only its own bytes with SQL failures.
Delete creates a tombstone inside I01 then removes only verified committed bytes.
Each operation increments Task revision/history once; it does not change due,
completion, rewards or approval. Current ACL precedes cached receipt replay.
Snapshot validation requires active metadata and exact bytes; deleted metadata
may omit retired bytes. Original restore/lifecycle owners remain in use.

The session keeps one immutable pending Blob/revision/key through navigation and
unknown ACK. Revocation/logout clears private bytes and filename metadata, fences
late responses and rejects stale confirmation. The drawer uses existing confirm
and inline feedback. Browser download verifies actual full bytes and UTF8 name.
Both390px light/dark screenshots were inspected.

Full8675tests539files/matchingJUnit, zero failed/skipped/todo, lint/build0 at
0877389; all8630 parent cases retained plus45. Same-build Chromium21/21 first
attempts (attachments3/content4/templates3/notifications4/collaboration3/calendar4)
with isolated17/16/15/14/13/13 fixtures, offline providers, normal stop, integrity,
closed handles and cleanup. Earlier development failures remain in
[raw proof](evidence/p13-attachments-development.json), including reporter OOM
and the actual generic-cleanup flaw. Author review only; no new Windows claim.

P13 import/export and remaining master tasks stay open. New feature harnesses
must join final composed Windows qualification before PR merge. Actual Windows
Server2019 acceptance is R02 and unrun. No release, tag or VPS access occurred.
''')
with(root/'docs/engineering/implementation-status.md').open('a')as file:file.write('''\n\n### P13 private Task attachments Cloud checkpoint (2026-10-18)\n\n- Source08773891665ef6eff59e7886f0aa1f56c1808c2c (backend5e471501), PR URL/CI run URL not created for this feature-first group. Explicit pilot17; default6/frozen1–16/packagecaps13 retained. Private20MiB Task file storage/raw internal routes and usable drawer upload/download/reviewed delete share I01, current Task ACL, exact-byte validation, immutable pending Blob and revocation/logout fencing. Reward/approval/due unchanged.\n- Full8675tests539files/JUnit,0failed-skipped-todo, lint/build0; all8630 parent cases plus45 retained. Chromium21/21 same-source/build firstattempts, offline/owned17/16/15/14/13/13/normalstop/integrity/closed/cleaned; both390themes inspected. Earlier OOM reporter/native cleanup/API fixture failures retained and distinguished from acceptance. No assertion removal/skip/timeout/retry relaxation. [Proof](evidence/p13-attachments-development.json).\n- Next P13 JSON/CSV/ICS staged preview/commit/conditionalundo/export, then P14–P18/remainingWallet/W18/M1/I02/I03. New six harnesses and final Windows Node22/24/three engines/package/service/performance remain pending; no new Windows/sourcePR acceptance. R02 Server2019 unrun. No release/tag/VPS/PC runner.\n''')
print('Verified8675full/21browser; retained',len(retained),'artifacts')
