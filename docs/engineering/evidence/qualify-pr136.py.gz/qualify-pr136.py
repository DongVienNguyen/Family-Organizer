from pathlib import Path
import json,hashlib,subprocess,xml.etree.ElementTree as ET,re
r=Path('/workspace/Family-Organizer');e=Path('/workspace/family-evidence');a=e/'pr136-38987528125-artifacts';sha='7e59abd0c682acf4dba80a7830e54c7e2e052a33';run='https://github.com/DongVienNguyen/Family-Organizer/actions/runs/38987528125';load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));folder=lambda prefix:next(p for p in a.iterdir()if p.name.startswith(prefix));h=lambda b:hashlib.sha256(b).hexdigest();lockSource=subprocess.check_output(['git','show',sha+':package-lock.json'],cwd=r);assert b'\r\n'not in lockSource;lockLf=h(lockSource);lock=h(lockSource.replace(b'\n',b'\r\n'))
record={'taskId':'P09 PR136 final raw qualification','prUrl':'https://github.com/DongVienNguyen/Family-Organizer/pull/136','sourceCommit':sha,'ciRunUrl':run,'qualification':'Historical exact-HEAD Windows2022 run, not current feature-branch acceptance or Server2019 R02','lockSourceLfSha256':lockLf,'lockWindowsCheckoutCrlfSha256':lock,'lockBinding':'Windows checkout CRLF bytes derived exactly from Git LF blob; artifact unchanged','units':{},'browsers':{},'nativeExitFiles':{},'review':{'independent':False,'mode':'Previously closed whole-branch SELF review26source plus three real fixture repairs; final29hashes and repair diff rechecked; no unresolved PR review threads'},'remaining':['Feature-first branch W/P/I work and final composed Windows qualification remain.','No release/tag/VPS access/deployment; actualServer2019R02 unrun.']}
def junit(file,count):
 cases=ET.parse(file).getroot().findall('.//testcase');assert len(cases)==count,(file,len(cases));assert not any(c.find(tag)is not None for c in cases for tag in ['failure','error','skipped'])
def first_attempts(report):
 rows=[]
 def visit(suites):
  for suite in suites:
   for spec in suite.get('specs',[]):
    for test in spec['tests']:
     assert test['expectedStatus']=='passed';assert len(test['results'])==1;assert test['results'][0]['status']=='passed' and test['results'][0].get('retry',0)==0;rows.append((test.get('projectName'),spec['title']))
   visit(suite.get('suites',[]))
 visit(report['suites']);assert len(rows)==len(set(rows));return rows
def common(manifest):
 assert manifest['commitSha']==sha and manifest['platform']=='win32' and manifest['architecture']=='x64' and manifest['lockSha256']==lock
 for name in ['legacyPreserved','databaseClosed','fixtureRemoved']:assert manifest[name],name
 assert manifest['integrity']=='ok' and manifest['serverExitCode']==0 and manifest['serverSignal']is None and manifest['error']is None
 assert not manifest.get('networkAttempts',[]) and not manifest.get('externalAttempts',[])
for key,node,npm in [('node22','v22.23.3','10.9.9'),('node24','v24.21.0','11.19.0')]:
 f=folder('windows-'+key+'-');evidence=load(f/'evidence.json');tests=load(f/'vitest.json');assert evidence['commitSha']==sha and evidence['workflowRunUrl']==run and evidence['nodeVersion']==node and evidence['npmVersion']==npm and evidence['runnerOS']=='Windows_NT 10.0.20348'
 assert all(v=='success'for v in evidence['checks'].values()) and len(evidence['checks'])==8
 assert tests['success'] and tests['numTotalTests']==tests['numPassedTests']==6032 and tests['numFailedTests']==tests['numPendingTests']==tests.get('numTodoTests',0)==0 and len(tests['testResults'])==326
 assert all(case['status']=='passed'for suite in tests['testResults']for case in suite['assertionResults']);junit(f/'junit.xml',6032)
 record['units'][key]={'passed':6032,'files':326,'junitCases':6032,'failed':0,'skipped':0,'todo':0,'node':node,'npm':npm,'checks':evidence['checks']}
for f in a.iterdir():
 for p in f.glob('*-exit.json'):
  value=load(p)
  if 'exitCode'in value:assert value['exitCode']==0,(p,value);record['nativeExitFiles'][str(p.relative_to(a))]=0
f=folder('windows-browsers-');report=load(f/'browser.json');manifest=load(f/'browser-fixture.json');common(manifest);assert manifest['cliExitCode']==0 and manifest['cliSignal']is None
assert report['stats']['expected']==45 and report['stats']['unexpected']==report['stats']['skipped']==report['stats']['flaky']==0;assert len(first_attempts(report))==45;junit(f/'browser.junit.xml',45)
legacy=load(f/'browser-evidence.json');assert legacy['commitSha']==sha and not legacy['errors'] and all(v=='success'for v in legacy['checks'].values());record['browsers']['legacy']={'passed':45,'firstAttempts':45,'failed':0,'skipped':0,'flaky':0}
f=folder('windows-productivity-browsers-');report=load(f/'productivity-browser.json');evidence=load(f/'productivity-browser-evidence.json');manifest=load(f/'productivity-browser-fixture.json');common(manifest);assert manifest['browserExitCode']==manifest['cliExitCode']==manifest['touchExitCode']==0 and manifest['nativeTouchVerified']
assert evidence['commitSha']==sha and evidence['workflowRunUrl']==run and not evidence['errors'] and all(v=='success'for v in evidence['checks'].values())
assert report['stats']['expected']==126 and report['stats']['unexpected']==report['stats']['skipped']==report['stats']['flaky']==0
rows=first_attempts(report);assert len(rows)==126
for project in ['chromium','firefox','webkit']:
 ids=[int(re.search(r' C(\d{2}) ',title).group(1))for engine,title in rows if engine==project];assert sorted(ids)==list(range(1,43)),(project,ids)
for shard in evidence['shards']:
 common(shard['manifest']);assert shard['manifest']['browserExitCode']==0 and shard['manifest']['cliExitCode']==0
 for worker in shard['manifest']['workerFixtures']:
  assert worker['integrity']=='ok'and worker['databaseClosed']and worker['nativeHandlesClosed']and worker['fixtureRemoved']and worker['serverExitCode']==0 and worker['serverSignal']is None and not worker['networkAttempts']and worker['error']is None
junit(f/'productivity-browser.junit.xml',126);junit(f/'productivity-browser-touch.junit.xml',1)
touch=evidence['touch'];assert touch['report']['stats']['expected']==1 and not touch['report']['errors'] and len(first_attempts(touch['report']))==1;assert touch['runtime']['nativeTouchPointer']=={'pointerType':'touch','trusted':True} and touch['runtime']['maxTouchPoints']>0
record['browsers']['productivity']={'passed':126,'casesPerEngine':42,'engines':['chromium','firefox','webkit'],'nativeTouch':1,'firstAttempts':127,'failed':0,'skipped':0,'flaky':0}
profile=load(folder('windows-package-tests-')/'package-functional.json');service=load(folder('windows-service-tests-')/'service-exit.json');assert profile['commitSha']==service['commitSha']==sha and service['exitCode']==0
record['packageFunctionalChecks']=profile['checks'];record['serviceChecks']=service['checks']
review=json.loads(subprocess.check_output(['git','show',sha+':docs/engineering/evidence/p09-columns-development.json'],cwd=r,text=True));assert len(review['wholeBranchReview']['sourceFiles'])==26 and len(review['sourceFiles'])==29 and not review['wholeBranchReview']['findings']
for file,digest in review['sourceFiles'].items():assert h(subprocess.check_output(['git','show',sha+':'+file],cwd=r))==digest,file
logs=[]
for file in sorted((e/'pr136-38987528125-logs').rglob('*.txt')):
 text=file.read_text(encoding='utf-8-sig');logs.append({'path':str(file.relative_to(e)),'sha256':h(file.read_bytes()),'lines':len(text.splitlines()),'sourceMentions':text.count(sha)})
assert len(logs)==16 and sum(row['lines']for row in logs)>14000
record['rawLogs']=logs;record['rawArtifacts']={str(file.relative_to(a)):{'sha256':h(file.read_bytes()),'bytes':file.stat().st_size}for file in sorted(a.rglob('*'))if file.is_file()and file.suffix in ['.json','.xml','.log']and 'coverage'not in str(file)};record['packageZipDownloaded']=False;record['downloadedArtifacts']=7;record['browserFirstAttemptsTotal']=172
(e/'pr136-38987528125-qualified.json').write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n');print({'source':sha,'node22':6032,'node24':6032,'browserFirstAttempts':172,'logs':len(logs),'logLines':sum(row['lines']for row in logs),'rawReports':len(record['rawArtifacts'])})
