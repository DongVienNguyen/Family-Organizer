# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: templates.spec.ts >> P13 save and preview a Task template, then recover a lost instantiate ACK across Calendar navigation without duplicate Tasks or copied checklist completion
- Location: tests/e2e/templates.spec.ts:14:1

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: locator('details[aria-label="Mẫu tác vụ cá nhân"]').getByRole('button', { name: 'Thử lại lệnh cũ', exact: true })
Expected: enabled
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" locator('details[aria-label="Mẫu tác vụ cá nhân"]').getByRole('button', { name: 'Thử lại lệnh cũ', exact: true }) with timeout 10000ms
  - waiting for locator('details[aria-label="Mẫu tác vụ cá nhân"]').getByRole('button', { name: 'Thử lại lệnh cũ', exact: true })

```

```yaml
- complementary:
  - text: Family Organizer Không gian gia đình
  - navigation:
    - button "Tổng quan"
    - button "Nhóm Task"
    - button "Chi tiêu"
    - button "Lập Lịch"
    - button "Ghi chú"
    - button "Đi chợ"
    - button "Sức khỏe gia đình"
    - button "Giấy tờ"
    - button "Quản lý Server"
    - button "Thiết lập"
  - button "Mở hồ sơ của Synthetic admin": S Synthetic admin Quản lý (Admin) • v1.1.0
  - button "Đăng xuất"
- banner:
  - text: "Đồng bộ: Đang kết nối"
  - button "Tìm kiếm toàn cục"
  - button "Chuyển sang Giao diện Tối"
  - button "1"
- main:
  - button "Danh sách" [pressed]
  - button "Kanban hiện có"
  - button "Matrix"
  - button "Kanban"
  - button "Lịch công việc"
  - region "Công việc theo danh sách":
    - textbox "Tên công việc mới"
    - button "Danh sách cho việc mới": Gia đình
    - button "Thêm việc danh sách" [disabled]
    - group: Tổ chức danh sách, sections và tags
    - group "Mẫu tác vụ cá nhân"
    - region "Bộ lọc công việc":
      - button "Góc nhìn công việc": Tất cả
      - button "Góc nhìn đã lưu": Bộ lọc tùy chọn
      - textbox "Tìm trong công việc": Synthetic P13 reusable checklist
      - button "Tìm"
      - button "Đặt lại"
      - group: Bộ lọc
      - textbox "Tên góc nhìn đã lưu"
      - button "Lưu góc nhìn mới" [disabled]
      - paragraph: 2 công việc
      - button "Synthetic P13 reusable checklist Gia đình · Khẩn cấp · Không hạn"
      - button "Synthetic P13 reusable checklist Gia đình · Khẩn cấp · Không hạn"
- button "AI assistant"
- button "Thêm công việc mới"
```

# Test source

```ts
  1  | import {test as base,expect,type Page} from '@playwright/test';
  2  | import {installOfflineNetworkBoundary} from './offline-network-boundary.js';
  3  | import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
  4  | const seed=JSON.parse(process.env.FO_TEMPLATES_SEED??'null');
  5  | const test=base.extend<{boundary:void}>({boundary:[async({context,page,baseURL},use)=>{if(!baseURL||!seed?.synthetic||seed.productivityVersion!==15)throw Error('Owned synthetic template fixture required');const external:string[]=[],errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));await installOfflineNetworkBoundary(context,baseURL,external);await context.addInitScript(()=>{localStorage.setItem('family_lang','vi');});await use();expect(external).toEqual([]);expect(errors).toEqual([]);},{auto:true}]});
  6  | test.beforeAll(async({browser,browserName})=>{const folder=path.join('reports/templates',browserName);fs.mkdirSync(folder,{recursive:true});fs.writeFileSync(path.join(folder,'runtime.json'),JSON.stringify({browserName,browserVersion:browser.version(),executableSha256:createHash('sha256').update(fs.readFileSync(browser.browserType().executablePath())).digest('hex'),node:process.version,platform:process.platform,architecture:process.arch}));});
  7  | async function login(page:Page){const response=await page.request.post('/api/auth/login',{data:{username:'browser-admin',password:'synthetic-browser-password'},maxRedirects:0});expect(response.status()).toBe(200);const body=await response.json(),origin=new URL(response.url()).origin;await page.context().setStorageState({cookies:[],origins:[{origin,localStorage:[{name:'family_token',value:body.token},{name:'family_lang',value:'vi'},{name:'family_theme',value:'light'}]}]});await page.goto('/?tab=tasks');await expect(page.getByRole('button',{name:'Lịch công việc',exact:true})).toBeEnabled();}
  8  | async function request(page:Page,path:string,method='GET',body?:unknown){return page.evaluate(async({path,method,body})=>{const response=await fetch('/api/productivity'+path,{method,headers:{Authorization:'Bearer '+localStorage.getItem('family_token'),'Content-Type':'application/json','x-request-id':crypto.randomUUID()},...(body===undefined?{}:{body:JSON.stringify(body)})});return {status:response.status,body:await response.json()};},{path,method,body});}
  9  | const drawer=(page:Page)=>page.getByRole('dialog',{name:'Chi tiết công việc',exact:true}),library=(page:Page)=>page.locator('details[aria-label="Mẫu tác vụ cá nhân"]');
  10 | async function openLibrary(page:Page){await expect(library(page)).toBeVisible();if(!await library(page).evaluate(el=>(el as HTMLDetailsElement).open))await library(page).locator('summary').click();}
  11 | async function choose(page:Page,label:string,option:string){await library(page).getByRole('button',{name:label,exact:true}).click();await page.getByRole('option',{name:option,exact:true}).click();}
  12 | async function source(page:Page,title:string){const result=await request(page,'/tasks','POST',{expectedRevision:0,input:{listId:'legacy-family',title,body:'Synthetic reusable **Markdown**',priority:'high',isShared:true}});expect(result.status).toBe(200);return result.body.task;}
  13 | async function open(page:Page,task:any){await page.getByRole('textbox',{name:'Tìm trong công việc',exact:true}).fill(task.title);await page.getByRole('button',{name:'Tìm',exact:true}).click();await page.locator('button[data-task-id="'+task.id+'"]').click();await expect(drawer(page).getByRole('button',{name:'Lưu mẫu này',exact:true})).toBeEnabled();}
> 14 | test('P13 save and preview a Task template, then recover a lost instantiate ACK across Calendar navigation without duplicate Tasks or copied checklist completion',async({page})=>{await login(page);const task=await source(page,'Synthetic P13 reusable checklist'),checked=await request(page,'/tasks/'+task.id+'/checklist','POST',{expectedRevision:task.revision,input:[{text:'Synthetic completed source item',done:true},{text:'Synthetic second item',done:false}]});expect(checked.status).toBe(200);await open(page,task);await drawer(page).getByRole('button',{name:'Lưu mẫu này',exact:true}).click();await expect(drawer(page).getByRole('region',{name:'Lưu nội dung thành mẫu',exact:true})).toContainText('Đã lưu thay đổi.');const rows=(await request(page,'/templates')).body.items,template=rows.find((row:any)=>row.sourceTaskId===task.id);expect(template).toBeTruthy();expect(template.checklistCount).toBe(2);expect(template.payload).toBeUndefined();await drawer(page).getByRole('button',{name:'Đóng',exact:true}).click();await openLibrary(page);await choose(page,'Chọn mẫu',task.title);await expect(library(page)).toContainText(task.body);const catalog=(await request(page,'/catalog')).body,target=catalog.lists.find((row:any)=>row.id==='legacy-family');await choose(page,'Danh sách nhận tác vụ mới',target.title);const before=(await request(page,'/tasks')).body.tasks.length,calls:any[]=[];let createdId='';await page.route('**/api/productivity/templates/'+template.id+'/instantiate',async route=>{calls.push({key:route.request().headers()['x-request-id'],body:route.request().postData()});if(calls.length===1){const response=await route.fetch();expect(response.status()).toBe(200);createdId=(await response.json()).task.id;await route.abort('failed');}else await route.continue();});await library(page).getByRole('button',{name:'Tạo từ mẫu',exact:true}).click();const confirm=page.getByRole('dialog',{name:'Xác nhận tác vụ mới',exact:true});await expect(confirm).toContainText(target.title);await confirm.getByRole('button',{name:'Tạo từ mẫu',exact:true}).click();await openLibrary(page);await expect(library(page).getByRole('button',{name:'Thử lại lệnh cũ',exact:true})).toBeEnabled();await page.getByTestId('task-projections').getByRole('button',{name:'Lịch công việc',exact:true}).click();await page.getByTestId('task-projections').getByRole('button',{name:'Danh sách',exact:true}).click();await openLibrary(page);await library(page).getByRole('button',{name:'Thử lại lệnh cũ',exact:true}).click();await openLibrary(page);await expect(library(page)).toContainText('Đã lưu thay đổi.');expect(calls).toHaveLength(2);expect(calls[1]).toEqual(calls[0]);const tasks=(await request(page,'/tasks')).body.tasks;expect(tasks).toHaveLength(before+1);const created=tasks.find((row:any)=>row.id===createdId);expect(created).toMatchObject({title:task.title,body:task.body,listId:target.id,lifecycle:'todo',rewardPoints:0,pendingApproval:false,due:{kind:'none'},assigneeId:null});expect(created.id).not.toBe(task.id);const next=(await request(page,'/tasks/'+created.id+'/checklist')).body.checklist.items,old=checked.body.checklist.items;expect(next.map((row:any)=>({text:row.text,done:row.done}))).toEqual([{text:'Synthetic completed source item',done:false},{text:'Synthetic second item',done:false}]);expect(next.every((row:any)=>!old.some((item:any)=>item.id===row.id))).toBe(true);});
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ^ Error: expect(locator).toBeEnabled() failed
  15 | test('P13 deletion is reviewed, remains owner-scoped, and leaves source content unchanged',async({page})=>{await login(page);const task=await source(page,'Synthetic P13 removable personal template'),saved=await request(page,'/tasks/'+task.id+'/templates','POST',{expectedRevision:task.revision});expect(saved.status).toBe(200);await openLibrary(page);await choose(page,'Chọn mẫu',task.title);await expect(library(page)).toContainText(task.body);await library(page).getByRole('button',{name:'Xóa mẫu cá nhân',exact:true}).click();const confirm=page.getByRole('dialog',{name:'Xóa mẫu cá nhân',exact:true});await expect(confirm).toContainText(task.title);await confirm.getByRole('button',{name:'Xóa mẫu cá nhân',exact:true}).click();await openLibrary(page);await expect(library(page)).toContainText('Đã lưu thay đổi.');expect((await request(page,'/templates/'+saved.body.template.id)).status).toBe(404);expect((await request(page,'/tasks/'+task.id)).body.task).toEqual(task);});
  16 | test('P13 template preview fits390px in both themes and shows explicit no-default-date and no-reward semantics',async({page})=>{await login(page);const task=await source(page,'Synthetic P13 mobile template'),saved=await request(page,'/tasks/'+task.id+'/templates','POST',{expectedRevision:task.revision});expect(saved.status).toBe(200);await page.setViewportSize({width:390,height:844});for(const theme of ['light','dark']){await page.evaluate(theme=>localStorage.setItem('family_theme',theme),theme);await page.reload();await openLibrary(page);await choose(page,'Chọn mẫu',task.title);await expect(library(page)).toContainText(task.body);await expect(library(page)).toContainText('không có hạn mặc định');expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBe(true);expect(await page.evaluate(()=>document.documentElement.classList.contains('dark'))).toBe(theme==='dark');await library(page).screenshot({path:'reports/templates/'+test.info().project.name+'/templates-390-'+theme+'.png'});}});
  17 | 
```