from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
root=Path('/workspace/Family-Organizer');ev=Path('/workspace/family-evidence');out=root/'docs/engineering/evidence/p13-templates';out.mkdir(exist_ok=True)
sha='3ee1d5d3c914d005abffe7699917228e4e81e018';fullSha='ceafc797038ce0471d9615dd0edb93fadcbad00b';base='0d9de66'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==sha
h=lambda b:hashlib.sha256(b).hexdigest()
full=json.loads((ev/'p13-template-full.json').read_text());focused=json.loads((ev/'p13-template-panel-fixed.json').read_text());parent=json.loads((ev/'p12-notification-full.json').read_text())
for report,n,files in [(full,8595,526),(focused,34,5)]:
 assert report['success'] and report['numTotalTests']==report['numPassedTests']==n and len(report['testResults'])==files
 assert report['numFailedTests']==report['numPendingTests']==report.get('numTodoTests',0)==0
for name,n in [('p13-template-full.xml',8595),('p13-template-panel-fixed.xml',34)]:
 cases=ET.parse(ev/name).getroot().findall('.//testcase');assert len(cases)==n and not any(c.find(tag)is not None for c in cases for tag in ['failure','error','skipped'])
def identities(report):
 result=collections.Counter()
 for file in report['testResults']:
  name=str(Path(file['name']).relative_to(root))
  for case in file['assertionResults']:
   assert case['status']=='passed';title=case['fullName']
   if name=='server/recoveryRetention.test.ts':title=re.sub(r'/tmp/fo test synthetic [A-Za-z0-9]+(?=/|$)','/tmp/fo test synthetic <fixture>',title)
   result[(name,title)]+=1
 return result
before,after=identities(parent),identities(full);assert sum(before.values())==8560 and not before-after,before-after
assert sum((after-before).values())==35
focusedFiles={str(Path(file['name']).relative_to(root))for file in focused['testResults']};shared=collections.Counter({k:v for k,v in after.items()if k[0]in focusedFiles});now=identities(focused);assert not shared-now and sum((now-shared).values())==1
for stem in ['p13-template-full','p13-template-lint','p13-template-build','p13-template-panel-fixed','p13-template-panel-lint','p13-template-build-final','p13-template-browser-final','p13-template-parent-notifications','p13-template-parent-collaboration','p13-template-parent-calendar']:assert(ev/(stem+'.exit')).read_text().strip()=='0',stem
browsers={}
for feature,count,version in [('templates',3,15),('notifications',4,14),('collaboration',3,13),('calendar',4,13)]:
 folder=root/'reports'/feature/'chromium';report=json.loads((folder/'browser.json').read_text());fixture=json.loads((folder/'fixture.json').read_text());assert report['stats']['expected']==count and report['stats']['unexpected']==report['stats']['flaky']==report['stats']['skipped']==0
 assert fixture['commitSha']==sha and fixture['nodeVersion']=='v24.21.0' and fixture['platform']=='linux' and fixture['seed']['productivityVersion']==version
 assert all(fixture[key]for key in ['databaseClosed','fixtureRemoved','legacyPreserved']) and fixture['integrity']=='ok' and fixture['error']is None and not fixture['networkAttempts'] and fixture['serverExitCode']==fixture['browserExitCode']==0
 assert fixture['browserSignal']==fixture['serverSignal']==None
 for key,name in [('server','dist/server.cjs'),('index','dist/index.html')]:assert fixture['build'][key]==h((root/name).read_bytes())
 def check(suites):
  for suite in suites:
   for spec in suite.get('specs',[]):
    for test in spec['tests']:assert test['status']=='expected' and len(test['results'])==1 and test['results'][0]['status']=='passed'
   check(suite.get('suites',[]))
 check(report['suites']);cases=ET.parse(folder/'browser.junit.xml').getroot().findall('.//testcase');assert len(cases)==count and not any(c.find(tag)is not None for c in cases for tag in ['failure','error','skipped'])
 browsers[feature]={'passed':count,'firstAttemptsOnly':True,'fixture':fixture}
files=subprocess.check_output(['git','diff','--name-only',base,sha],cwd=root,text=True).splitlines();source={name:h(subprocess.check_output(['git','show',sha+':'+name],cwd=root))for name in files}
for name,digest in source.items():assert h((root/name).read_bytes())==digest,name
for name in ['schema.ts','migrate.ts','structureSchema.ts','tagSchema.ts','pinSchema.ts','viewSchema.ts','matrixSchema.ts','boardSchema.ts','seriesSchema.ts','occurrenceSchema.ts','occurrenceSkipSchema.ts','legacyCutoverSchema.ts','notificationSchema.ts']:
 if name=='structureSchema.ts':continue # table catalog updated; v2 SQL unchanged below
 assert subprocess.check_output(['git','show',base+':server/productivity/'+name],cwd=root)==subprocess.check_output(['git','show',sha+':server/productivity/'+name],cwd=root),name
old=subprocess.check_output(['git','show',base+':server/productivity/structureSchema.ts'],cwd=root,text=True);new=(root/'server/productivity/structureSchema.ts').read_text();assert old.split('export const structureSchemaSql=`')[1].split('`;')[0]==new.split('export const structureSchemaSql=`')[1].split('`;')[0]
assert h((root/'package-lock.json').read_bytes())=='17e305b217c2dbd6543d66e2e600c20251425c5b4d0eb66fa903cbd13ecc6ec7'
red=json.loads((ev/'p13-template-panel-red.json').read_text());assert red['numFailedTests']==1
retained={}
def retain(file:Path,name:str):
 data=file.read_bytes();target=out/(name+'.gz');target.write_bytes(gzip.compress(data,mtime=0));retained[name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes()),'uncompressedSha256':h(data)}
for file in sorted(ev.glob('p13-template-*')):
 if file.is_file()and file.suffix in ['.json','.xml','.log','.exit','.sha']:retain(file,file.name)
retain(ev/'publish-p13-templates.py','publish-p13-templates.py')
for feature in browsers:
 folder=root/'reports'/feature/'chromium'
 for name in ['browser.json','browser.junit.xml','fixture.json','runtime.json','run.log','server.log']:retain(folder/name,feature+'-final-'+name)
first=ev/'p13-template-browser-first-artifacts'
for file in first.rglob('*'):
 if file.is_file()and file.suffix in ['.json','.xml','.log','.md','.zip','.png']:retain(file,'first-'+str(file.relative_to(first)).replace('/','__'))
for file in (root/'reports/templates/chromium').glob('templates-390-*.png'):
 target=out/file.name;target.write_bytes(file.read_bytes());retained[file.name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes()),'visuallyInspected':True}
proof={'taskId':'P13 templates functional slice','sourceCommit':sha,'fullRegressionSource':fullSha,'prUrl':None,'ciRunUrl':None,'qualification':'Cloud only, final Windows pending','fullRegression':{'passed':8595,'files':526,'junitCases':8595,'failed':0,'skipped':0,'todo':0,'parentTests':8560,'parentRemoved':0,'added':35,'note':'Includes P12 media2 and initial template33. This is the ceafc79 full run, before the panel-state follow-up.'},'finalFocused':{'passed':34,'files':5,'failed':0,'skipped':0,'newPanelRegression':1,'scope':'All33 initial template assertions retained; one added. No full-suite claim for3ee1d5d.'},'lintExitCode':0,'buildExitCode':0,'browser':browsers,'sourceFiles':source,'schema':{'explicitPilotVersion':15,'defaultVersion':6,'frozen1to14Preserved':True,'packageCapsChanged':False},'review':{'independent':False,'scope':'Author review of owner/source/destination current ACL before receipt, I01 rollback/fresh IDs, media capabilities, frozen schema and snapshot validation, bounded summary DTOs and source-fenced browser session.'},'findings':['Templates retain only title, body, priority and checklist labels. Instantiation creates new Task/check-item/history IDs, all checklist unchecked, todo/zero rewards/no due/assignee/proof/completion/recurrence/tags; no source edit or reward effect.','List/detail owner scope and live source ACL are checked before decoding body; destination create scope is checked before cached receipts and again inside I01. Tombstone deletion keeps retry identity without disclosing content.','At most100 personal templates; list returns summaries and loads only one selected body. New capabilities permit only current source-bound Markdown in a trusted instantiation; removed files cannot be resurrected and generic foreign attachment copying remains denied.','Actual first Chromium lost-ACK case failed because SSE remounted a closed library panel. The browser-session owner now retains expansion and original command; the actual native panel RED is retained. Three final template journeys and all eleven parent feature journeys pass, no retries/timeouts/assertion weakening.','Initial feature RED had missing implementation imports. Two subsequent media fixture failures were missing owner-staged upload metadata; fixtures now use the real metadata binding lifecycle, assertions retained. An invalid reporter CLI attempt is retained separately and is not counted as a test run.'],'remaining':['P13 Notes/conversion/files/import/export not implemented by this template slice.','P14–P18, remaining Wallet/W18/M1/I02/I03 remain; final composed Windows Node22/24, all parent engines/touch/Wallet suites and new feature harnesses are pending.','No new source PR/Windows run, no release/tag/VPS/PC runner; actual Server2019 R02 is separate and unrun.'],'retainedEvidence':retained}
(root/'docs/engineering/evidence/p13-templates-development.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
(root/'docs/engineering/productivity-templates.md').write_text('''# P13 personal task templates

Source3ee1d5d implements the template slice of P13. Explicit pilot schema15 adds
one owner-scoped content table. Default6 and package caps are unchanged; frozen
1–14 migration SQL/checksums remain. Notes/conversion/files/import/export are
still separate P13 work, not implied by this checkpoint.

The Task drawer saves title, Markdown, priority and checklist labels. A reviewed
destination creates a private unfinished Task with fresh Task/history/check-item
IDs, unchecked checklist, no date/assignee/reward/proof/completion/recurrence/tag
copy. The source remains unchanged. Current owner/source/destination authority
is checked before the shared I01 receipt and within its transaction. Revoked or
deleted sources hide templates without leaking body/counts. Tombstone deletion
is owner-only and retry-safe. Lists return at most100 summaries; only the selected
body loads. Media inheritance uses an explicit trusted capability from current
source references, so old templates cannot resurrect removed attachments.

The existing user session owns original nonce/revisions/payload across lost ACK,
SSE and navigation. Current source/destination visibility loss and logout retire
private intent and fence late effects. Library expansion also survives an SSE
remount; the first actual browser failure and one native RED are retained.

Full8595tests526files/matching JUnit passed at ceafc79 (all8560parents retained,
plus media2 and templates33). A subsequent UI panel-state fix at3ee1d5d has all34
focused template cases, lint/build0 and14 first-attempt Chromium journeys:
templates3 + notifications4 + collaboration3 + calendar4. All share the exact
3ee1d5d build; owned15/14/13/13 fixtures, offline boundary, normal stop, integrity,
closed handles and cleanup pass. Both390px template themes were viewed. No full-
suite claim is made for3ee1d5d. [Raw proof](evidence/p13-templates-development.json).

No new-source PR or Windows run yet. Final composed Windows qualification must
include all prior Productivity/touch/Wallet browser suites, three engines,
Node22/24/package/service/performance and the new feature harnesses (not yet wired).
Actual Server2019 R02 remains separate; no release/tag/VPS/PC runner.
''')
p=root/'docs/engineering/implementation-status.md';s=p.read_text();marker='## Current direction — 2026-10-18 (UTC)\n';entry=f'''\n**P13 templates functional slice:** source `{sha}` adds owner-scoped\nexplicit15 content templates, fresh unfinished Task/checklist instantiation,\ncurrent source/destination ACL, trusted media inheritance, summary-only lists\nand session-owned lost-ACK packets/library expansion. Full8595tests526files\npassed at `{fullSha}` (all8560parents +media2/template33);\nfinal panel fix has34focused cases/lint/build0 and14/14 same-build Chromium\njourneys (templates3/reminders4/collaboration3/calendar4), first attempts, offline,\nowned fixtures, normal stop/integrity/closed/cleaned; both390themes viewed.\nNo full-suite claim for3ee1d5d. Actual browser/native panel failure retained.\n[Details](productivity-templates.md), [proof](evidence/p13-templates-development.json).\nPR URL/CI run URL:none for this source; backup branch, author review only.\nP13 remains partial: Notes/conversion/files/import/export next, then remaining\nP/W18/M1/I02/I03 and final composed Windows. No release/tag/VPS/PC runner.\n''';assert '**P13 templates functional slice:**'not in s;p.write_text(s.replace(marker,marker+entry,1))
print(json.dumps({'source':sha,'fullSource':fullSha,'full':8595,'focused':34,'browsers':14,'retained':len(retained)}))
