import json,hashlib,pathlib,collections,re,subprocess,xml.etree.ElementTree as ET
r=pathlib.Path('/workspace/Family-Organizer');e=pathlib.Path('/workspace/family-evidence');f=json.loads((e/'w16-frozen.json').read_text());sha=f['sourceCommit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==sha
for p,h in f['sourceFiles'].items():
 assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
 assert hashlib.sha256(subprocess.check_output(['git','show',sha+':'+p],cwd=r)).hexdigest()==h,p
assert hashlib.sha256((r/'package-lock.json').read_bytes()).hexdigest()==f['lockSha256']
for stem in ['w16-final-full','w16-final-lint','w16-final-build','w16-final-browser']:assert (e/(stem+'.exit')).read_text().strip()=='0',stem
cur=json.loads((e/'w16-final-full.json').read_text());old=json.loads((e/'w15-final-full.json').read_text());assert cur['success'] and cur['numTotalTests']==cur['numPassedTests'] and cur['numTotalTests']>0;assert cur['numFailedTests']==cur['numPendingTests']==cur.get('numTodoTests',0)==0
cases=ET.parse(e/'w16-final-full.junit.xml').getroot().findall('.//testcase');assert len(cases)==cur['numTotalTests'];assert not any(c.find(tag)is not None for c in cases for tag in ('failure','error','skipped'))
def identities(d):
 result=collections.Counter()
 for file in d['testResults']:
  name=str(pathlib.Path(file['name']).relative_to(r))
  for case in file['assertionResults']:
   assert case['status']=='passed',(name,case['fullName'],case['status'])
   title=case['fullName']
   if name=='server/recoveryRetention.test.ts':title=re.sub(r'/tmp/fo test synthetic [A-Za-z0-9]+(?=/|$)','/tmp/fo test synthetic <fixture>',title)
   result[(name,title)]+=1
 return result
prev,now=identities(old),identities(cur);assert sum(prev.values())==8350;assert not prev-now,prev-now
b=e/'w16-final-browser-artifacts';fixture=json.loads((b/'fixture.json').read_text());browser=json.loads((b/'browser.json').read_text())
for key in ['databaseClosed','legacyPreserved','fixtureRemoved']:assert fixture[key],key
assert fixture['commitSha']==sha and fixture['seed']['walletVersion']==16
assert fixture['integrity']=='ok' and not fixture['networkAttempts'] and fixture['error'] is None
assert fixture['serverExitCode']==fixture['browserExitCode']==0 and fixture['serverSignal']==fixture['browserSignal']==None
assert browser['stats']['expected']==65 and browser['stats']['unexpected']==browser['stats']['flaky']==browser['stats']['skipped']==0
bc=ET.parse(b/'browser.junit.xml').getroot().findall('.//testcase');assert len(bc)==65;assert not any(c.find(tag)is not None for c in bc for tag in ('failure','error','skipped'))
prior=ET.parse(e/'w14-browser-qualified-artifacts/browser.junit.xml').getroot().findall('.//testcase');assert not(collections.Counter(c.attrib['name'] for c in prior)-collections.Counter(c.attrib['name'] for c in bc))
prior15=ET.parse(e/'w15-final-browser-artifacts/browser.junit.xml').getroot().findall('.//testcase');assert not(collections.Counter(c.attrib['name'] for c in prior15)-collections.Counter(c.attrib['name'] for c in bc))
for name,p in {'server':'dist/server.cjs','index':'dist/index.html'}.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==fixture['build'][name]
p={'sourceCommit':sha,'parentPassed':sum(prev.values()),'currentPassed':sum(now.values()),'added':sum((now-prev).values()),'removed':sum((prev-now).values()),'normalization':'only temporary root in five recoveryRetention names; multiplicity retained','junitCases':len(cases),'files':len(cur['testResults']),'newCases':[{'file':name,'title':title,'multiplicity':count}for(name,title),count in(now-prev).items()],'sourceFiles':f['sourceFiles'],'baseHead':f['baseHead'],'browser':{'scope':'whole Wallet Chromium; Windows deferred to final integration batch','cases':len(bc),'unexpected':0,'flaky':0,'skipped':0,'fixture':fixture}}
(e/'w16-preservation.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({k:v for k,v in p.items()if k not in ['sourceFiles','newCases','browser']}))
