from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
root=Path('/workspace/Family-Organizer');ev=Path('/workspace/family-evidence');out=root/'docs/engineering/evidence';sha='1a4d2a32d4a07f332d6721778e201693bb8384b8';base='6815cbea1c56e98fde6c34a6dac0cd7d2ca8f177'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==sha
h=lambda b:hashlib.sha256(b).hexdigest()
full=json.loads((ev/'p12-notification-full.json').read_text());parent=json.loads((ev/'p12-collaboration-full.json').read_text())
assert full['success'] and full['numTotalTests']==full['numPassedTests']==8560 and len(full['testResults'])==520
assert full['numFailedTests']==full['numPendingTests']==full.get('numTodoTests',0)==0
cases=ET.parse(ev/'p12-notification-full.junit.xml').getroot().findall('.//testcase');assert len(cases)==8560 and not any(c.find(tag)is not None for c in cases for tag in ['failure','error','skipped'])
def identities(report):
 result=collections.Counter()
 for file in report['testResults']:
  name=str(Path(file['name']).relative_to(root))
  for case in file['assertionResults']:
   assert case['status']=='passed';title=case['fullName']
   if name=='server/recoveryRetention.test.ts':title=re.sub(r'/tmp/fo test synthetic [A-Za-z0-9]+(?=/|$)','/tmp/fo test synthetic <fixture>',title)
   result[(name,title)]+=1
 return result
before,after=identities(parent),identities(full);assert sum(before.values())==8502 and not before-after,before-after
assert sum((after-before).values())==58
stems=['p12-notification-full','p12-notification-final-lint','p12-notification-final-build','p12-notification-browser-final','p12-notification-parent-collaboration','p12-notification-parent-calendar']
for stem in stems:assert(ev/(stem+'.exit')).read_text().strip()=='0',stem
browsers={}
for feature,count,version in [('notifications',4,14),('collaboration',3,13),('calendar',4,13)]:
 folder=root/'reports'/feature/'chromium';report=json.loads((folder/'browser.json').read_text());fixture=json.loads((folder/'fixture.json').read_text());assert report['stats']['expected']==count and report['stats']['unexpected']==report['stats']['flaky']==report['stats']['skipped']==0
 assert fixture['commitSha']==sha and fixture['nodeVersion']=='v24.21.0' and fixture['platform']=='linux' and fixture['seed']['synthetic'] and fixture['seed']['productivityVersion']==version
 if feature=='notifications':assert fixture['seed']['notificationFixture']=={'explicit':True,'frozen13Preserved':True,'taskRowsPreserved':True,'notificationsCreated':0}
 assert all(fixture[key]for key in ['databaseClosed','fixtureRemoved','legacyPreserved'])
 assert fixture['integrity']=='ok' and fixture['error']is None and not fixture['networkAttempts'] and fixture['serverExitCode']==fixture['browserExitCode']==0 and fixture['browserSignal']==fixture['serverSignal']==None
 for key,name in [('server','dist/server.cjs'),('index','dist/index.html')]:assert fixture['build'][key]==h((root/name).read_bytes())
 bc=ET.parse(folder/'browser.junit.xml').getroot().findall('.//testcase');assert len(bc)==count and not any(c.find(tag)is not None for c in bc for tag in ['failure','error','skipped'])
 def check(suites):
  for suite in suites:
   for spec in suite.get('specs',[]):
    for test in spec['tests']:assert test['status']=='expected' and len(test['results'])==1 and test['results'][0]['status']=='passed'
   check(suite.get('suites',[]))
 check(report['suites']);browsers[feature]={'passed':count,'failed':0,'skipped':0,'flaky':0,'firstAttemptsOnly':True,'fixture':fixture}
files=subprocess.check_output(['git','diff','--name-only',base,sha],cwd=root,text=True).splitlines();assert 'package-lock.json'not in files
source={name:h(subprocess.check_output(['git','show',sha+':'+name],cwd=root))for name in files}
for name,digest in source.items():assert h((root/name).read_bytes())==digest,name
for name in ['server/productivity/schema.ts','server/productivity/migrate.ts','server/productivity/legacyCutoverSchema.ts','server/productivity/occurrenceSkipSchema.ts','server/productivity/occurrenceSchema.ts','server/productivity/seriesSchema.ts']:
 assert subprocess.check_output(['git','show',base+':'+name],cwd=root)==subprocess.check_output(['git','show',sha+':'+name],cwd=root),name
assert h((root/'package-lock.json').read_bytes())=='17e305b217c2dbd6543d66e2e600c20251425c5b4d0eb66fa903cbd13ecc6ec7'
red=json.loads((ev/'p12-notification-review-regressions-red.json').read_text());assert red['numFailedTests']==3
retained={}
for file in sorted([*ev.glob('p12-notification-*'),ev/'publish-p12-notifications.py']):
 if file.is_file()and file.suffix in ['.json','.xml','.log','.exit','.py']:
  target=out/(file.name+'.gz');target.write_bytes(gzip.compress(file.read_bytes(),mtime=0));retained[file.name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes())}
for feature in ['notifications','collaboration','calendar']:
 folder=root/'reports'/feature/'chromium'
 for name in ['browser.json','browser.junit.xml','fixture.json','runtime.json','run.log','server.log']:
  file=folder/name;target=out/('p12-notification-'+feature+'-final.'+name+'.gz');target.write_bytes(gzip.compress(file.read_bytes(),mtime=0));retained[feature+'/'+name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes())}
for file in (root/'reports/notifications/chromium').glob('reminders-390-*.png'):
 target=out/('p12-'+file.name);target.write_bytes(file.read_bytes());retained[file.name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes()),'visuallyInspected':True}
proof={'taskId':'P12 durable reminder and notification functional core','sourceCommit':sha,'baseHead':base,'prUrl':None,'ciRunUrl':None,'qualification':'Cloud functional development; Windows/I03 and rollout remain','sourceFiles':source,'unit':{'passed':8560,'files':520,'junitCases':8560,'failed':0,'skipped':0,'todo':0,'parentPassed':8502,'added':58,'removed':0,'normalization':'Only owned temporary-root token in recoveryRetention names; all names and multiplicity retained'},'lintExitCode':0,'buildExitCode':0,'browser':browsers,'schema':{'newVersion':14,'explicitPilotOnly':True,'defaultVersion':6,'frozen1to13Preserved':True,'packageCapsChanged':False},'findings':['Existing comment/history/mention/list grants remain canonical. New14 rules/claims/per-user preferences/reference-only notice metadata join I01 and the shared AppJobs/legacy push outbox; no duplicate scheduler/provider gateway.','Current Task edits synchronously cancel/re-anchor pending reminders; injected observer/native faults roll back Task/claim/notice mutations. Assignment/reassignment notifications also join the Task command and stable identity.','A real restore test with deliberately different snapshot/restore clocks initially replayed a delayed digest. Shared synchronous minimum-version domain restore policies now consume pending notice references inside replacement COMMIT, preserving inbox history and fencing old epoch jobs. A failing policy rolls back replacement; this is not a timestamp-only guess.','Two review findings have three actual RED assertions: UTC spelling created distinct reminder identities/SDK acknowledgement mismatch, and256-character preserved Task IDs exceeded the shared job-key limit. Canonical millisecond UTC and bounded hashed continuation keys fix the causes; no assertion/timeout/retry relaxation.','One subsequent fixture claim-count failure was an earlier test’s synthetic restore marker surviving a clock reset. Each owned notification fixture now resets that marker; all assertions remain unchanged.','Quiet hours and daily digest use explicit named-zone real instants, including overnight/half-hour/DST gap/fold cases. External push is retryable/outcome-unknown per shared ownership; only inbox identity is deduped, never an exactly-once provider receipt promise.','Current recipient/source access is rechecked before dispatch and again before external push. Deleted recipients are suppressed without blocking live recipients. A digest stays visible only while at least one current source is readable.','Task reminder/own Settings packets retain original revisions/body/key through lost acknowledgements and navigation. Unsent own settings also survive unrelated Task SSE; Task visibility loss/logout fence late continuations. No browser offline writes or real provider/test push.'],'retainedEvidence':retained,'review':{'independent':False,'scope':'Author review of frozen migration/known-version/checksum/SQL-shape guards; I01 observer/rollback/restore-policy synchronous ownership; current ACL, source clocks, UTC identity and bounded continuation fairness; DTO/session packet privacy; all eleven native Chromium journeys and actual390px themes.'},'remaining':['New14 is an explicit development pilot. No automatic production upgrade or package-cap promotion; controlled schema conversion/pilot/rollback and global snapshot capacity remain P18/W18/I03.','Final composed Windows must include all parent unit/browser/Wallet/three-engine/native-touch suites plus Calendar, Collaboration and Notifications; new feature harnesses are not yet wired into Windows CI.','Whole42Productivity/nativeTouch and65Wallet browser suites were not repeated for this group; no Windows acceptance inferred from Cloud.','Calendar/notes/import P13, Focus/Habits/Insights/P17–18, remainingWallet/W18/M1/I02/I03/master remain incomplete.','Node22/24 Windows2022/package/service/performance and actualServer2019R02 unrun for this source. No release/tag/VPS/PC runner.']}
(out/'p12-notification-development.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
(root/'docs/engineering/productivity-notifications.md').write_text('''# P12 task reminders and notification preferences

This is the Cloud functional implementation, source1a4d2a3. Schema14 is an explicit
pilot addition; ordinary startup only registers the version already persisted.
The default migration remains6, frozen1–13 DDL/checksums/Task facts remain intact,
and Windows package caps have not been promoted. Controlled conversion/pilot and
Windows qualification belong to P18/I03; this is not Server2019 acceptance.

The Task drawer schedules an explicit UTC instant, an offset before a timed due
instant, or an offset before scheduled start. Date-only due values require the
user to select a real reminder time. Empty dates remain empty; DST gaps cannot
silently become valid, and repeated wall minutes require an explicit offset.
Custom rules replace that Task’s old fixed reminder windows; disabling all custom
rules stops those reminders. Tasks without custom rules retain their old defaults;
Plan/medical reminder producers remain unchanged. Existing assignee controls now
stage canonical assignment/reassignment notices in the same Task command.

A unique Task/occurrence/recipient/kind/canonical-fireAt claim and I01 receipt own
the inbox effect. Equivalent UTC spellings cannot create another rule/claim.
Task changes synchronously cancel/re-anchor pending work, including retained Task
adapters. Rules have at most64 entries per Task. Bounded worker batches and hashed
continuation keys preserve256-character legacy Task IDs. Job leases, backoff,
shutdown/drain and outbound push remain owned by AppJobs and the legacy effect
outbox. No test delivers a real notification; external provider receipt is not
promised exactly once.

The existing Push Notifications card includes own-user immediate/daily and quiet-
hour preferences. Inbox records remain available even when outbound Task push is
disabled or device permission is denied; device permission is managed separately.
The worker checks current preferences at dispatch and current source/recipient ACL
before queuing an effect. The push worker checks source access again. Daily digest
content is generic and stays visible only while at least one current source is
readable. Deactivated recipients do not block other recipients in the batch.

Restore consumes old pending outbound notice references inside the shared SQL
replacement transaction through a synchronous, minimum-version domain policy.
It preserves inbox history, applies the shared job restore fence, and rejects old
epoch commands. Genuine future reminder intents are re-authorized when due.
A failing domain policy rolls back replacement; snapshot clock skew cannot revive
an old delayed digest. No second restore engine or scheduler is introduced.

Browser-session owners retain reviewed reminder/rule/preference packets through
lost ACK and navigation with the original revision/body/key. Fresh source denial
or logout retires private packets and late continuations. Unsent own preferences
also survive unrelated Task SSE without rebasing their original revision.

Cloud full8560tests520files/matching JUnit, zero failed/skipped/todo; all8502
parent cases plus58 retained, lint/build0. Notifications4/4, Collaboration3/3 and
Calendar4/4 Chromium journeys pass on the same source/build, first attempts only,
with offline/owned fixtures14/13/13, normal stop, integrity, closed handles and
cleanup. Both390px reminder themes were inspected. Original restore/review and
fixture failures are retained in [proof](evidence/p12-notification-development.json).

New feature harnesses still need mandatory Windows CI wiring. Whole parent
Productivity/touch/Wallet suites, Node22/24 Windows package/service/performance,
actual Server2019 R02, and P18/W18 capacity/pilot/rollback remain separate. No
release/tag, VPS deployment, or PC runner was used or requested.
''')
p=root/'docs/engineering/implementation-status.md';s=p.read_text();anchor='## Current direction — 2026-10-18 (UTC)\n\n';entry=f'''**P12 durable reminders/quiet hours/digest functional core (2026-10-18):**
source `{sha}` adds explicit14 rules/claims/own-user preferences and reference-
only delivery metadata, I01 Task-save cancellation/rescheduling/assignment, shared
AppJobs/legacy push reuse and atomic restore backlog consumption. Default6,
frozen1–13 and package caps remain. Cloud full8560tests520files/matchingJUnit,
zero failures/skips/todo; all8502parents +58 retained, lint/build0.
Same-source/build Chromium Notifications4/4 + Collaboration3/3 + Calendar4/4,
firstattempts/offline/owned14/13/13fixtures/normal-stop/integrity/closed/cleaned;
390px light/dark inspected. Actual restore-clock/UTC-identity/job-key failures and
fixture isolation correction retained, assertions/deadlines unchanged.
[Details](productivity-notifications.md), [proof](evidence/p12-notification-development.json).
Author review only. PR/CI run URLs:none for this source; backup branch.
P12 functional core is implemented; full Windows acceptance and controlled14
pilot/rollout remain P18/I03. Next P13 content/templates/import/export and remaining
P/W18/M1/I02/I03, then final composed Windows including allparent suites and all
three new feature harnesses (not yet wired). ActualServer2019R02 unrun;
no release/tag/VPS or PC runner. Whole master is not complete.

''';assert '**P12 durable reminders/quiet hours/digest functional core (2026-10-18):**'not in s;p.write_text(s.replace(anchor,anchor+entry,1))
print(json.dumps({'source':sha,'unitTests':8560,'files':520,'added':58,'browsers':{'notifications':4,'collaboration':3,'calendar':4},'retainedFiles':len(retained),'prUrl':None,'ciRunUrl':None}))
