# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: habits.spec.ts >> P15 finishing Habit stopwatch leaves check-ins/Tasks unchanged and reviewed archive preserves read-only history
- Location: tests/e2e/habits.spec.ts:15:1

# Error details

```
Error: locator.check: Clicking the checkbox did not change its state
Call log:
  - waiting for getByTestId('habit-workspace').getByLabel('Xem mục đã lưu trữ', { exact: true })
    - locator resolved to <input type="checkbox"/>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - performing click action
    - click action done
    - waiting for scheduled navigations to finish
    - navigations have finished

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - complementary [ref=e4]:
      - generic [ref=e5]:
        - generic [ref=e11]:
          - generic [ref=e12]: Family Organizer
          - text: Không gian gia đình
        - navigation [ref=e13]:
          - button "Tổng quan" [ref=e14] [cursor=pointer]
          - button "Nhóm Task" [ref=e19] [cursor=pointer]
          - button "Chi tiêu" [ref=e24] [cursor=pointer]
          - button "Lập Lịch" [ref=e29] [cursor=pointer]
          - button "Ghi chú" [ref=e33] [cursor=pointer]
          - button "Đi chợ" [ref=e38] [cursor=pointer]
          - button "Sức khỏe gia đình" [ref=e44] [cursor=pointer]
          - button "Giấy tờ" [ref=e49] [cursor=pointer]
          - button "Quản lý Server" [ref=e55] [cursor=pointer]
          - button "Thiết lập" [ref=e60] [cursor=pointer]
      - generic [ref=e65]:
        - button "Mở hồ sơ của Synthetic admin" [ref=e66] [cursor=pointer]:
          - generic [ref=e67]: S
          - generic [ref=e68]:
            - generic [ref=e69]: Synthetic admin
            - generic [ref=e70]: Quản lý (Admin) • v1.1.0
        - button "Đăng xuất" [ref=e71] [cursor=pointer]
    - generic [ref=e75]:
      - banner [ref=e76]:
        - generic [ref=e77]: "Đồng bộ: Đang kết nối"
        - generic [ref=e84]:
          - button "Tìm kiếm toàn cục" [ref=e85] [cursor=pointer]
          - button "Chuyển sang Giao diện Tối" [ref=e89] [cursor=pointer]
          - button "1" [ref=e93] [cursor=pointer]
      - main [ref=e98]:
        - group [ref=e99]:
          - generic "Tập trung" [ref=e100] [cursor=pointer]
          - generic [ref=e104]:
            - paragraph [ref=e105]: Phiên Focus chỉ ghi thời gian của bạn; không hoàn thành công việc hoặc cộng điểm thưởng.
            - form "Bắt đầu phiên Focus" [ref=e106]:
              - generic [ref=e107]:
                - group [ref=e108]:
                  - button "Liên kết phiên Focus" [ref=e109] [cursor=pointer]:
                    - generic [ref=e110]: Không liên kết
                - group [ref=e114]:
                  - button "Chế độ Focus" [ref=e115] [cursor=pointer]:
                    - generic [ref=e116]: Pomodoro
              - generic [ref=e120]:
                - text: Ghi chú phiên Focus
                - textbox "Ghi chú phiên Focus" [ref=e121]
              - generic [ref=e122]:
                - text: Ước tính (giây, tùy chọn)
                - spinbutton "Ước tính (giây, tùy chọn)" [ref=e123]
              - generic [ref=e124]:
                - button "Bắt đầu Focus" [ref=e125] [cursor=pointer]
                - button "Bắt đầu nghỉ" [ref=e126] [cursor=pointer]
            - group [ref=e127]:
              - generic "Ghi thời gian thủ công" [ref=e128] [cursor=pointer]
            - group [ref=e129]:
              - generic "Thiết lập Focus" [ref=e130] [cursor=pointer]
            - region "Lịch sử Focus của tôi" [ref=e131]:
              - heading "Lịch sử Focus của tôi · 1" [level=3] [ref=e132]
              - button "01:00 19 thg 10, 2026 · Tập trung làm việc · 0s · Synthetic P15 timer archive" [ref=e133]
              - generic [ref=e134]:
                - button "100 phiên trước" [disabled] [ref=e135] [cursor=pointer]
                - button "100 phiên tiếp" [disabled] [ref=e136] [cursor=pointer]
            - button "Tải lại Focus" [ref=e137] [cursor=pointer]
        - generic [ref=e139]:
          - generic [ref=e140]:
            - button "Danh sách" [pressed] [ref=e141]
            - button "Kanban hiện có" [ref=e142]
            - button "Matrix" [ref=e143]
            - button "Kanban" [ref=e144]
            - button "Lịch công việc" [ref=e145]
          - region "Công việc theo danh sách" [ref=e147]:
            - group "Thói quen và ngày quan trọng" [ref=e148]:
              - generic [ref=e150]:
                - paragraph [ref=e151]: Check-in ghi tiến độ riêng của từng người. Thói quen và Focus không tự hoàn thành công việc, cộng điểm hoặc ghi tiền.
                - generic [ref=e152]:
                  - button "Tạo thói quen" [ref=e153] [cursor=pointer]
                  - button "Thêm ngày quan trọng" [ref=e154] [cursor=pointer]
                  - button "Tải lại theo dõi" [ref=e155] [cursor=pointer]
                  - generic [ref=e156]:
                    - checkbox "Xem mục đã lưu trữ" [checked] [ref=e157]
                    - text: Xem mục đã lưu trữ
                - generic [ref=e158]:
                  - region "Thói quen của tôi và gia đình" [ref=e159]:
                    - heading "Thói quen của tôi và gia đình · 1" [level=3] [ref=e160]
                    - article [ref=e161]:
                      - button "Synthetic P15 timer archive" [ref=e162] [cursor=pointer]
                      - paragraph [ref=e163]: Mỗi ngày · Đạt / chưa đạt · Riêng tư
                    - generic [ref=e164]:
                      - button "100 mục trước" [disabled] [ref=e165] [cursor=pointer]
                      - button "100 mục tiếp" [disabled] [ref=e166] [cursor=pointer]
                  - region "Chi tiết thói quen" [ref=e167]:
                    - heading "Synthetic P15 timer archive" [level=3] [ref=e168]
                    - paragraph [ref=e169]: Synthetic Habit browser note
                    - paragraph [ref=e170]: Asia/Saigon · Mỗi ngày
                    - paragraph [ref=e171]: Mục đã lưu trữ; lịch sử chỉ đọc và không phát sinh check-in mới.
                    - generic [ref=e172]:
                      - group [ref=e173]:
                        - generic [ref=e174]:
                          - textbox "Mốc ngày xem tiến độ" [ref=e175]:
                            - /placeholder: dd/mm/yyyy
                            - text: 19/10/2026
                          - button "Chọn ngày từ lịch" [ref=e176] [cursor=pointer]
                      - group [ref=e179]:
                        - button "Khoảng xem tiến độ" [ref=e180] [cursor=pointer]:
                          - generic [ref=e181]: 7 ngày
                    - generic [ref=e185]:
                      - paragraph [ref=e186]: Đạt 0 / 1 mục tiêu · 0%
                      - paragraph [ref=e187]: Chuỗi chỉ tính trong kỳ đang xem. Bỏ qua không là hoàn thành và giữ chuỗi theo ngày; mục tiêu theo tuần vẫn phải đủ lượt. Ngày/tuần hiện tại chưa kết thúc không tự làm đứt chuỗi.
                      - paragraph [ref=e188]: "Chuỗi trong kỳ: 0 ngày theo lịch; tốt nhất 0."
                      - paragraph [ref=e189]: 19/10/2026 — 25/10/2026
                      - generic "Lịch tiến độ thói quen" [ref=e190]:
                        - button "19/10/2026 · Chưa đạt" [ref=e191] [cursor=pointer]:
                          - text: "19"
                          - generic [ref=e192]: ·
                        - button "20/10/2026 · Không theo lịch" [disabled] [ref=e193] [cursor=pointer]:
                          - text: "20"
                          - generic [ref=e194]: ·
                        - button "21/10/2026 · Không theo lịch" [disabled] [ref=e195] [cursor=pointer]:
                          - text: "21"
                          - generic [ref=e196]: ·
                        - button "22/10/2026 · Không theo lịch" [disabled] [ref=e197] [cursor=pointer]:
                          - text: "22"
                          - generic [ref=e198]: ·
                        - button "23/10/2026 · Không theo lịch" [disabled] [ref=e199] [cursor=pointer]:
                          - text: "23"
                          - generic [ref=e200]: ·
                        - button "24/10/2026 · Không theo lịch" [disabled] [ref=e201] [cursor=pointer]:
                          - text: "24"
                          - generic [ref=e202]: ·
                        - button "25/10/2026 · Không theo lịch" [disabled] [ref=e203] [cursor=pointer]:
                          - text: "25"
                          - generic [ref=e204]: ·
                      - paragraph [ref=e205]: Một phần tuần nằm ngoài lịch sử/khoảng xem; không suy ra thiếu tiến độ cho phần chưa có dữ liệu.
                    - region "Ghi tiến độ theo ngày" [ref=e206]:
                      - heading "Ghi tiến độ theo ngày" [level=4] [ref=e207]
                      - group [ref=e208]:
                        - generic [ref=e209]:
                          - textbox "Ngày check-in hoặc ghi bù" [ref=e210]:
                            - /placeholder: dd/mm/yyyy
                            - text: 19/10/2026
                          - button "Chọn ngày từ lịch" [ref=e211] [cursor=pointer]
                      - generic [ref=e214]:
                        - alert [ref=e215]: Ngày hoặc lịch đã đổi ở nơi khác. Giữ nguyên bản nháp để xem lại; chưa gửi ghi đè lên dữ liệu mới.
                        - button "Đọc lại bản ghi của ngày" [ref=e216] [cursor=pointer]
                      - paragraph [ref=e217]: "Mục tiêu của bản ghi: 1"
                      - generic [ref=e218]:
                        - checkbox "Đánh dấu đã đạt mục tiêu" [disabled] [ref=e219]
                        - text: Đánh dấu đã đạt mục tiêu
                      - generic [ref=e220]:
                        - text: Ghi chú check-in hoặc lý do sửa
                        - textbox "Ghi chú check-in hoặc lý do sửa" [disabled] [ref=e221]
                      - generic [ref=e222]:
                        - button "Lưu tiến độ" [disabled] [ref=e223] [cursor=pointer]
                        - button "Bỏ qua ngày này" [disabled] [ref=e224] [cursor=pointer]
                    - button "Tải lại tiến độ" [ref=e225] [cursor=pointer]
                  - region "Các ngày quan trọng" [ref=e226]:
                    - heading "Các ngày quan trọng · 0" [level=3] [ref=e227]
                    - paragraph [ref=e228]: Chưa có ngày quan trọng trong danh sách này.
                    - generic [ref=e229]:
                      - button "100 mục trước" [disabled] [ref=e230] [cursor=pointer]
                      - button "100 mục tiếp" [disabled] [ref=e231] [cursor=pointer]
            - generic [ref=e232]:
              - generic [ref=e233]:
                - textbox "Tên công việc mới" [ref=e234]
                - button "Danh sách cho việc mới" [ref=e235] [cursor=pointer]:
                  - generic [ref=e236]: Gia đình
                - button "Thêm việc danh sách" [disabled] [ref=e240] [cursor=pointer]
              - group [ref=e242]:
                - generic "Tổ chức danh sách, sections và tags" [ref=e243] [cursor=pointer]
              - group "Mẫu tác vụ cá nhân" [ref=e244]
              - group "Nhập và xuất công việc" [ref=e246]
              - region "Bộ lọc công việc" [ref=e248]:
                - generic [ref=e249]:
                  - button "Góc nhìn công việc" [ref=e250] [cursor=pointer]:
                    - generic [ref=e251]: Tất cả
                  - button "Góc nhìn đã lưu" [ref=e255] [cursor=pointer]:
                    - generic [ref=e256]: Bộ lọc tùy chọn
                - generic [ref=e260]:
                  - textbox "Tìm trong công việc" [ref=e261]
                  - button "Tìm" [ref=e262] [cursor=pointer]
                  - button "Đặt lại" [ref=e263] [cursor=pointer]
                - group [ref=e264]:
                  - generic "Bộ lọc" [ref=e265] [cursor=pointer]
                - generic [ref=e267]:
                  - textbox "Tên góc nhìn đã lưu" [ref=e268]
                  - button "Lưu góc nhìn mới" [disabled] [ref=e269] [cursor=pointer]
                - generic "Danh sách" [ref=e270]:
                  - paragraph [ref=e271]: 12 công việc
                  - button "Đưa đón trẻ chromium Gia đình · Không ưu tiên · Không hạn Synthetic tag B chromium · Synthetic tag A chromium" [ref=e272] [cursor=pointer]:
                    - generic [ref=e273]: Đưa đón trẻ chromium
                    - generic [ref=e274]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e275]: Synthetic tag B chromium · Synthetic tag A chromium
                  - button "Đưa đón trẻ chromium phụ Gia đình · Không ưu tiên · Không hạn Synthetic tag A chromium" [ref=e276] [cursor=pointer]:
                    - generic [ref=e277]: Đưa đón trẻ chromium phụ
                    - generic [ref=e278]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e279]: Synthetic tag A chromium
                  - button "Synthetic P05 completed chromium ui-completed-recent- Gia đình · Không ưu tiên · Không hạn home" [ref=e280] [cursor=pointer]:
                    - generic [ref=e281]: Synthetic P05 completed chromium ui-completed-recent-
                    - generic [ref=e282]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e283]: home
                  - button "Synthetic P05 completed chromium ui-completed-month- Gia đình · Không ưu tiên · Không hạn home" [ref=e284] [cursor=pointer]:
                    - generic [ref=e285]: Synthetic P05 completed chromium ui-completed-month-
                    - generic [ref=e286]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e287]: home
                  - button "Synthetic P05 completed chromium ui-completed-quarter- Gia đình · Không ưu tiên · Không hạn home" [ref=e288] [cursor=pointer]:
                    - generic [ref=e289]: Synthetic P05 completed chromium ui-completed-quarter-
                    - generic [ref=e290]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e291]: home
                  - button "Synthetic P05 completed chromium ui-completed-older- Gia đình · Không ưu tiên · Không hạn home" [ref=e292] [cursor=pointer]:
                    - generic [ref=e293]: Synthetic P05 completed chromium ui-completed-older-
                    - generic [ref=e294]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e295]: home
                  - button "Synthetic recurrence ui-repeat-chromium Gia đình · Không ưu tiên · 2027-01-31 home" [ref=e296] [cursor=pointer]:
                    - generic [ref=e297]: Synthetic recurrence ui-repeat-chromium
                    - generic [ref=e298]: Gia đình · Không ưu tiên · 2027-01-31
                    - generic [ref=e299]: home
                  - button "Synthetic recurrence ui-repeat-completion-chromium Gia đình · Không ưu tiên · Không hạn home" [ref=e300] [cursor=pointer]:
                    - generic [ref=e301]: Synthetic recurrence ui-repeat-completion-chromium
                    - generic [ref=e302]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e303]: home
                  - button "Synthetic UI root chromium Gia đình · Không ưu tiên · Không hạn home" [ref=e304] [cursor=pointer]:
                    - generic [ref=e305]: Synthetic UI root chromium
                    - generic [ref=e306]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e307]: home
                  - button "Synthetic UI child chromium Gia đình · Không ưu tiên · Không hạn home" [ref=e308] [cursor=pointer]:
                    - generic [ref=e309]: Synthetic UI child chromium
                    - generic [ref=e310]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e311]: home
                  - button "Synthetic UI private member chromium Gia đình · Không ưu tiên · Không hạn home" [ref=e312] [cursor=pointer]:
                    - generic [ref=e313]: Synthetic UI private member chromium
                    - generic [ref=e314]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e315]: home
                  - button "Synthetic unrelated P15 Task SSE Gia đình · Không ưu tiên · Không hạn" [ref=e316] [cursor=pointer]:
                    - generic [ref=e317]: Synthetic unrelated P15 Task SSE
                    - generic [ref=e318]: Gia đình · Không ưu tiên · Không hạn
    - button "AI assistant" [ref=e319]
  - button "Thêm công việc mới" [ref=e323] [cursor=pointer]
```

# Test source

```ts
  1  | import {loginProductivityActor as login} from './productivity-actor-login.js';import {test as base,expect,type Page} from '@playwright/test';import {installOfflineNetworkBoundary} from './offline-network-boundary.js';import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
  2  | const seed=JSON.parse(process.env.FO_HABITS_SEED??'null'),panel=(page:Page)=>page.getByTestId('habit-workspace'),detail=(page:Page)=>panel(page).getByRole('region',{name:'Chi tiết thói quen',exact:true});
  3  | const test=base.extend<{boundary:void}>({boundary:[async({context,page,baseURL},use)=>{if(!baseURL||!seed?.synthetic||seed.productivityVersion!==20)throw Error('Owned synthetic Habit20 fixture required');const external:string[]=[],errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));await installOfflineNetworkBoundary(context,baseURL,external);await context.addInitScript(()=>{if(['http:','https:'].includes(location.protocol))localStorage.setItem('family_lang','vi');});await use();expect(external).toEqual([]);expect(errors).toEqual([]);},{auto:true}]});
  4  | test.beforeAll(async({browser,browserName})=>{const folder=path.join('reports/habits',browserName);fs.mkdirSync(folder,{recursive:true});fs.writeFileSync(path.join(folder,'runtime.json'),JSON.stringify({browserName,browserVersion:browser.version(),executableSha256:createHash('sha256').update(fs.readFileSync(browser.browserType().executablePath())).digest('hex'),node:process.version,platform:process.platform,architecture:process.arch}));});
  5  | async function request(page:Page,url:string,method='GET',body?:unknown,token?:string,key?:string){return page.evaluate(async({url,method,body,token,key})=>{const response=await fetch('/api/productivity'+url,{method,headers:{Authorization:'Bearer '+(token??localStorage.getItem('family_token')),'Content-Type':'application/json','x-request-id':key??crypto.randomUUID()},...(body===undefined?{}:{body:JSON.stringify(body)})});return {status:response.status,body:await response.json()};},{url,method,body,token,key});}
  6  | async function open(page:Page){await expect(panel(page)).toBeVisible();if(!await panel(page).evaluate(element=>(element as HTMLDetailsElement).open))await panel(page).locator('summary').first().click();await expect(panel(page).getByRole('button',{name:'Tạo thói quen',exact:true})).toBeVisible();}
  7  | const date=(value:string)=>value.split('-').reverse().join('/'),plus=(value:string,days:number)=>new Date(Date.parse(value+'T00:00:00.000Z')+days*86400000).toISOString().slice(0,10);
  8  | async function dates(page:Page){const value=(await request(page,'/habits')).body.clock,parts=new Intl.DateTimeFormat('en-CA',{timeZone:value.timezone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(value.nowUtc)),get=(name:string)=>parts.find(part=>part.type===name)!.value,today=get('year')+'-'+get('month')+'-'+get('day'),weekday=new Date(today+'T00:00:00Z').getUTCDay()||7,previousMonday=plus(today,-weekday-6);return {today,previousMonday};}
  9  | async function pick(page:Page,label:string,value:string){await panel(page).getByRole('button',{name:label,exact:true}).click();await page.getByRole('option',{name:value,exact:true}).click();}
  10 | async function inputDate(page:Page,label:string,value:string){await panel(page).getByRole('textbox',{name:label,exact:true}).fill(date(value));await panel(page).getByRole('textbox',{name:label,exact:true}).press('Tab');}
  11 | const habitInput=(title:string,startDate:string,isShared=false)=>({title,note:'Synthetic Habit browser note',isShared,startDate,policy:{frequency:{kind:'daily'},goal:{kind:'boolean',target:1,unit:''},timezone:'Asia/Saigon'}});
  12 | test('P15 weekly numeric Habit creates once after lost ACK; original check-in retries once and exact raw progress remains separate from its2/3 weekly goal',async({page})=>{await login(page);await open(page);const {previousMonday}=await dates(page),title='Synthetic P15 numeric weekly',createCalls:any[]=[];await panel(page).getByRole('button',{name:'Tạo thói quen',exact:true}).click();await panel(page).getByLabel('Tên thói quen',{exact:true}).fill(title);await inputDate(page,'Ngày bắt đầu thói quen',previousMonday);await pick(page,'Lịch thói quen','Số lần mỗi tuần');await panel(page).getByLabel('Số lần mỗi tuần',{exact:true}).fill('3');await pick(page,'Loại mục tiêu','Mục tiêu bằng số');await panel(page).getByLabel('Mục tiêu mỗi ngày',{exact:true}).fill('20');await panel(page).getByLabel('Đơn vị theo dõi',{exact:true}).fill('phút');await page.route('**/api/productivity/habits',async route=>{if(route.request().method()!=='POST'){await route.continue();return;}createCalls.push({key:route.request().headers()['x-request-id'],body:route.request().postDataJSON()});if(createCalls.length===1){expect((await route.fetch()).status()).toBe(200);await route.abort('failed');}else await route.continue();});await panel(page).getByRole('button',{name:'Lưu thói quen',exact:true}).click();await expect(panel(page).getByRole('button',{name:'Kiểm tra thao tác theo dõi đã gửi',exact:true})).toBeEnabled();await page.getByTestId('task-projections').getByRole('button',{name:'Lịch công việc',exact:true}).click();await page.getByTestId('task-projections').getByRole('button',{name:'Danh sách',exact:true}).click();await panel(page).getByRole('button',{name:'Kiểm tra thao tác theo dõi đã gửi',exact:true}).click();await expect(detail(page)).toContainText(title);expect(createCalls).toHaveLength(2);expect(createCalls[1]).toEqual(createCalls[0]);const rows=(await request(page,'/habits')).body.items.filter((row:any)=>row.title===title);expect(rows).toHaveLength(1);const habit=rows[0];await inputDate(page,'Mốc ngày xem tiến độ',previousMonday);await inputDate(page,'Ngày check-in hoặc ghi bù',previousMonday);await expect(detail(page).getByLabel('Giá trị tiến độ',{exact:true})).toBeEnabled();await detail(page).getByLabel('Giá trị tiến độ',{exact:true}).fill('7.5');const logCalls:any[]=[];await page.route('**/api/productivity/habits/'+habit.id+'/logs',async route=>{if(route.request().method()!=='POST'){await route.continue();return;}logCalls.push({key:route.request().headers()['x-request-id'],body:route.request().postDataJSON()});if(logCalls.length===1){expect((await route.fetch()).status()).toBe(200);await route.abort('failed');}else await route.continue();});await detail(page).getByRole('button',{name:'Lưu tiến độ',exact:true}).click();await expect(panel(page).getByRole('button',{name:'Kiểm tra thao tác theo dõi đã gửi',exact:true})).toBeEnabled();await panel(page).getByRole('button',{name:'Kiểm tra thao tác theo dõi đã gửi',exact:true}).click();expect(logCalls).toHaveLength(2);expect(logCalls[1]).toEqual(logCalls[0]);await page.unroute('**/api/productivity/habits/'+habit.id+'/logs');await expect(detail(page).getByLabel('Giá trị tiến độ',{exact:true})).toHaveValue('7.5');await expect(detail(page).getByRole('button',{name:'Lưu tiến độ',exact:true})).toBeEnabled();await detail(page).getByLabel('Giá trị tiến độ',{exact:true}).fill('20');await detail(page).getByRole('button',{name:'Lưu tiến độ',exact:true}).click();await inputDate(page,'Ngày check-in hoặc ghi bù',plus(previousMonday,2));await expect(detail(page).getByLabel('Giá trị tiến độ',{exact:true})).toBeEnabled();await detail(page).getByLabel('Giá trị tiến độ',{exact:true}).fill('44.25');await detail(page).getByRole('button',{name:'Lưu tiến độ',exact:true}).click();await expect(detail(page).getByTestId('habit-report')).toContainText('Đạt 2 / 3 mục tiêu');const logPage=(await request(page,'/habits/'+habit.id+'/logs?fromDate='+previousMonday+'&toDateExclusive='+plus(previousMonday,7))).body;expect(logPage.items.map((row:any)=>row.value)).toEqual([20,44.25]);expect(logPage.items[0].revision).toBe(2);});
  13 | test('P15 an unsent own check-in survives unrelated Task SSE; revocation removes its uncertain command/current Focus label and denies original replay',async({page})=>{const admin=await login(page);await open(page);const {previousMonday}=await dates(page),value=habitInput('PRIVATE_P15_SHARED_TITLE',previousMonday,true),created=await request(page,'/habits','POST',{expectedRevision:0,input:value});expect(created.status).toBe(200);const h=created.body.habit;await login(page,'member');await open(page);await panel(page).getByRole('button',{name:value.title,exact:true}).click();await inputDate(page,'Ngày check-in hoặc ghi bù',previousMonday);await expect(detail(page).getByLabel('Đánh dấu đã đạt mục tiêu',{exact:true})).toBeEnabled();await detail(page).getByLabel('Đánh dấu đã đạt mục tiêu',{exact:true}).check();expect((await request(page,'/tasks','POST',{expectedRevision:0,input:{listId:'legacy-family',title:'Synthetic unrelated P15 Task SSE',isShared:true}},admin)).status).toBe(200);await expect(detail(page).getByLabel('Đánh dấu đã đạt mục tiêu',{exact:true})).toBeChecked();await expect(detail(page)).toContainText('bản nháp chưa lưu');await detail(page).getByRole('button',{name:'Pomodoro cho thói quen',exact:true}).click();await expect(page.getByTestId('focus-workspace')).toContainText(value.title);const calls:any[]=[];await page.route('**/api/productivity/habits/'+h.id+'/logs',async route=>{if(route.request().method()!=='POST'){await route.continue();return;}calls.push({key:route.request().headers()['x-request-id'],body:route.request().postDataJSON()});expect((await route.fetch()).status()).toBe(200);await route.abort('failed');});await detail(page).getByRole('button',{name:'Lưu tiến độ',exact:true}).click();await expect(panel(page).getByRole('button',{name:'Kiểm tra thao tác theo dõi đã gửi',exact:true})).toBeEnabled();expect((await request(page,'/habits','POST',{expectedRevision:h.revision,input:{...value,id:h.id,isShared:false}},admin)).status).toBe(200);await expect(page.getByText(value.title,{exact:true})).toHaveCount(0);await expect(panel(page).getByRole('button',{name:'Kiểm tra thao tác theo dõi đã gửi',exact:true})).toHaveCount(0);await expect(page.getByTestId('focus-workspace')).toContainText('Liên kết đã được ẩn theo quyền hiện tại.');expect(calls).toHaveLength(1);await page.unroute('**/api/productivity/habits/'+h.id+'/logs');expect((await request(page,'/habits/'+h.id+'/logs','POST',calls[0].body,undefined,calls[0].key)).status).toBe(404);await page.getByTestId('focus-workspace').getByRole('button',{name:'Kết thúc Focus',exact:true}).click();await expect(page.getByTestId('focus-workspace').getByRole('region',{name:'Phiên Focus hiện tại',exact:true})).toHaveCount(0);});
  14 | test('P15 important dates keep inclusive today and positive anniversary/leap policy and fit390px in both actual themes',async({page})=>{await login(page);await open(page);const {today}=await dates(page);await page.setViewportSize({width:390,height:844});for(const theme of ['light','dark']){await page.evaluate(theme=>localStorage.setItem('family_theme',theme),theme);await page.reload();await open(page);const title='Synthetic important date '+theme;await panel(page).getByRole('button',{name:'Thêm ngày quan trọng',exact:true}).click();await panel(page).getByLabel('Tên ngày quan trọng',{exact:true}).fill(title);await inputDate(page,'Ngày gốc cần theo dõi',today);await panel(page).getByLabel('Tính cả ngày hiện tại',{exact:true}).check();await panel(page).getByRole('button',{name:'Lưu ngày quan trọng',exact:true}).click();await expect(panel(page).getByRole('region',{name:'Chi tiết ngày quan trọng',exact:true})).toContainText('Hôm nay · 1 ngày');const row=(await request(page,'/countdowns')).body.items.find((row:any)=>row.title===title);expect(row).toMatchObject({policy:{inclusive:true,date:today},value:{days:1,direction:'today'}});await panel(page).locator('summary').first().scrollIntoViewIfNeeded();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBe(true);expect(await page.evaluate(()=>document.documentElement.classList.contains('dark'))).toBe(theme==='dark');await page.screenshot({path:'reports/habits/'+test.info().project.name+'/habits-390-'+theme+'.png'});await panel(page).getByRole('region',{name:'Chi tiết ngày quan trọng',exact:true}).scrollIntoViewIfNeeded();await page.screenshot({path:'reports/habits/'+test.info().project.name+'/countdown-390-'+theme+'.png'});}await panel(page).getByRole('button',{name:'Thêm ngày quan trọng',exact:true}).click();await panel(page).getByLabel('Tên ngày quan trọng',{exact:true}).fill('Synthetic leap anniversary');await inputDate(page,'Ngày gốc cần theo dõi','2024-02-29');await pick(page,'Cách theo dõi ngày','Theo dõi kỷ niệm gốc');await panel(page).getByLabel('Lặp lại hằng năm',{exact:true}).check();await pick(page,'Quy tắc ngày 29/2','Chờ năm có đúng ngày 29/2');await panel(page).getByRole('button',{name:'Lưu ngày quan trọng',exact:true}).click();const result=(await request(page,'/countdowns')).body.items.find((row:any)=>row.title==='Synthetic leap anniversary');expect(result.policy).toMatchObject({date:'2024-02-29',kind:'anniversary',annual:true,leapPolicy:'skip'});expect(result.value.direction).toBe('elapsed');expect(result.value.days).toBeGreaterThan(0);await expect(panel(page).getByRole('region',{name:'Chi tiết ngày quan trọng',exact:true})).toContainText('Đã qua');});
> 15 | test('P15 finishing Habit stopwatch leaves check-ins/Tasks unchanged and reviewed archive preserves read-only history',async({page})=>{await login(page);await open(page);const {previousMonday}=await dates(page),value=habitInput('Synthetic P15 timer archive',previousMonday),first=await request(page,'/habits','POST',{expectedRevision:0,input:value});expect(first.status).toBe(200);const h=first.body.habit;await panel(page).getByRole('button',{name:value.title,exact:true}).click();const beforeTasks=(await request(page,'/tasks')).body.tasks;await detail(page).getByRole('button',{name:'Bấm giờ cho thói quen',exact:true}).click();const focus=page.getByTestId('focus-workspace');await expect(focus.getByRole('region',{name:'Phiên Focus hiện tại',exact:true})).toContainText(value.title);await focus.getByRole('button',{name:'Kết thúc Focus',exact:true}).click();await expect(focus.getByRole('region',{name:'Phiên Focus hiện tại',exact:true})).toHaveCount(0);expect((await request(page,'/tasks')).body.tasks).toEqual(beforeTasks);expect((await request(page,'/habits/'+h.id+'/logs?fromDate='+previousMonday+'&toDateExclusive='+plus(previousMonday,7))).body.items).toEqual([]);await panel(page).locator('article[data-habit-id="'+h.id+'"]').getByRole('button',{name:'Lưu trữ mục',exact:true}).click();const dialog=page.getByRole('dialog',{name:'Xác nhận lưu trữ mục',exact:true});await expect(dialog).toContainText('check-in');await dialog.getByRole('button',{name:'Lưu trữ mục',exact:true}).click();await expect(detail(page)).toContainText('Mục đã lưu trữ');expect((await request(page,'/habits/'+h.id)).body.habit.archivedAt).not.toBeNull();await panel(page).getByLabel('Xem mục đã lưu trữ',{exact:true}).check();await expect(panel(page).getByRole('button',{name:value.title,exact:true})).toBeVisible();});
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ^ Error: locator.check: Clicking the checkbox did not change its state
  16 | 
```