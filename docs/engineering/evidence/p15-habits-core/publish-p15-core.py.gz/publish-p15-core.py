from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
root=Path('/workspace/Family-Organizer');ev=Path('/workspace/family-evidence');out=root/'docs/engineering/evidence/p15-habits-core';out.mkdir(exist_ok=True)
sha='2bd0bc6568ef14d1493aabbb07fef0cdd0f63cbc';base='d04ffe21f342a3dfdfe5c0d838f6f0910aab1d91';h=lambda v:hashlib.sha256(v).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==sha
full=json.loads((ev/'p15-core-full.json').read_text());assert full['success'] and full['numTotalTests']==full['numPassedTests']==8867 and len(full['testResults'])==565 and full['numFailedTests']==full['numPendingTests']==full.get('numTodoTests',0)==0
cases=ET.parse(ev/'p15-core-full.junit.xml').getroot().findall('.//testcase');assert len(cases)==8867 and not any(c.find(tag)is not None for c in cases for tag in ['failure','error','skipped'])
def identities(report):
 result=collections.Counter()
 for file in report['testResults']:
  name=str(Path(file['name']).relative_to(root))
  for case in file['assertionResults']:
   assert case['status']=='passed';title=case['fullName']
   if name=='server/recoveryRetention.test.ts':title=re.sub(r'/tmp/fo test synthetic [A-Za-z0-9]+(?=/|$)','/tmp/fo test synthetic <fixture>',title)
   result[(name,title)]+=1
 return result
before=identities(json.loads((ev/'p14-focus-full.json').read_text()));after=identities(full);assert sum(before.values())==8793 and not before-after,before-after
assert sum((after-before).values())==74
stems=['p15-core-full','p15-build-second','p15-lint-mobile-heatmap','p15-browser-second']+[f'p15-qualified-browser-{name}'for name in ['focus','data','attachments','content','templates','notifications','collaboration','calendar']]
for stem in stems:assert (ev/(stem+'.exit')).read_text().strip()=='0',stem
browser={}
for feature,count,version in [('habits',4,20),('focus',4,19),('data',4,18),('attachments',3,17),('content',4,16),('templates',3,15),('notifications',4,14),('collaboration',3,13),('calendar',4,13)]:
 folder=root/'reports'/feature/'chromium';report=json.loads((folder/'browser.json').read_text());fixture=json.loads((folder/'fixture.json').read_text());assert report['stats']['expected']==count and report['stats']['unexpected']==report['stats']['flaky']==report['stats']['skipped']==0
 assert fixture['commitSha']==sha and fixture['seed']['productivityVersion']==version and fixture['nodeVersion']=='v24.21.0' and fixture['platform']=='linux' and all(fixture[k]for k in ['synthetic','databaseClosed','fixtureRemoved','legacyPreserved']) and fixture['integrity']=='ok' and fixture['error']is None and not fixture['networkAttempts'] and fixture['serverExitCode']==fixture['browserExitCode']==0
 for key,name in [('server','dist/server.cjs'),('index','dist/index.html')]:assert fixture['build'][key]==h((root/name).read_bytes())
 def check(suites):
  for suite in suites:
   for spec in suite.get('specs',[]):
    for t in spec['tests']:assert t['status']=='expected' and len(t['results'])==1 and t['results'][0]['status']=='passed'
   check(suite.get('suites',[]))
 check(report['suites']);testcases=ET.parse(folder/'browser.junit.xml').getroot().findall('.//testcase');assert len(testcases)==count and not any(c.find(tag)is not None for c in testcases for tag in ['failure','error','skipped'])
 browser[feature]={'passed':count,'firstAttemptsOnly':True,'fixture':fixture}
source={}
for name in subprocess.check_output(['git','diff','--name-only',base,sha],cwd=root,text=True).splitlines():
 data=subprocess.check_output(['git','show',sha+':'+name],cwd=root);assert (root/name).read_bytes()==data,name;source[name]=h(data)
for name in ['schema.ts','migrate.ts','tagSchema.ts','pinSchema.ts','viewSchema.ts','matrixSchema.ts','boardSchema.ts','seriesSchema.ts','occurrenceSchema.ts','occurrenceSkipSchema.ts','legacyCutoverSchema.ts','notificationSchema.ts','templateSchema.ts','contentSchema.ts','taskAttachmentSchema.ts','importSchema.ts','focusSchema.ts']:
 assert subprocess.check_output(['git','show',base+':server/productivity/'+name],cwd=root)==subprocess.check_output(['git','show',sha+':server/productivity/'+name],cwd=root),name
for ref in [base,sha]:
 text=subprocess.check_output(['git','show',ref+':server/productivity/structureSchema.ts'],cwd=root,text=True);sql=re.search(r'export const structureSchemaSql=`(.*?)`;',text,re.S).group(1)
 if ref==base:frozenSql=sql
 else:assert sql==frozenSql
for name in ['package.json','package-lock.json']:assert subprocess.check_output(['git','show',base+':'+name],cwd=root)==(root/name).read_bytes()
assert h((root/'package-lock.json').read_bytes())=='17e305b217c2dbd6543d66e2e600c20251425c5b4d0eb66fa903cbd13ecc6ec7'
retained={}
def retain(file,name):
 data=file.read_bytes();target=out/(name+'.gz');target.write_bytes(gzip.compress(data,mtime=0));retained[name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes()),'uncompressedSha256':h(data)}
for file in sorted(ev.glob('p15-*')):
 if file.is_file()and file.suffix in ['.json','.xml','.log','.exit','.txt']:retain(file,file.name)
for feature in browser:
 for name in ['browser.json','browser.junit.xml','fixture.json','runtime.json','run.log','server.log']:retain(root/'reports'/feature/'chromium'/name,feature+'-final-'+name)
for file in (ev/'p15-browser-first-artifacts').rglob('*'):
 if file.is_file()and file.suffix in ['.json','.xml','.log','.md','.zip','.png','.webm']:retain(file,'browser-first-'+str(file.relative_to(ev/'p15-browser-first-artifacts')).replace('/','__'))
for file in (root/'reports/habits/chromium').glob('*390-*.png'):
 target=out/file.name;target.write_bytes(file.read_bytes());retained[file.name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes()),'visuallyInspected':True,'scope':'Actual390px Habits, numeric heatmap and Countdown viewports in light and dark.'}
retain(ev/'publish-p15-core.py','publish-p15-core.py')
proof={'taskId':'P15 Habits/Countdown core functional slice; reminders/Calendar still open','sourceCommit':sha,'backendSource':'ffa472d5b79b47ca7bc0148f8571385d86a34c84','uiSource':'bf106385492d0de85fe6c9c4b471a0130f1eef94','prUrl':None,'ciRunUrl':None,'qualification':'Cloud functional development only; final composed Windows pending','fullRegression':{'passed':8867,'files':565,'junitCases':8867,'failed':0,'skipped':0,'todo':0,'parentPassed':8793,'added':74,'removed':0},'lintExitCode':0,'buildExitCode':0,'buildSource':sha,'browser':browser,'sourceFiles':source,'schema':{'explicitPilotVersion':20,'defaultVersion':6,'frozen1to19Preserved':True,'packageCapsChanged':False},'review':{'independent':False,'scope':'Author review only: actor-owned logs, original dated goals/timezones, current SQL ACL before receipts and inside I01, off-page references, source-bound SDK/previews, pending metadata and check-in retention, current Focus link redaction, archive history and snapshot validation.'},'developmentFailures':['Cold missing-module/API/SDK/controller checkpoints failed or could not collect; raw native exits remain historical failures.','A new seven-day fixture report was initially compared with a one-element expectation. The correction adds explicit length7 and date/value assertions; no acceptance behavior removed.','Two TypeScript string assertion precedence errors, a seed excess property and a missing controller entry-draft/read-version initialization failed validation and were fixed.','First actual four-browser run atbf10638 had3passed/1failed: controlled Show Archived checkbox reverted before refresh published the requested filter. Production refresh now publishes the requested filter immediately; a new unit case failed before the fix and passed after. Original browser failure DOM/video/trace retained.','Second run at qualified source passed4/4 plus29parent journeys, all first attempts with no timeout, retry, skip or assertion relaxation.'],'scope':['Habit daily/selected ISO weekdays/weekly quotas, raw numeric values and capped display, per-user unique date logs with frozen goal/timezone and audit, next-Monday policy changes, explicit scoped streaks/partial weeks and permanent archive history.','Own or family metadata; current adult family reviewers may inspect personal logs, Children only their own. No phantom Tasks/rewards or financial effects. Internal HTTP/session only; SSE audiences checked without private labels.','Countdown today0/inclusive1, positive anniversary elapsed, stored annual Feb29 clamp/skip and original anchor/timezone.','Real Habit-linked Focus authority/current redaction, no automatic check-in. Strict SDK and provider-owned original unknown commands/nonce/revisions and unsent day drafts survive unrelated Task SSE/navigation; role/source/logout/late-response fences.','Paged100 lists, bounded current-ACL reference resolution, own/adult historical heatmap, reasoned edits/backfill/skip, vi/en/zh and inspected390px light/dark.'],'retainedEvidence':retained,'remaining':['P15 reminders and optional Calendar layer/typed summary refs remain open; this checkpoint does not complete all P15.','P16–P18, remaining Wallet/W18/M1/I02/I03, capacity/performance and independent review remain open.','Final composed mandatory Windows Node22/24/three engines/package/service/pilot acceptance is pending; nine feature harnesses are not yet mandatory Windows CI.','No new PR/Actions run. Actual Server2019 R02 separate/unrun; release/tag/VPS/PC runner not performed.']}
(root/'docs/engineering/evidence/p15-habits-core-development.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
(root/'docs/engineering/productivity-habits.md').write_text('''# P15 Habits and important dates: core checkpoint

Source2bd0bc6568ef14d1493aabbb07fef0cdd0f63cbc adds explicit pilot20 with
five native tables. Default6, frozen1–19 DDL/checksums and packagecaps13 remain
unchanged. This checkpoint covers the core; reminders and optional Calendar
layer remain open. It is Cloud functional proof, not Windows qualification.

Daily, selected ISO weekdays and weekly-quota policies have explicit denominators.
Numeric check-ins retain raw values; display progress caps at100%. Each user's
unique dated log preserves its original goal/timezone and ordered audit. Edits to
frequency/goals take effect next Monday; the editor preserves a pending policy.
Skip is not completion. Day streaks treat skip neutrally; weekly quotas still
apply. Streaks are scoped to the selected range, with partial-week coverage.
Archive keeps read-only history and stops future denominator growth.

Private metadata belongs to its owner; family metadata is readable by current
roles, writable by owner or Admin. Children write/read their own logs; adults
review other logs only for a currently shared habit. Current native ACL precedes
receipt lookup and is repeated inside I01. Real internal HTTP and SSE tests check
that another Child does not receive a peer's personal check-in stream.

Countdowns retain the source date/timezone, today0 or inclusive1, annual leap
clamp/skip and positive elapsed anniversaries. Habit-linked Focus uses actual
current authority, can redact revoked labels and never creates a check-in,
phantom Task, reward or money entry. Shared restoration validates all20 records.

The provider keeps original unknown commands, revisions and nonces as well as
unsent check-ins through unrelated Task SSE/navigation. Revocation/logout fence
late responses. Historical previews bind exact source/date/user revisions; stale
input requires explicit reload. Lists are paged100; reference resolution is
bounded and applies SQL ACL before decoding. Existing controls/theme/i18n remain.

Full8867tests565files/matchingJUnit,0failed-skipped-todo preserve all8793parent
cases plus74. Lint/build0. Same-build Chromium33/33 first attempts cover Habits4
and all29parent feature journeys with owned offline fixtures, normal stop,
integrity, closed handles and cleanup. Six actual390px root/heatmap/countdown
screenshots were inspected across light/dark. First browser run3/4 exposed an
actual asynchronous archive-filter controller race; its new unit regression and
original browser trace/video/DOM remain in the evidence. No assertions, retries,
timeouts or standards were weakened. Review is author-only.

[Retained reports and failures](evidence/p15-habits-core-development.json).
Next P15 reminders/Calendar, P16–P18/remainingWallet/W18/M1/I02/I03, then composed
Windows qualification. No new PR/Actions/Windows acceptance, release/tag/VPS or
PC runner. Actual Server2019 acceptance is separate R02 and remains unrun.
''')
with (root/'docs/engineering/implementation-status.md').open('a')as file:file.write('''\n\n### P15 Habit/Countdown core Cloud checkpoint (2026-10-18)\n\n- Source2bd0bc6568ef14d1493aabbb07fef0cdd0f63cbc, backendffa472d/UIbf10638; PR URL/CI run URL not created for feature-first group. Explicit20/default6/frozen1–19/packagecaps13 unchanged. Per-actor dated check-ins, policy history, raw numeric goals, heatmap/backfill/skip/archive, important dates and actual Habit–Focus link are usable. Reminders/Calendar remain open, so P15 is not complete.\n- Full8867tests565files/matchingJUnit/0failed-skipped-todo; all8793parent+74 preserved, lint/build0. Chromium33/33 same-source/build first attempts, nine owned/offline fixtures/normal stop/integrity/closed/cleaned. Six actual390px light/dark screenshots inspected. First browser3/4 exposed archive checkbox async controller race; production fix plus actual RED→GREEN unit case and failure video/DOM/trace retained. [Evidence](evidence/p15-habits-core-development.json). No assertion/timeout/retry weakening.\n- Next P15 reminders/optional Calendar and typed refs, P16–P18/remainingWallet/W18/M1/I02/I03 then final composed Windows Node22/24/three engines/package/service/performance/pilot acceptance. New nine feature harnesses not yet mandatory Windows. No new PR/Actions or Windows claim. R02 Server2019 separate/unrun; release/tag/VPS/PC runner not performed.\n''')
print('Validated8867full/33browser; retained',len(retained),'artifacts')
