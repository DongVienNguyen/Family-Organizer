from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
root=Path('/workspace/Family-Organizer');ev=Path('/workspace/family-evidence');out=root/'docs/engineering/evidence';sha='7a73d55ba4659d7b5641e9b346fecdde947319cf';base='6d743622d7fd7e8dfe696ec952271e273597cb34'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==sha
h=lambda b:hashlib.sha256(b).hexdigest()
full=json.loads((ev/'p12-collaboration-full.json').read_text());parent=json.loads((ev/'p11-calendar-full.json').read_text())
assert full['success'] and full['numTotalTests']==full['numPassedTests']==8502
assert full['numFailedTests']==full['numPendingTests']==full.get('numTodoTests',0)==0 and len(full['testResults'])==512
cases=ET.parse(ev/'p12-collaboration-full.junit.xml').getroot().findall('.//testcase');assert len(cases)==8502 and not any(c.find(tag)is not None for c in cases for tag in ['failure','error','skipped'])
old_title='read-grant Member keeps existing semantic comments without generic edit permission';new_title='P12 read grants deny comment writes; an explicit contribution grant retains existing semantic comments'
def identities(report):
 result=collections.Counter()
 for file in report['testResults']:
  name=str(Path(file['name']).relative_to(root))
  for case in file['assertionResults']:
   assert case['status']=='passed';title=case['fullName']
   if name=='server/recoveryRetention.test.ts':title=re.sub(r'/tmp/fo test synthetic [A-Za-z0-9]+(?=/|$)','/tmp/fo test synthetic <fixture>',title)
   if name=='server/productivity/access.api.test.ts' and title==new_title:title=old_title
   result[(name,title)]+=1
 return result
before,after=identities(parent),identities(full);assert sum(before.values())==8459 and not before-after,before-after
assert sum((after-before).values())==43
stems=['p12-collaboration-full','p12-collaboration-final-lint','p12-collaboration-final-build','p12-collaboration-browser-final','p12-collaboration-calendar-final']
for stem in stems:assert(ev/(stem+'.exit')).read_text().strip()=='0',stem
browsers={}
for feature,count in [('collaboration',3),('calendar',4)]:
 folder=root/'reports'/feature/'chromium';report=json.loads((folder/'browser.json').read_text());fixture=json.loads((folder/'fixture.json').read_text());assert report['stats']['expected']==count and report['stats']['unexpected']==report['stats']['flaky']==report['stats']['skipped']==0
 assert fixture['commitSha']==sha and fixture['nodeVersion']=='v24.21.0' and fixture['platform']=='linux'
 assert fixture['seed']['synthetic'] and fixture['seed']['productivityVersion']==13
 assert all(fixture[k]for k in ['databaseClosed','fixtureRemoved','legacyPreserved'])
 assert fixture['integrity']=='ok' and fixture['error']is None and not fixture['networkAttempts'] and fixture['serverExitCode']==fixture['browserExitCode']==0 and fixture['browserSignal']==fixture['serverSignal']==None
 for key,name in [('server','dist/server.cjs'),('index','dist/index.html')]:assert fixture['build'][key]==h((root/name).read_bytes())
 tests=ET.parse(folder/'browser.junit.xml').getroot().findall('.//testcase');assert len(tests)==count and not any(c.find(tag)is not None for c in tests for tag in ['failure','error','skipped'])
 def check(suites):
  for suite in suites:
   for spec in suite.get('specs',[]):
    for test in spec['tests']:assert test['status']=='expected' and len(test['results'])==1 and test['results'][0]['status']=='passed'
   check(suite.get('suites',[]))
 check(report['suites']);browsers[feature]={'passed':count,'failed':0,'skipped':0,'flaky':0,'firstAttemptsOnly':True,'fixture':fixture}
files=subprocess.check_output(['git','diff','--name-only',base,sha],cwd=root,text=True).splitlines();assert 'package-lock.json'not in files and not any(name.endswith('Schema.ts')for name in files)
source={name:h(subprocess.check_output(['git','show',sha+':'+name],cwd=root))for name in files}
for name,digest in source.items():assert h((root/name).read_bytes())==digest,name
assert h((root/'package-lock.json').read_bytes())=='17e305b217c2dbd6543d66e2e600c20251425c5b4d0eb66fa903cbd13ecc6ec7'
causal=json.loads((ev/'p12-causal-baseline.json').read_text());assert causal['baselineCommit']==base and causal['fixtureRemoved'] and len(causal['cases'])==2 and all(c['exitCode']==1 and c['actualAssertionFailure']for c in causal['cases'])
retained={}
for file in sorted([*ev.glob('p12-*'),ev/'publish-p12-collaboration.py']):
 if file.is_file()and file.suffix in ['.json','.xml','.log','.exit','.py']:
  target=out/(file.name+'.gz');target.write_bytes(gzip.compress(file.read_bytes(),mtime=0));retained[file.name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes())}
for feature in ['collaboration','calendar']:
 folder=root/'reports'/feature/'chromium'
 for name in ['browser.json','browser.junit.xml','fixture.json','runtime.json','run.log','server.log']:
  file=folder/name;target=out/('p12-'+feature+'-final.'+name+'.gz');target.write_bytes(gzip.compress(file.read_bytes(),mtime=0));retained[feature+'/'+name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes())}
for file in (root/'reports/collaboration/chromium').glob('comments-390-*.png'):
 target=out/('p12-'+file.name);target.write_bytes(file.read_bytes());retained[file.name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes()),'visuallyInspected':True}
proof={'taskId':'P12 collaboration functional core','sourceCommit':sha,'baseHead':base,'prUrl':None,'ciRunUrl':None,'qualification':'Cloud development only; P12 reminders/quiet hours/digest and final Windows remain','sourceFiles':source,'unit':{'passed':8502,'files':512,'junitCases':8502,'failed':0,'skipped':0,'todo':0,'parentPassed':8459,'added':43,'parentIdentityPolicyTransition':{'file':'server/productivity/access.api.test.ts','before':old_title,'after':new_title,'reason':'Approved P12 requires comment edit scope. Original three assertions remain: generic edit403 at read scope; comment200 and exact content after a real I01 write grant. Added read-comment403 and unchanged-task assertions. No assertion deleted/skip/retry relaxation.'}},'lintExitCode':0,'buildExitCode':0,'browser':browsers,'causalBaseline':causal,'findings':['The exact pre-change native baseline admits a nonowner shared Child comment and duplicates clock-derived comment/history IDs; both retained AssertionErrors now have direct regressions.','Actual HTTP mention failure exposed sender-bound recipient lookup. The internal adapter reads the live recipient identity separately while the caller remains the owning comment I01 command.','Actual SSE failure exposed previous-audience union with global notification invalidation. New mentions use server-owned recipient scope; wire events contain no titles, content or IDs.','First full suite8500pass/2fail retained: explicit legacy transaction ownership join added without a static allowlist, and the intentional P12 comment policy transition retains all old assertions while adding negative read-scope checks.','Comments, history and mentions share the canonical Task payload/revision and I01 receipt. No duplicate comment database, scheduler, provider call or public API.','Opaque session-owned uncertain comment and grant packets survive native SSE/navigation with unchanged body/revision/key, but fresh Task or manager-scope loss/logout retires them and fences late effects.','Three browser journeys cover Unicode comment/mention lost ACK through Calendar navigation, reviewed list grant lost ACK through drawer navigation, and real SSE revocation of private history/composer; all four parent Calendar journeys also pass.'], 'retainedEvidence':retained,'review':{'independent':False,'scope':'Author inspection of canonical/legacy ACL and current recipient authority, native transaction joins/rollback/receipts, reference-only outbox/restart claim, targeted SSE, immutable paging, session packet privacy and DESIGN tokens; both actual390px themes inspected.'},'remaining':['P12 is partial: persisted reminder scheduling, quiet hours, daily digest, cancellation/rescheduling and restored notification backlog policy remain. Existing shared push retry/backoff/unknown-effect semantics are reused; external delivery is not exactly once.','Whole42Productivity/nativeTouch and65Wallet browser suites not repeated for this slice; final composed Windows must include all parents plus Calendar and Collaboration harnesses. Neither new harness is wired to Windows CI yet.','Node22/24 Windows2022/package/service/performance and actualServer2019R02 unrun for this source.','Remaining P13–P18/W18/M1/I02/I03/master are not complete. No release/tag/VPS/PC runner.']}
(out/'p12-collaboration-development.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
(root/'docs/engineering/productivity-collaboration.md').write_text('''# P12 collaboration functional core

Canonical Task comments, immutable history and current-authority mention recipients
are available in the task drawer. The same I01 receipt owns the comment, history,
activity and targeted inbox/outbox references. There is no new comment store or
schema migration. Existing native push retries/leases remain shared; tests use an
explicit offline push adapter. External provider receipt is not exactly once.

Commenting now requires the same edit scope as the Task command, including on the
canonical legacy HTTP adapter. A read grant can inspect history but cannot append.
This is the approved P12 permission change: the old P03 semantic-comment test now
checks read-scope comment403/no mutation, retains generic-edit403 there, upgrades
through the real I01 contribution grant, then retains its comment200/exact-content
assertions. No assertion was removed or skipped. Noncanonical legacy behavior is
retained. UUID comment/history IDs do not depend on clock resolution.

The drawer reads bounded50-entry pages (maximum100) with current Task ACL. Cursors
bind actor, kind and Task revision; historical duplicate IDs are preserved using
source indices, and unknown legacy dates remain explicit. Mention choices contain
only live family users who can currently read this Task; the worker checks current
source access before the offline/native push adapter. The new inbox invalidation
is scoped to recipients; SSE never carries bodies, titles, IDs or counts.

List managers can inspect and review grants for existing adult Members. The UI
label Contribute maps to the existing write permission. Children/guests cannot
receive grants; there is no invitation service. Existing family-shared read access
is clearly distinguished from individual grants before removal.

A session owner retains uncertain comment/grant packets through SSE, closing the
drawer and projection navigation. Retry sends the original body/revision/key.
Current Task/management denial or logout clears private packets and fences late
continuations. An explicit conflict reload permits review before a new send;
there is no automatic retry, rebasing or offline write queue.

Source7a73d55: full Cloud8502tests512files/matching JUnit, lint/build0. All8459
parent cases remain, with the one documented policy transition above and43 new
cases. Whole Collaboration Chromium3/3 and Calendar4/4 first attempts, isolated
schema13 fixtures, offline boundary, integrity/normal-stop/closed/cleaned and exact
source/build hashes. Both390px themes were inspected. Original baseline/HTTP/SSE/
full-suite failures and final reports are retained in
[evidence](evidence/p12-collaboration-development.json).

P12 is not complete: durable reminders, per-user quiet hours/digest, update
cancellation/rescheduling and restore backlog consumption are next. Final composed
Windows must include the parent suites plus both new feature harnesses; neither
new harness is currently wired to Windows CI. No Windows result is inferred from
Cloud. Server2019 R02, release/tag and VPS deployment remain separate/unrun.
''')
p=root/'docs/engineering/implementation-status.md';s=p.read_text();anchor='## Current direction — 2026-10-18 (UTC)\n\n';entry=f'''**P12 collaboration functional core (2026-10-18):** source `{sha}`
adds canonical comments/history/mentions and reviewed list grants, native I01/
outbox reuse, current-source ACL/targeted SSE and immutable unknown-request
packets across navigation. Cloud full8502tests512files/JUnit, zero failures/skips/
todo; parent8459 retained with one explicit stronger P12 policy transition,
43 new cases; lint/build0. Whole Collaboration Chromium3/3 + parentCalendar4/4,
first attempts/offline/owned13fixture/normal-stop/integrity/closed/cleaned and
source/build-bound. Actual390px themes inspected. Native baseline/HTTP/SSE/full-
suite failures retained, no assertion removal or skip. [Details](productivity-collaboration.md),
[proof](evidence/p12-collaboration-development.json). Author review only.
PR URL/CI run URL:none for this source; backup branch. P12 remains partial:
reminders/quiet hours/daily digest/reschedule/restore backlog next, then remaining
P/W18/M1/I02/I03 and final composed Windows (allparents+Calendar+Collaboration
harnesses). Neither new harness is wired to Windows CI yet. No Windows/Server2019
acceptance claim, release/tag/VPS or PC runner.

''';assert '**P12 collaboration functional core (2026-10-18):**'not in s;p.write_text(s.replace(anchor,anchor+entry,1))
print(json.dumps({'source':sha,'unitTests':8502,'files':512,'newTests':43,'browsers':{'collaboration':3,'calendar':4},'retainedFiles':len(retained),'prUrl':None,'ciRunUrl':None}))
