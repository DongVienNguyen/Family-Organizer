from pathlib import Path
import subprocess,json,gzip,hashlib,collections,xml.etree.ElementTree as ET
r=Path('/workspace/Family-Organizer');e=Path('/workspace/family-evidence');d=r/'docs/engineering/evidence';sha='7cae94af340ac4596f1fe8f12e754d33bd548cec';base='847c3dfce49520e988755b15217db02fe3deec62';h=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==sha
preservation=json.loads((e/'w17-import-preservation.json').read_text());assert preservation['currentPassed']==8409 and preservation['removed']==0
for name in ['w17-import-full','w17-import-lint','w17-import-build','w17-import-browser']:assert(e/(name+'.exit')).read_text().strip()=='0',name
b=r/'reports/wallet/chromium';fixture=json.loads((b/'fixture.json').read_text());browser=json.loads((b/'browser.json').read_text());assert fixture['commitSha']==sha and fixture['seed']['walletVersion']==16 and fixture['error']is None
for key in ['databaseClosed','fixtureRemoved','legacyPreserved']:assert fixture[key],key
assert fixture['serverExitCode']==fixture['browserExitCode']==0 and fixture['serverSignal']==fixture['browserSignal']==None and not fixture['networkAttempts'] and fixture['integrity']=='ok'
assert browser['stats']['expected']==65 and browser['stats']['unexpected']==browser['stats']['flaky']==browser['stats']['skipped']==0
cases=ET.parse(b/'browser.junit.xml').getroot().findall('.//testcase');assert len(cases)==65 and not any(c.find(t)is not None for c in cases for t in ['failure','error','skipped'])
old=ET.parse(e/'w16-final-browser-artifacts/browser.junit.xml').getroot().findall('.//testcase');assert not(collections.Counter(c.attrib['name'] for c in old)-collections.Counter(c.attrib['name'] for c in cases))
for name,file in {'server':'dist/server.cjs','index':'dist/index.html'}.items():assert fixture['build'][name]==h((r/file).read_bytes())
sourceFiles={file:h(subprocess.check_output(['git','show',sha+':'+file],cwd=r))for file in subprocess.check_output(['git','diff','--name-only',base,sha],cwd=r,text=True).splitlines()}
for file,digest in sourceFiles.items():assert h((r/file).read_bytes())==digest,file
retained={}
paths=sorted({*e.glob('w17-import-*'),*e.glob('w17-prepare-failure-*'),*e.glob('w17-preview-batch-*'),e/'publish-w17-import.py'})
for file in paths:
 if file.is_file() and file.suffix in ['.json','.xml','.log','.exit','.py']:
  target=d/(file.name+'.gz');target.write_bytes(gzip.compress(file.read_bytes(),mtime=0));retained[file.name]={'path':str(target.relative_to(r)),'sha256':h(target.read_bytes())}
for name in ['browser.json','browser.junit.xml','fixture.json','runtime.json','run.log','server.log']:
 file=b/name
 if file.exists():
  target=d/('w17-import-whole.'+name+'.gz');target.write_bytes(gzip.compress(file.read_bytes(),mtime=0));retained['whole-browser/'+name]={'path':str(target.relative_to(r)),'sha256':h(target.read_bytes())}
metrics=[]
for line in (e/'w17-import-full.log').read_text().splitlines():
 if line.startswith('{"synthetic'):metrics.append(json.loads(line))
proof={'taskId':'W17 import responsiveness subset','qualification':'Cloud functional development, not full W17 or Windows acceptance','sourceCommit':sha,'baseHead':base,'prUrl':None,'ciRunUrl':None,'sourceFiles':sourceFiles,'aggregate':preservation,'lintExitCode':0,'buildExitCode':0,'browser':{'scope':'whole Wallet Chromium','cases':65,'unexpected':0,'flaky':0,'skipped':0,'fixture':fixture},'importMeasurementsFromFullRun':metrics,'baseline':'Original unchanged21import tests passed before changes;10k synchronous commit8758.799ms. Raw baseline and subsequent failures retained. Cloud concurrent runs are diagnostics, not a controlled Windows qualification.','retainedEvidence':retained,'review':{'independent':False,'scope':'author inspection of opaque pure preparation, exact int64 JSON1 binding, one synchronous I01 writer/current ACL catalog fences, rollback and source manifest/receipt/audit preservation'},'remaining':['Complete protected cross-module recovery, global producer capacity/retention and W18 bridge/networth/cutover remain.','Preview yields per128validations; parser/mapping/hash and final atomic SQL still synchronous bounded work. Do not promise a zero-block event loop.','All8391 W16 parent tests are retained with18additional cases,8409total. New system harness is uncommitted test-only development outside this source and is not part of this aggregate.','No automatic schema preparation/activation or production package-cap change.','No feature PR/CI run yet. Final Windows2022 Node22/24/browser/ZIP/service performance batch and actual Server2019 R02 unrun.','Remaining Productivity/M1/I02/I03/master work incomplete; no release/tag/VPS.']}
(d/'w17-import-development.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n')
entry=f"""**W17 import subset (2026-10-18):** source `{sha}` adds cooperative queued
preparation and set-based exact int64 ledger/provenance/audit writes inside one
I01 transaction, with current ACL/catalog/preview fences and safe queued-failure
state. Preview yields and rechecks current references before persistence.
Benchmark rejects a preloaded installation without touching or closing its DB.
Cloud full8409tests498files/matching JUnit/zero failed-skipped-todo,
all8391 W16 parents +18 retained; lint/build0. Whole Wallet Chromium65/65,
all65parent cases, offline/integrity/normal-stop/closed/cleaned/build-bound.
Original10k commit diagnostic8758.8ms; current focused1198.6ms; queued writer
~0.8s with heartbeats and only0/10000observable rows. These are Cloud diagnostics,
not Windows performance acceptance. [Proof](evidence/w17-import-development.json).
PR/CI URLs:none; author inspection only; backup branch. New system recovery
harness remains separate development. W17 full recovery/system, W18 global
capacity/retention/legacy bridge/networth/cutover, remaining P/M1/I02/I03/master
and final composed Windows batch remain. Server2019 R02 unrun; no release/tag/VPS.

"""
status=r/'docs/engineering/implementation-status.md';text=status.read_text();anchor='## Current direction — 2026-10-18 (UTC)\n\n';assert '**W17 import subset (2026-10-18):**'not in text;status.write_text(text.replace(anchor,anchor+entry,1))
with(r/'docs/engineering/wallet-performance.md').open('a')as file:file.write('\n## Queued import development\n\n'+entry)
print(json.dumps({'source':sha,'aggregate':8409,'files':498,'browser':65,'retained':len(retained)}))
