# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: productivity-settings.spec.ts >> P17 personal settings lost acknowledgement retains original command, current revision conflicts require explicit review, and switching actors changes owner defaults
- Location: tests/e2e/productivity-settings.spec.ts:9:1

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: getByTestId('productivity-settings').getByRole('button', { name: 'Kiểm tra thiết lập đã gửi', exact: true })
Expected: enabled
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" getByTestId('productivity-settings').getByRole('button', { name: 'Kiểm tra thiết lập đã gửi', exact: true }) with timeout 10000ms
  - waiting for getByTestId('productivity-settings').getByRole('button', { name: 'Kiểm tra thiết lập đã gửi', exact: true })

```

```yaml
- complementary:
  - text: Family Organizer Không gian gia đình
  - navigation:
    - button "Tổng quan"
    - button "Nhóm Task"
    - button "Chi tiêu"
    - button "Lập Lịch"
    - button "Ghi chú"
    - button "Đi chợ"
    - button "Sức khỏe gia đình"
    - button "Giấy tờ"
    - button "Quản lý Server"
    - button "Thiết lập"
  - button "Mở hồ sơ của Synthetic admin": S Synthetic admin Quản lý (Admin) • v1.1.0
  - button "Đăng xuất"
- banner:
  - text: "Đồng bộ: Đang kết nối"
  - button "Tìm kiếm toàn cục"
  - button "Chuyển sang Giao diện Tối"
  - button
- main:
  - group: Tập trung
  - button "Danh sách" [pressed]
  - button "Kanban hiện có"
  - button "Matrix"
  - button "Kanban"
  - button "Lịch công việc"
  - button "Tổng kết tuần"
  - region "Công việc theo danh sách":
    - group "Thiết lập công việc của tôi"
    - group "Thói quen và ngày quan trọng"
    - region "Nhập nhanh có xem trước":
      - heading "Nhập nhanh có xem trước" [level=3]
      - textbox "Tên công việc mới"
      - group:
        - button "Danh sách cho việc mới": Gia đình
      - button "Xem bản nháp công việc" [disabled]
      - checkbox "Giữ nguyên văn, không phân tích từ khóa"
      - text: Giữ nguyên văn, không phân tích từ khóa
      - paragraph: "Ví dụ: Dọn phòng mai 8h #nhà. Nhãn chỉ lấy từ danh mục bạn đang được phép xem. Luôn xem trước rồi xác nhận; không gọi AI hoặc tự tạo nhãn."
      - status
    - group: Tổ chức danh sách, sections và tags
    - group "Mẫu tác vụ cá nhân"
    - group "Nhập và xuất công việc"
    - region "Bộ lọc công việc":
      - button "Góc nhìn công việc": Tất cả
      - button "Góc nhìn đã lưu": Bộ lọc tùy chọn
      - textbox "Tìm trong công việc"
      - button "Tìm"
      - button "Đặt lại"
      - group: Bộ lọc
      - textbox "Tên góc nhìn đã lưu"
      - button "Lưu góc nhìn mới" [disabled]
      - paragraph: 12 công việc
      - button "Đưa đón trẻ chromium Gia đình · Không ưu tiên · Không hạn Synthetic tag A chromium · Synthetic tag B chromium"
      - button "Đưa đón trẻ chromium phụ Gia đình · Không ưu tiên · Không hạn Synthetic tag A chromium"
      - button "Synthetic P05 completed chromium ui-completed-recent- Gia đình · Không ưu tiên · Không hạn home"
      - button "Synthetic P05 completed chromium ui-completed-month- Gia đình · Không ưu tiên · Không hạn home"
      - button "Synthetic P05 completed chromium ui-completed-quarter- Gia đình · Không ưu tiên · Không hạn home"
      - button "Synthetic P05 completed chromium ui-completed-older- Gia đình · Không ưu tiên · Không hạn home"
      - button "Synthetic recurrence ui-repeat-chromium Gia đình · Không ưu tiên · 2027-01-31 home"
      - button "Synthetic recurrence ui-repeat-completion-chromium Gia đình · Không ưu tiên · Không hạn home"
      - button "Synthetic UI root chromium Gia đình · Không ưu tiên · Không hạn home"
      - button "Synthetic UI child chromium Gia đình · Không ưu tiên · Không hạn home"
      - button "Synthetic UI private member chromium Gia đình · Không ưu tiên · Không hạn home"
      - button "Dọn phòng Gia đình · Không ưu tiên · 2026-10-20T01:00:00.000Z nhà"
- button "AI assistant"
- button "Thêm công việc mới"
```

# Test source

```ts
  1  | import {loginProductivityActor as login} from './productivity-actor-login.js';import {test as base,expect,type Page} from '@playwright/test';import {installOfflineNetworkBoundary} from './offline-network-boundary.js';import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
  2  | const seed=JSON.parse(process.env.FO_PREFERENCES_SEED??'null'),settings=(page:Page)=>page.getByTestId('productivity-settings'),capture=(page:Page)=>page.getByTestId('task-capture'),projections=(page:Page)=>page.getByTestId('task-projections');
  3  | const test=base.extend<{boundary:void}>({boundary:[async({context,page,baseURL},use)=>{if(!baseURL||!seed?.synthetic||seed.productivityVersion!==23)throw Error('Owned synthetic Preferences23 fixture required');const external:string[]=[],errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));await installOfflineNetworkBoundary(context,baseURL,external);await context.addInitScript(()=>{if(['http:','https:'].includes(location.protocol))localStorage.setItem('family_lang','vi');});await use();expect(external).toEqual([]);expect(errors).toEqual([]);},{auto:true}]});
  4  | test.beforeAll(async({browser,browserName})=>{const folder=path.join('reports/preferences',browserName);fs.mkdirSync(folder,{recursive:true});fs.writeFileSync(path.join(folder,'runtime.json'),JSON.stringify({browserName,browserVersion:browser.version(),executableSha256:createHash('sha256').update(fs.readFileSync(browser.browserType().executablePath())).digest('hex'),node:process.version,platform:process.platform,architecture:process.arch}));});
  5  | async function request(page:Page,url:string,method='GET',body?:unknown,token?:string,key?:string){return page.evaluate(async({url,method,body,token,key})=>{const response=await fetch('/api/productivity'+url,{method,headers:{Authorization:'Bearer '+(token??localStorage.getItem('family_token')),'Content-Type':'application/json','x-request-id':key??crypto.randomUUID()},...(body===undefined?{}:{body:JSON.stringify(body)})});return {status:response.status,body:await response.json()};},{url,method,body,token,key});}
  6  | async function defaults(page:Page,patch:Record<string,unknown>={}){const current=(await request(page,'/settings')).body;const next=await request(page,'/settings','PUT',{expectedRevision:current.revision,input:{...current.settings,defaultPriority:'none',defaultDue:'none',smartCapture:false,shortcuts:false,weekStart:1,features:{focus:true,habits:true,insights:true},...patch}});expect(next.status,JSON.stringify(next.body)).toBe(200);await expect(capture(page)).toBeVisible();return next.body;}
  7  | async function openSettings(page:Page){await expect(settings(page)).toBeVisible();if(!await settings(page).evaluate(element=>(element as HTMLDetailsElement).open))await settings(page).locator('summary').click();await expect(settings(page).getByRole('button',{name:'Tải lại thiết lập công việc',exact:true})).toBeEnabled();}
  8  | test('P17 real quick capture keeps literal no-date, previewcancel makes no write, and unknown creation replays once across Calendar navigation',async({page})=>{await login(page);await defaults(page,{smartCapture:true});const tag=await request(page,'/tags','POST',{expectedRevision:0,input:{name:'nhà'}});expect(tag.status).toBe(200);const input=capture(page).getByRole('textbox',{name:'Tên công việc mới',exact:true});await input.fill('Dọn phòng mai 8h #nhà');await capture(page).getByRole('checkbox',{name:'Giữ nguyên văn, không phân tích từ khóa',exact:true}).check();await capture(page).getByRole('button',{name:'Xem bản nháp công việc',exact:true}).click();const preview=capture(page).getByRole('region',{name:'Duyệt bản nháp nhập nhanh',exact:true});await expect(preview).toContainText('Dọn phòng mai 8h #nhà');await expect(preview).toContainText('Không hạn');const before=(await request(page,'/tasks')).body.tasks;await preview.getByRole('button',{name:'Hủy',exact:true}).click();expect((await request(page,'/tasks')).body.tasks).toEqual(before);await capture(page).getByRole('checkbox',{name:'Giữ nguyên văn, không phân tích từ khóa',exact:true}).uncheck();await capture(page).getByRole('button',{name:'Xem bản nháp công việc',exact:true}).click();await expect(preview.getByText('Dọn phòng',{exact:true})).toBeVisible();const calls:{key:string;body:any}[]=[];await page.route('**/api/productivity/tasks',async route=>{if(route.request().method()!=='POST'){await route.continue();return;}calls.push({key:route.request().headers()['x-request-id'],body:route.request().postDataJSON()});if(calls.length===1){expect((await route.fetch()).status()).toBe(200);await route.abort('failed');}else await route.continue();});await preview.getByRole('button',{name:'Xác nhận tạo công việc',exact:true}).click();await expect(capture(page).getByRole('button',{name:'Kiểm tra công việc đã gửi',exact:true})).toBeEnabled();await projections(page).getByRole('button',{name:'Lịch công việc',exact:true}).click();await projections(page).getByRole('button',{name:'Danh sách',exact:true}).click();await expect(input).toHaveValue('Dọn phòng mai 8h #nhà');await capture(page).getByRole('button',{name:'Kiểm tra công việc đã gửi',exact:true}).click();await expect(input).toHaveValue('');expect(calls).toHaveLength(2);expect(calls[1]).toEqual(calls[0]);expect(calls[0].body.input).toMatchObject({title:'Dọn phòng',tagIds:[tag.body.tag.id],due:{kind:'timed',timezone:'Asia/Saigon'}});expect((await request(page,'/tasks')).body.tasks).toHaveLength(before.length+1);});
> 9  | test('P17 personal settings lost acknowledgement retains original command, current revision conflicts require explicit review, and switching actors changes owner defaults',async({page})=>{await login(page);await defaults(page);await openSettings(page);await settings(page).getByRole('checkbox',{name:'Phân tích nhanh tiếng Việt',exact:true}).check();const calls:any[]=[];await page.route('**/api/productivity/settings',async route=>{if(route.request().method()!=='PUT'){await route.continue();return;}calls.push({key:route.request().headers()['x-request-id'],body:route.request().postDataJSON()});if(calls.length===1){expect((await route.fetch()).status()).toBe(200);await route.abort('failed');}else await route.continue();});await settings(page).getByRole('button',{name:'Lưu thiết lập công việc',exact:true}).click();await expect(settings(page).getByRole('button',{name:'Kiểm tra thiết lập đã gửi',exact:true})).toBeEnabled();await projections(page).getByRole('button',{name:'Lịch công việc',exact:true}).click();await projections(page).getByRole('button',{name:'Danh sách',exact:true}).click();await settings(page).getByRole('button',{name:'Kiểm tra thiết lập đã gửi',exact:true}).click();await expect(settings(page).getByRole('button',{name:'Lưu thiết lập công việc',exact:true})).toBeDisabled();expect(calls).toHaveLength(2);expect(calls[1]).toEqual(calls[0]);await page.unroute('**/api/productivity/settings');await settings(page).getByRole('checkbox',{name:'Bật phím tắt công việc',exact:true}).check();const old=(await request(page,'/settings')).body;expect((await request(page,'/settings','PUT',{expectedRevision:old.revision,input:{...old.settings,defaultReminderMinutes:75}})).status).toBe(200);await expect(settings(page).getByRole('button',{name:'Duyệt phiên bản mới, giữ lựa chọn của tôi',exact:true})).toBeEnabled();await expect(settings(page).getByRole('checkbox',{name:'Bật phím tắt công việc',exact:true})).toBeChecked();await expect(settings(page).getByRole('button',{name:'Lưu thiết lập công việc',exact:true})).toBeDisabled();await settings(page).getByRole('button',{name:'Duyệt phiên bản mới, giữ lựa chọn của tôi',exact:true}).click();await settings(page).getByRole('button',{name:'Lưu thiết lập công việc',exact:true}).click();await expect.poll(async()=>(await request(page,'/settings')).body.settings.shortcuts).toBe(true);await login(page,'member');await openSettings(page);await expect(settings(page).getByRole('checkbox',{name:'Phân tích nhanh tiếng Việt',exact:true})).not.toBeChecked();expect((await request(page,'/settings')).body.ownerId).toBe('browser-member');});
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ^ Error: expect(locator).toBeEnabled() failed
  10 | test('P17 keyboard shortcuts ignore text and dialogs, feature visibility never changes Task data, and manual cache cleanup preserves Wallet and auth',async({page})=>{await login(page);await defaults(page,{shortcuts:true,features:{focus:false,habits:false,insights:false}});await openSettings(page);await expect(projections(page).getByRole('button',{name:'Tổng kết tuần',exact:true})).toHaveCount(0);await expect(page.getByTestId('habit-workspace')).toHaveCount(0);const input=capture(page).getByRole('textbox',{name:'Tên công việc mới',exact:true});await input.fill('1 2 3 4 n vẫn là chữ');await input.press('2');await expect(projections(page).getByRole('button',{name:'Danh sách',exact:true})).toHaveAttribute('aria-pressed','true');await input.press('Tab');await page.keyboard.press('4');await expect(projections(page).getByRole('button',{name:'Lịch công việc',exact:true})).toHaveAttribute('aria-pressed','true');await page.keyboard.press('n');await expect(input).toBeFocused();await page.evaluate(async()=>{await caches.open('family-productivity-synthetic');await caches.open('family-wallet-synthetic');});const token=await page.evaluate(()=>localStorage.getItem('family_token')),before=(await request(page,'/tasks')).body.tasks;await settings(page).getByRole('button',{name:'Xóa bộ nhớ công việc trên thiết bị',exact:true}).click();const dialog=page.getByRole('dialog');await expect(dialog).toBeVisible();await page.keyboard.press('2');await expect(projections(page).getByRole('button',{name:'Danh sách',exact:true})).toHaveAttribute('aria-pressed','true');await dialog.getByRole('button',{name:'Xóa bộ nhớ công việc trên thiết bị',exact:true}).click();await expect(settings(page)).toContainText('Đã xóa bộ nhớ thiết bị thuộc miền công việc.');const names=await page.evaluate(()=>caches.keys());expect(names).not.toContain('family-productivity-synthetic');expect(names).toContain('family-wallet-synthetic');expect(await page.evaluate(()=>localStorage.getItem('family_token'))).toBe(token);expect((await request(page,'/tasks')).body.tasks).toEqual(before);});
  11 | test('P17 uncertain draft requires explicit review and preferences/capture fit390px in light and dark without offline writes',async({page})=>{await login(page);await defaults(page,{smartCapture:true});await page.setViewportSize({width:390,height:844});for(const theme of['light','dark']){await page.evaluate(theme=>localStorage.setItem('family_theme',theme),theme);await page.reload();await openSettings(page);await settings(page).scrollIntoViewIfNeeded();expect(await settings(page).evaluate(element=>element.scrollWidth<=element.clientWidth)).toBe(true);await page.screenshot({path:path.join('reports/preferences',test.info().project.name,'settings-390-'+theme+'.png')});await capture(page).getByRole('textbox',{name:'Tên công việc mới',exact:true}).fill('Họp 8h #chưa-có');await capture(page).getByRole('button',{name:'Xem bản nháp công việc',exact:true}).click();const preview=capture(page).getByRole('region',{name:'Duyệt bản nháp nhập nhanh',exact:true});await expect(preview.getByRole('button',{name:'Xác nhận tạo công việc',exact:true})).toBeDisabled();await expect(preview).toContainText('Có giờ nhưng chưa rõ ngày');await expect(preview).toContainText('không tự tạo nhãn');await preview.getByRole('checkbox',{name:'Tôi đã xem các điểm chưa rõ và đồng ý với bản nháp này',exact:true}).check();await expect(preview.getByRole('button',{name:'Xác nhận tạo công việc',exact:true})).toBeEnabled();await preview.scrollIntoViewIfNeeded();expect(await preview.evaluate(element=>element.getBoundingClientRect().right<=innerWidth)).toBe(true);await page.screenshot({path:path.join('reports/preferences',test.info().project.name,'capture-390-'+theme+'.png')});await preview.getByRole('button',{name:'Hủy',exact:true}).click();}const before=(await request(page,'/tasks')).body.tasks;await page.context().setOffline(true);await expect(capture(page).getByRole('button',{name:'Xem bản nháp công việc',exact:true})).toBeDisabled();await page.context().setOffline(false);await expect(capture(page).getByRole('button',{name:'Xem bản nháp công việc',exact:true})).toBeEnabled();expect((await request(page,'/tasks')).body.tasks).toEqual(before);});
  12 | 
```