# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: task-data.spec.ts >> P13 data preview fits390px in both themes and preserves unsupported ICS recurrence as a visible warning without creating Tasks
- Location: tests/e2e/task-data.spec.ts:13:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('group', { name: 'Nhập và xuất công việc', exact: true }).getByRole('article', { name: 'Bản xem trước công việc', exact: true })
Expected substring: "chưa được kích hoạt hoặc đổi sang quy tắc gần đúng"
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('group', { name: 'Nhập và xuất công việc', exact: true }).getByRole('article', { name: 'Bản xem trước công việc', exact: true }) with timeout 10000ms
  - waiting for getByRole('group', { name: 'Nhập và xuất công việc', exact: true }).getByRole('article', { name: 'Bản xem trước công việc', exact: true })

```

```yaml
- banner:
  - button
  - button "Tìm kiếm toàn cục"
  - button "Chuyển sang Giao diện Sáng"
  - button
- main:
  - button "Danh sách" [pressed]
  - button "Kanban hiện có"
  - button "Matrix"
  - button "Kanban"
  - button "Lịch công việc"
  - region "Công việc theo danh sách":
    - textbox "Tên công việc mới"
    - button "Danh sách cho việc mới": Gia đình
    - button "Thêm việc danh sách" [disabled]
    - group: Tổ chức danh sách, sections và tags
    - group "Mẫu tác vụ cá nhân"
    - group "Nhập và xuất công việc":
      - text: Nhập và xuất công việc
      - paragraph: JSON, CSV hoặc ICS; tối đa20MiB và10.000 công việc. Xem trước và kiểm tra danh sách trước khi nhập.
      - region "Nhập từ tệp":
        - heading "Nhập từ tệp" [level=3]
        - text: Chọn tệp công việc
        - button "Chọn tệp công việc"
        - paragraph: Synthetic Calendar dark.ics
        - button "Xem trước tệp"
        - button "Chọn bản nhập của tôi"
      - alert: Tối đa3 bản nhập đang chờ và100MiB dữ liệu nguồn được giữ.
      - button "Tải lại bản nhập"
      - region "Xuất công việc ra tệp":
        - heading "Xuất công việc ra tệp" [level=3]
        - paragraph: Xuất toàn bộ công việc được phép xem trong danh sách. JSON giữ nội dung, checklist và lịch sử; CSV dành cho bảng tính; ICS giữ ngày và văn bản cho lịch. Sao lưu toàn bộ dùng để giữ cả tệp đính kèm.
        - button "Danh sách cần xuất": Gia đình
        - button "Định dạng tệp xuất": JSON
        - button "Tải tệp công việc"
    - region "Bộ lọc công việc":
      - button "Góc nhìn công việc": Tất cả
      - button "Góc nhìn đã lưu": Bộ lọc tùy chọn
      - textbox "Tìm trong công việc"
      - button "Tìm"
      - button "Đặt lại"
      - group: Bộ lọc
      - textbox "Tên góc nhìn đã lưu"
      - button "Lưu góc nhìn mới" [disabled]
      - paragraph: 12 công việc
      - button "Đưa đón trẻ chromium Gia đình · Không ưu tiên · Không hạn Synthetic tag A chromium · Synthetic tag B chromium"
      - button "Đưa đón trẻ chromium phụ Gia đình · Không ưu tiên · Không hạn Synthetic tag A chromium"
      - button "Synthetic P05 completed chromium ui-completed-recent- Gia đình · Không ưu tiên · Không hạn home"
      - button "Synthetic P05 completed chromium ui-completed-month- Gia đình · Không ưu tiên · Không hạn home"
      - button "Synthetic P05 completed chromium ui-completed-quarter- Gia đình · Không ưu tiên · Không hạn home"
      - button "Synthetic P05 completed chromium ui-completed-older- Gia đình · Không ưu tiên · Không hạn home"
      - button "Synthetic recurrence ui-repeat-chromium Gia đình · Không ưu tiên · 2027-01-31 home"
      - button "Synthetic recurrence ui-repeat-completion-chromium Gia đình · Không ưu tiên · Không hạn home"
      - button "Synthetic UI root chromium Gia đình · Không ưu tiên · Không hạn home"
      - button "Synthetic UI child chromium Gia đình · Không ưu tiên · Không hạn home"
      - button "Synthetic UI private member chromium Gia đình · Không ưu tiên · Không hạn home"
      - button "=Synthetic P13 formula text Gia đình · Không ưu tiên · Không hạn"
- button "AI assistant"
- button "Thêm công việc mới"
```

# Test source

```ts
  1  | import {loginProductivityActor as login} from './productivity-actor-login.js';import {test as base,expect,type Page} from '@playwright/test';import {installOfflineNetworkBoundary} from './offline-network-boundary.js';import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
  2  | const seed=JSON.parse(process.env.FO_DATA_SEED??'null'),panel=(page:Page)=>page.getByRole('group',{name:'Nhập và xuất công việc',exact:true}),preview=(page:Page)=>panel(page).getByRole('article',{name:'Bản xem trước công việc',exact:true});
  3  | const test=base.extend<{boundary:void}>({boundary:[async({context,page,baseURL},use)=>{if(!baseURL||!seed?.synthetic||seed.productivityVersion!==18)throw Error('Owned synthetic Task data18 fixture required');const external:string[]=[],errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));await installOfflineNetworkBoundary(context,baseURL,external);await context.addInitScript(()=>{if(['http:','https:'].includes(location.protocol))localStorage.setItem('family_lang','vi');});await use();expect(external).toEqual([]);expect(errors).toEqual([]);},{auto:true}]});
  4  | test.beforeAll(async({browser,browserName})=>{const folder=path.join('reports/data',browserName);fs.mkdirSync(folder,{recursive:true});fs.writeFileSync(path.join(folder,'runtime.json'),JSON.stringify({browserName,browserVersion:browser.version(),executableSha256:createHash('sha256').update(fs.readFileSync(browser.browserType().executablePath())).digest('hex'),node:process.version,platform:process.platform,architecture:process.arch}));});
  5  | async function request(page:Page,path:string,method='GET',body?:unknown,token?:string,key?:string){return page.evaluate(async({path,method,body,token,key})=>{const response=await fetch('/api/productivity'+path,{method,headers:{Authorization:'Bearer '+(token??localStorage.getItem('family_token')),'Content-Type':'application/json','x-request-id':key??crypto.randomUUID()},...(body===undefined?{}:{body:JSON.stringify(body)})});return {status:response.status,body:await response.json()};},{path,method,body,token,key});}
  6  | async function open(page:Page){const summary=page.getByText('Nhập và xuất công việc',{exact:true});await expect(summary).toBeVisible();if(!await panel(page).evaluate(element=>(element as HTMLDetailsElement).open))await summary.click();await expect(panel(page).getByLabel('Chọn tệp công việc',{exact:true})).toBeVisible();}
  7  | async function pick(page:Page,label:string,value:string){await panel(page).getByRole('button',{name:label,exact:true}).click();await page.getByRole('option',{name:value,exact:true}).click();}
  8  | async function file(page:Page,bytes:Buffer,name='Synthetic Tasks.json'){await panel(page).getByLabel('Chọn tệp công việc',{exact:true}).setInputFiles({name,mimeType:'application/octet-stream',buffer:bytes});await panel(page).getByRole('button',{name:'Xem trước tệp',exact:true}).click();}
  9  | const fixture=(rows:unknown[])=>Buffer.from(JSON.stringify({format:'family-organizer.tasks',version:1,tasks:rows}));
  10 | test('P13 Task import keeps original lost-ACK file, previews without writes, reviews/cancels commit, exports lossless IDs and conditionally undoes unchanged items',async({page})=>{await login(page);await open(page);const before=(await request(page,'/tasks')).body.tasks,bytes=fixture([{id:'child',parentId:'root',listId:'external',title:'Synthetic P13 imported child',body:'Nội dung con 漢字'},{id:'root',listId:'external',title:'Synthetic P13 imported parent',body:'**Nội dung gốc**',rewardPoints:999,pendingApproval:true,lifecycle:'completed',creatorId:'forged'},{id:'independent',listId:'external',title:'Synthetic P13 independent Task',checklist:[{id:'old-check',text:'Một bước',done:true}]}]),calls:any[]=[];await page.route('**/api/productivity/imports',async route=>{if(route.request().method()!=='POST'){await route.continue();return;}calls.push({key:route.request().headers()['x-request-id'],name:route.request().headers()['x-file-name'],format:route.request().headers()['x-file-format'],sha256:createHash('sha256').update(route.request().postDataBuffer()!).digest('hex')});if(calls.length===1){expect((await route.fetch()).status()).toBe(200);await route.abort('failed');}else await route.continue();});await file(page,bytes);await expect(panel(page).getByRole('button',{name:'Kiểm tra lệnh dữ liệu đã gửi',exact:true})).toBeEnabled();await page.getByTestId('task-projections').getByRole('button',{name:'Lịch công việc',exact:true}).click();await page.getByTestId('task-projections').getByRole('button',{name:'Danh sách',exact:true}).click();await expect(panel(page).getByRole('button',{name:'Kiểm tra lệnh dữ liệu đã gửi',exact:true})).toBeEnabled();await panel(page).getByRole('button',{name:'Kiểm tra lệnh dữ liệu đã gửi',exact:true}).click();await expect(preview(page)).toContainText('Synthetic P13 imported child');expect(calls).toHaveLength(2);expect(calls[1]).toEqual(calls[0]);expect(calls[0].sha256).toBe(createHash('sha256').update(bytes).digest('hex'));const batches=(await request(page,'/imports')).body.items.filter((row:any)=>row.fileName==='Synthetic Tasks.json');expect(batches).toHaveLength(1);expect((await request(page,'/tasks')).body.tasks).toEqual(before);const list=(await request(page,'/catalog')).body.lists.find((row:any)=>row.id==='legacy-family');await pick(page,'Danh sách đích mặc định',list.title);await preview(page).getByRole('button',{name:'Cập nhật bản xem trước',exact:true}).click();await expect(preview(page).getByRole('button',{name:'Nhập công việc',exact:true})).toBeEnabled();expect((await request(page,'/tasks')).body.tasks).toEqual(before);await preview(page).getByRole('button',{name:'Nhập công việc',exact:true}).click();let confirmation=page.getByRole('dialog',{name:'Xác nhận nhập công việc',exact:true});await expect(confirmation).toContainText('3 công việc mới');await confirmation.getByRole('button',{name:'Hủy',exact:true}).click();expect((await request(page,'/tasks')).body.tasks).toEqual(before);await preview(page).getByRole('button',{name:'Nhập công việc',exact:true}).click();confirmation=page.getByRole('dialog',{name:'Xác nhận nhập công việc',exact:true});await confirmation.getByRole('button',{name:'Nhập công việc',exact:true}).click();await expect(preview(page)).toContainText('Đã nhập xong');const all=(await request(page,'/tasks')).body.tasks,created=all.filter((row:any)=>!before.some((old:any)=>old.id===row.id));expect(created).toHaveLength(3);const parent=created.find((row:any)=>row.title==='Synthetic P13 imported parent'),child=created.find((row:any)=>row.title==='Synthetic P13 imported child');expect(child.parentId).toBe(parent.id);for(const row of created)expect(row).toMatchObject({lifecycle:'todo',rewardPoints:0,pendingApproval:false,assigneeId:null,isShared:false});await pick(page,'Danh sách cần xuất',list.title);const downloading=page.waitForEvent('download');await panel(page).getByRole('button',{name:'Tải tệp công việc',exact:true}).click();const download=await downloading,exported=JSON.parse(fs.readFileSync((await download.path())!,'utf8'));expect(exported.tasks.filter((row:any)=>created.some((task:any)=>task.id===row.id))).toHaveLength(3);expect(exported.tasks.find((row:any)=>row.id===child.id)).toMatchObject({parentId:parent.id,body:child.body});expect((await request(page,'/tasks/'+child.id,'PATCH',{expectedRevision:child.revision,patch:{title:'User edited P13 imported child'}})).status).toBe(200);await preview(page).getByRole('button',{name:'Hoàn tác mục chưa sửa',exact:true}).click();await page.getByRole('dialog',{name:'Xác nhận hoàn tác bản nhập',exact:true}).getByRole('button',{name:'Hoàn tác mục chưa sửa',exact:true}).click();await expect(preview(page)).toContainText('Đã hoàn tác 1; giữ lại 2');const current=(await request(page,'/tasks')).body.tasks;expect(current.find((row:any)=>row.id===child.id)?.title).toBe('User edited P13 imported child');expect(current.some((row:any)=>row.id===parent.id)).toBe(true);expect(current.some((row:any)=>row.id===created.find((row:any)=>row.title==='Synthetic P13 independent Task').id)).toBe(false);});
  11 | test('P13 spreadsheet export prefixes formulas and its checked metadata restores literal titles in a no-write CSV preview',async({page})=>{await login(page);const title='=Synthetic P13 formula text',created=await request(page,'/tasks','POST',{expectedRevision:0,input:{listId:'legacy-family',title,body:'Dòng 1\n漢字',isShared:false}});expect(created.status).toBe(200);await open(page);const list=(await request(page,'/catalog')).body.lists.find((row:any)=>row.id==='legacy-family');await pick(page,'Danh sách cần xuất',list.title);await pick(page,'Định dạng tệp xuất','CSV');const downloading=page.waitForEvent('download');await panel(page).getByRole('button',{name:'Tải tệp công việc',exact:true}).click();const download=await downloading,bytes=fs.readFileSync((await download.path())!);expect(bytes.toString()).toContain("'=Synthetic P13 formula text");const before=(await request(page,'/tasks')).body.tasks;await file(page,bytes,'Synthetic Roundtrip.csv');await expect(preview(page)).toContainText(title);expect((await request(page,'/tasks')).body.tasks).toEqual(before);const batches=(await request(page,'/imports')).body.items,batch=batches.find((row:any)=>row.fileName==='Synthetic Roundtrip.csv'),rows=(await request(page,'/imports/'+batch.id+'/rows')).body.items;expect(rows.find((row:any)=>row.sourceId===created.body.task.id)).toMatchObject({title,bodyPreview:'Dòng 1\n漢字'});});
  12 | test('P13 target grant revocation retires a pending mapping command and refuses its original accepted receipt replay',async({page})=>{const admin=await login(page),list=(await request(page,'/lists','POST',{expectedRevision:0,input:{title:'PRIVATE_ADMIN_IMPORT_TARGET',isShared:false}})).body.list,grant=await request(page,'/lists/'+list.id+'/grant','POST',{expectedRevision:list.revision,input:{userId:'browser-member',permission:'write'}});expect(grant.status).toBe(200);await login(page,'member');await open(page);await file(page,fixture([{id:'own-source',title:'Synthetic Member import',listId:'external'}]),'Synthetic Member Tasks.json');await expect(preview(page)).toContainText('Synthetic Member import');const batch=(await request(page,'/imports')).body.items.find((row:any)=>row.fileName==='Synthetic Member Tasks.json');await pick(page,'Danh sách đích mặc định','PRIVATE_ADMIN_IMPORT_TARGET');const calls:any[]=[];await page.route('**/api/productivity/imports/'+batch.id+'/mapping',async route=>{calls.push({key:route.request().headers()['x-request-id'],body:route.request().postDataJSON()});expect((await route.fetch()).status()).toBe(200);await route.abort('failed');});await preview(page).getByRole('button',{name:'Cập nhật bản xem trước',exact:true}).click();await expect(panel(page).getByRole('button',{name:'Kiểm tra lệnh dữ liệu đã gửi',exact:true})).toBeEnabled();expect((await request(page,'/lists/'+list.id+'/grant','POST',{expectedRevision:grant.body.list.revision,input:{userId:'browser-member',permission:null}},admin)).status).toBe(200);await expect(page.getByText('PRIVATE_ADMIN_IMPORT_TARGET',{exact:true})).toHaveCount(0);await expect(page.getByRole('button',{name:'Kiểm tra lệnh dữ liệu đã gửi',exact:true})).toHaveCount(0);expect(calls).toHaveLength(1);await page.unroute('**/api/productivity/imports/'+batch.id+'/mapping');expect((await request(page,'/imports/'+batch.id+'/mapping','POST',calls[0].body,undefined,calls[0].key)).status).toBe(404);});
> 13 | test('P13 data preview fits390px in both themes and preserves unsupported ICS recurrence as a visible warning without creating Tasks',async({page})=>{await login(page);await page.setViewportSize({width:390,height:844});const ics=Buffer.from(['BEGIN:VCALENDAR','VERSION:2.0','BEGIN:VEVENT','UID:synthetic-ics','SUMMARY:Ngày gia đình 漢字','DTSTART;VALUE=DATE:20280229','RRULE:FREQ=MONTHLY;BYDAY=MO;BYSETPOS=-1','END:VEVENT','END:VCALENDAR',''].join('\r\n'));for(const theme of ['light','dark']){await page.evaluate(theme=>localStorage.setItem('family_theme',theme),theme);await page.reload();await open(page);await panel(page).getByLabel('Chọn tệp công việc',{exact:true}).setInputFiles({name:'Synthetic invalid.svg',mimeType:'image/svg+xml',buffer:Buffer.from('<svg/>')});await expect(panel(page).getByRole('alert')).toContainText('20MiB');const before=(await request(page,'/tasks')).body.tasks;await file(page,ics,'Synthetic Calendar '+theme+'.ics');await expect(preview(page)).toContainText('chưa được kích hoạt hoặc đổi sang quy tắc gần đúng');expect((await request(page,'/tasks')).body.tasks).toEqual(before);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBe(true);expect(await page.evaluate(()=>document.documentElement.classList.contains('dark'))).toBe(theme==='dark');await panel(page).screenshot({path:'reports/data/'+test.info().project.name+'/task-data-390-'+theme+'.png'});}});
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ^ Error: expect(locator).toContainText(expected) failed
  14 | 
```