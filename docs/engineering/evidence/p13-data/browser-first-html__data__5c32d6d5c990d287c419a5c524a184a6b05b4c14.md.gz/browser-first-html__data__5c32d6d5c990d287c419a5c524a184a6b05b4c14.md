# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: task-data.spec.ts >> P13 Task import keeps original lost-ACK file, previews without writes, reviews/cancels commit, exports lossless IDs and conditionally undoes unchanged items
- Location: tests/e2e/task-data.spec.ts:10:1

# Error details

```
Test timeout of 45000ms exceeded.
```

```
Error: locator.click: Test timeout of 45000ms exceeded.
Call log:
  - waiting for getByRole('dialog', { name: 'Xác nhận nhập công việc', exact: true }).getByRole('button', { name: 'Hủy', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - complementary [ref=e4]:
      - generic [ref=e5]:
        - generic [ref=e11]:
          - generic [ref=e12]: Family Organizer
          - text: Không gian gia đình
        - navigation [ref=e13]:
          - button "Tổng quan" [ref=e14] [cursor=pointer]
          - button "Nhóm Task" [ref=e19] [cursor=pointer]
          - button "Chi tiêu" [ref=e24] [cursor=pointer]
          - button "Lập Lịch" [ref=e29] [cursor=pointer]
          - button "Ghi chú" [ref=e33] [cursor=pointer]
          - button "Đi chợ" [ref=e38] [cursor=pointer]
          - button "Sức khỏe gia đình" [ref=e44] [cursor=pointer]
          - button "Giấy tờ" [ref=e49] [cursor=pointer]
          - button "Quản lý Server" [ref=e55] [cursor=pointer]
          - button "Thiết lập" [ref=e60] [cursor=pointer]
      - generic [ref=e65]:
        - button "Mở hồ sơ của Synthetic admin" [ref=e66] [cursor=pointer]:
          - generic [ref=e67]: S
          - generic [ref=e68]:
            - generic [ref=e69]: Synthetic admin
            - generic [ref=e70]: Quản lý (Admin) • v1.1.0
        - button "Đăng xuất" [ref=e71] [cursor=pointer]
    - generic [ref=e75]:
      - banner [ref=e76]:
        - generic [ref=e77]: "Đồng bộ: Đang kết nối"
        - generic [ref=e84]:
          - button "Tìm kiếm toàn cục" [ref=e85] [cursor=pointer]
          - button "Chuyển sang Giao diện Tối" [ref=e89] [cursor=pointer]
          - button [ref=e93] [cursor=pointer]
      - main [ref=e97]:
        - generic [ref=e99]:
          - generic [ref=e100]:
            - button "Danh sách" [pressed] [ref=e101]
            - button "Kanban hiện có" [ref=e102]
            - button "Matrix" [ref=e103]
            - button "Kanban" [ref=e104]
            - button "Lịch công việc" [ref=e105]
          - region "Công việc theo danh sách" [ref=e107]:
            - generic [ref=e108]:
              - generic [ref=e109]:
                - textbox "Tên công việc mới" [ref=e110]
                - button "Danh sách cho việc mới" [ref=e111] [cursor=pointer]:
                  - generic [ref=e112]: Gia đình
                - button "Thêm việc danh sách" [disabled] [ref=e116] [cursor=pointer]
              - group [ref=e118]:
                - generic "Tổ chức danh sách, sections và tags" [ref=e119] [cursor=pointer]
              - group "Mẫu tác vụ cá nhân" [ref=e120]
              - group "Nhập và xuất công việc" [ref=e122]:
                - generic [ref=e124]:
                  - paragraph [ref=e125]: JSON, CSV hoặc ICS; tối đa20MiB và10.000 công việc. Xem trước và kiểm tra danh sách trước khi nhập.
                  - region "Nhập từ tệp" [ref=e126]:
                    - heading "Nhập từ tệp" [level=3] [ref=e127]
                    - generic [ref=e128]:
                      - text: Chọn tệp công việc
                      - button "Chọn tệp công việc" [ref=e129]
                    - button "Chọn bản nhập của tôi" [ref=e130] [cursor=pointer]:
                      - generic [ref=e131]: Synthetic Tasks.json
                    - article "Bản xem trước công việc" [ref=e135]:
                      - heading "Synthetic Tasks.json" [level=4] [ref=e136]
                      - status [ref=e137]: Chờ xem trước · Đã nhập 0/3
                      - list [ref=e138]:
                        - listitem [ref=e139]: Thông tin người tạo, hoàn thành, điểm thưởng và lịch sử nguồn không được dùng để thực hiện hành động mới.
                      - button "Danh sách đích mặc định" [ref=e140] [cursor=pointer]:
                        - generic [ref=e141]: Gia đình
                      - group [ref=e145]:
                        - generic "Ánh xạ riêng từng danh sách nguồn" [ref=e146] [cursor=pointer]
                      - button "Cập nhật bản xem trước" [ref=e147]
                      - paragraph [ref=e148]: Tạo 3 công việc mới, riêng tư và chưa hoàn thành. Không cấp điểm, duyệt công việc hay kích hoạt lịch lặp. Dữ liệu nguồn được giữ để đối chiếu.
                      - button "Nhập công việc" [ref=e149]
                      - paragraph [ref=e150]: Tối đa100 dòng mỗi trang. Phần nội dung dài được xem rút gọn; khi nhập vẫn giữ đầy đủ nội dung hợp lệ.
                      - list [ref=e151]:
                        - listitem [ref=e152]:
                          - paragraph [ref=e153]:
                            - generic [ref=e154]: "2."
                            - text: Synthetic P13 imported parent
                          - paragraph [ref=e155]: "**Nội dung gốc**"
                          - paragraph [ref=e156]: Không có hạn
                        - listitem [ref=e157]:
                          - paragraph [ref=e158]:
                            - generic [ref=e159]: "1."
                            - text: Synthetic P13 imported child
                          - paragraph [ref=e160]: Nội dung con 漢字
                          - paragraph [ref=e161]: Không có hạn
                        - listitem [ref=e162]:
                          - paragraph [ref=e163]:
                            - generic [ref=e164]: "3."
                            - text: Synthetic P13 independent Task
                          - paragraph
                          - paragraph [ref=e165]: Không có hạn
                      - generic [ref=e166]:
                        - button "Trang trước" [disabled] [ref=e167]
                        - generic [ref=e168]: 1–3/3
                        - button "Trang sau" [disabled] [ref=e169]
                  - button "Tải lại bản nhập" [ref=e170]
                  - region "Xuất công việc ra tệp" [ref=e171]:
                    - heading "Xuất công việc ra tệp" [level=3] [ref=e172]
                    - paragraph [ref=e173]: Xuất toàn bộ công việc được phép xem trong danh sách. JSON giữ nội dung, checklist và lịch sử; CSV dành cho bảng tính; ICS giữ ngày và văn bản cho lịch. Sao lưu toàn bộ dùng để giữ cả tệp đính kèm.
                    - button "Danh sách cần xuất" [ref=e174] [cursor=pointer]:
                      - generic [ref=e175]: Gia đình
                    - button "Định dạng tệp xuất" [ref=e179] [cursor=pointer]:
                      - generic [ref=e180]: JSON
                    - button "Tải tệp công việc" [ref=e184]
                - dialog [ref=e186]:
                  - generic [ref=e187]:
                    - heading "Xác nhận nhập công việc" [level=3] [ref=e192]
                    - button "Đóng hộp xác nhận" [active] [ref=e193]
                  - paragraph [ref=e197]: Synthetic Tasks.json Tạo 3 công việc mới, riêng tư và chưa hoàn thành. Không cấp điểm, duyệt công việc hay kích hoạt lịch lặp. Dữ liệu nguồn được giữ để đối chiếu.
                  - generic [ref=e198]:
                    - button "Hủy bỏ" [ref=e199] [cursor=pointer]
                    - button "Nhập công việc" [ref=e200] [cursor=pointer]
              - region "Bộ lọc công việc" [ref=e201]:
                - generic [ref=e202]:
                  - button "Góc nhìn công việc" [ref=e203] [cursor=pointer]:
                    - generic [ref=e204]: Tất cả
                  - button "Góc nhìn đã lưu" [ref=e208] [cursor=pointer]:
                    - generic [ref=e209]: Bộ lọc tùy chọn
                - generic [ref=e213]:
                  - textbox "Tìm trong công việc" [ref=e214]
                  - button "Tìm" [ref=e215] [cursor=pointer]
                  - button "Đặt lại" [ref=e216] [cursor=pointer]
                - group [ref=e217]:
                  - generic "Bộ lọc" [ref=e218] [cursor=pointer]
                - generic [ref=e220]:
                  - textbox "Tên góc nhìn đã lưu" [ref=e221]
                  - button "Lưu góc nhìn mới" [disabled] [ref=e222] [cursor=pointer]
                - generic "Danh sách" [ref=e223]:
                  - paragraph [ref=e224]: 11 công việc
                  - button "Đưa đón trẻ chromium Gia đình · Không ưu tiên · Không hạn Synthetic tag A chromium · Synthetic tag B chromium" [ref=e225] [cursor=pointer]:
                    - generic [ref=e226]: Đưa đón trẻ chromium
                    - generic [ref=e227]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e228]: Synthetic tag A chromium · Synthetic tag B chromium
                  - button "Đưa đón trẻ chromium phụ Gia đình · Không ưu tiên · Không hạn Synthetic tag A chromium" [ref=e229] [cursor=pointer]:
                    - generic [ref=e230]: Đưa đón trẻ chromium phụ
                    - generic [ref=e231]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e232]: Synthetic tag A chromium
                  - button "Synthetic P05 completed chromium ui-completed-recent- Gia đình · Không ưu tiên · Không hạn home" [ref=e233] [cursor=pointer]:
                    - generic [ref=e234]: Synthetic P05 completed chromium ui-completed-recent-
                    - generic [ref=e235]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e236]: home
                  - button "Synthetic P05 completed chromium ui-completed-month- Gia đình · Không ưu tiên · Không hạn home" [ref=e237] [cursor=pointer]:
                    - generic [ref=e238]: Synthetic P05 completed chromium ui-completed-month-
                    - generic [ref=e239]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e240]: home
                  - button "Synthetic P05 completed chromium ui-completed-quarter- Gia đình · Không ưu tiên · Không hạn home" [ref=e241] [cursor=pointer]:
                    - generic [ref=e242]: Synthetic P05 completed chromium ui-completed-quarter-
                    - generic [ref=e243]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e244]: home
                  - button "Synthetic P05 completed chromium ui-completed-older- Gia đình · Không ưu tiên · Không hạn home" [ref=e245] [cursor=pointer]:
                    - generic [ref=e246]: Synthetic P05 completed chromium ui-completed-older-
                    - generic [ref=e247]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e248]: home
                  - button "Synthetic recurrence ui-repeat-chromium Gia đình · Không ưu tiên · 2027-01-31 home" [ref=e249] [cursor=pointer]:
                    - generic [ref=e250]: Synthetic recurrence ui-repeat-chromium
                    - generic [ref=e251]: Gia đình · Không ưu tiên · 2027-01-31
                    - generic [ref=e252]: home
                  - button "Synthetic recurrence ui-repeat-completion-chromium Gia đình · Không ưu tiên · Không hạn home" [ref=e253] [cursor=pointer]:
                    - generic [ref=e254]: Synthetic recurrence ui-repeat-completion-chromium
                    - generic [ref=e255]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e256]: home
                  - button "Synthetic UI root chromium Gia đình · Không ưu tiên · Không hạn home" [ref=e257] [cursor=pointer]:
                    - generic [ref=e258]: Synthetic UI root chromium
                    - generic [ref=e259]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e260]: home
                  - button "Synthetic UI child chromium Gia đình · Không ưu tiên · Không hạn home" [ref=e261] [cursor=pointer]:
                    - generic [ref=e262]: Synthetic UI child chromium
                    - generic [ref=e263]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e264]: home
                  - button "Synthetic UI private member chromium Gia đình · Không ưu tiên · Không hạn home" [ref=e265] [cursor=pointer]:
                    - generic [ref=e266]: Synthetic UI private member chromium
                    - generic [ref=e267]: Gia đình · Không ưu tiên · Không hạn
                    - generic [ref=e268]: home
    - button "AI assistant" [ref=e269]
  - button "Thêm công việc mới" [ref=e273] [cursor=pointer]
```

# Test source

```ts
  1  | import {loginProductivityActor as login} from './productivity-actor-login.js';import {test as base,expect,type Page} from '@playwright/test';import {installOfflineNetworkBoundary} from './offline-network-boundary.js';import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
  2  | const seed=JSON.parse(process.env.FO_DATA_SEED??'null'),panel=(page:Page)=>page.getByRole('group',{name:'Nhập và xuất công việc',exact:true}),preview=(page:Page)=>panel(page).getByRole('article',{name:'Bản xem trước công việc',exact:true});
  3  | const test=base.extend<{boundary:void}>({boundary:[async({context,page,baseURL},use)=>{if(!baseURL||!seed?.synthetic||seed.productivityVersion!==18)throw Error('Owned synthetic Task data18 fixture required');const external:string[]=[],errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));await installOfflineNetworkBoundary(context,baseURL,external);await context.addInitScript(()=>{if(['http:','https:'].includes(location.protocol))localStorage.setItem('family_lang','vi');});await use();expect(external).toEqual([]);expect(errors).toEqual([]);},{auto:true}]});
  4  | test.beforeAll(async({browser,browserName})=>{const folder=path.join('reports/data',browserName);fs.mkdirSync(folder,{recursive:true});fs.writeFileSync(path.join(folder,'runtime.json'),JSON.stringify({browserName,browserVersion:browser.version(),executableSha256:createHash('sha256').update(fs.readFileSync(browser.browserType().executablePath())).digest('hex'),node:process.version,platform:process.platform,architecture:process.arch}));});
  5  | async function request(page:Page,path:string,method='GET',body?:unknown,token?:string,key?:string){return page.evaluate(async({path,method,body,token,key})=>{const response=await fetch('/api/productivity'+path,{method,headers:{Authorization:'Bearer '+(token??localStorage.getItem('family_token')),'Content-Type':'application/json','x-request-id':key??crypto.randomUUID()},...(body===undefined?{}:{body:JSON.stringify(body)})});return {status:response.status,body:await response.json()};},{path,method,body,token,key});}
  6  | async function open(page:Page){const summary=page.getByText('Nhập và xuất công việc',{exact:true});await expect(summary).toBeVisible();if(!await panel(page).evaluate(element=>(element as HTMLDetailsElement).open))await summary.click();await expect(panel(page).getByLabel('Chọn tệp công việc',{exact:true})).toBeVisible();}
  7  | async function pick(page:Page,label:string,value:string){await panel(page).getByRole('button',{name:label,exact:true}).click();await page.getByRole('option',{name:value,exact:true}).click();}
  8  | async function file(page:Page,bytes:Buffer,name='Synthetic Tasks.json'){await panel(page).getByLabel('Chọn tệp công việc',{exact:true}).setInputFiles({name,mimeType:'application/octet-stream',buffer:bytes});await panel(page).getByRole('button',{name:'Xem trước tệp',exact:true}).click();}
  9  | const fixture=(rows:unknown[])=>Buffer.from(JSON.stringify({format:'family-organizer.tasks',version:1,tasks:rows}));
> 10 | test('P13 Task import keeps original lost-ACK file, previews without writes, reviews/cancels commit, exports lossless IDs and conditionally undoes unchanged items',async({page})=>{await login(page);await open(page);const before=(await request(page,'/tasks')).body.tasks,bytes=fixture([{id:'child',parentId:'root',listId:'external',title:'Synthetic P13 imported child',body:'Nội dung con 漢字'},{id:'root',listId:'external',title:'Synthetic P13 imported parent',body:'**Nội dung gốc**',rewardPoints:999,pendingApproval:true,lifecycle:'completed',creatorId:'forged'},{id:'independent',listId:'external',title:'Synthetic P13 independent Task',checklist:[{id:'old-check',text:'Một bước',done:true}]}]),calls:any[]=[];await page.route('**/api/productivity/imports',async route=>{if(route.request().method()!=='POST'){await route.continue();return;}calls.push({key:route.request().headers()['x-request-id'],name:route.request().headers()['x-file-name'],format:route.request().headers()['x-file-format'],sha256:createHash('sha256').update(route.request().postDataBuffer()!).digest('hex')});if(calls.length===1){expect((await route.fetch()).status()).toBe(200);await route.abort('failed');}else await route.continue();});await file(page,bytes);await expect(panel(page).getByRole('button',{name:'Kiểm tra lệnh dữ liệu đã gửi',exact:true})).toBeEnabled();await page.getByTestId('task-projections').getByRole('button',{name:'Lịch công việc',exact:true}).click();await page.getByTestId('task-projections').getByRole('button',{name:'Danh sách',exact:true}).click();await expect(panel(page).getByRole('button',{name:'Kiểm tra lệnh dữ liệu đã gửi',exact:true})).toBeEnabled();await panel(page).getByRole('button',{name:'Kiểm tra lệnh dữ liệu đã gửi',exact:true}).click();await expect(preview(page)).toContainText('Synthetic P13 imported child');expect(calls).toHaveLength(2);expect(calls[1]).toEqual(calls[0]);expect(calls[0].sha256).toBe(createHash('sha256').update(bytes).digest('hex'));const batches=(await request(page,'/imports')).body.items.filter((row:any)=>row.fileName==='Synthetic Tasks.json');expect(batches).toHaveLength(1);expect((await request(page,'/tasks')).body.tasks).toEqual(before);const list=(await request(page,'/catalog')).body.lists.find((row:any)=>row.id==='legacy-family');await pick(page,'Danh sách đích mặc định',list.title);await preview(page).getByRole('button',{name:'Cập nhật bản xem trước',exact:true}).click();await expect(preview(page).getByRole('button',{name:'Nhập công việc',exact:true})).toBeEnabled();expect((await request(page,'/tasks')).body.tasks).toEqual(before);await preview(page).getByRole('button',{name:'Nhập công việc',exact:true}).click();let confirmation=page.getByRole('dialog',{name:'Xác nhận nhập công việc',exact:true});await expect(confirmation).toContainText('3 công việc mới');await confirmation.getByRole('button',{name:'Hủy',exact:true}).click();expect((await request(page,'/tasks')).body.tasks).toEqual(before);await preview(page).getByRole('button',{name:'Nhập công việc',exact:true}).click();confirmation=page.getByRole('dialog',{name:'Xác nhận nhập công việc',exact:true});await confirmation.getByRole('button',{name:'Nhập công việc',exact:true}).click();await expect(preview(page)).toContainText('Đã nhập xong');const all=(await request(page,'/tasks')).body.tasks,created=all.filter((row:any)=>!before.some((old:any)=>old.id===row.id));expect(created).toHaveLength(3);const parent=created.find((row:any)=>row.title==='Synthetic P13 imported parent'),child=created.find((row:any)=>row.title==='Synthetic P13 imported child');expect(child.parentId).toBe(parent.id);for(const row of created)expect(row).toMatchObject({lifecycle:'todo',rewardPoints:0,pendingApproval:false,assigneeId:null,isShared:false});await pick(page,'Danh sách cần xuất',list.title);const downloading=page.waitForEvent('download');await panel(page).getByRole('button',{name:'Tải tệp công việc',exact:true}).click();const download=await downloading,exported=JSON.parse(fs.readFileSync((await download.path())!,'utf8'));expect(exported.tasks.filter((row:any)=>created.some((task:any)=>task.id===row.id))).toHaveLength(3);expect(exported.tasks.find((row:any)=>row.id===child.id)).toMatchObject({parentId:parent.id,body:child.body});expect((await request(page,'/tasks/'+child.id,'PATCH',{expectedRevision:child.revision,patch:{title:'User edited P13 imported child'}})).status).toBe(200);await preview(page).getByRole('button',{name:'Hoàn tác mục chưa sửa',exact:true}).click();await page.getByRole('dialog',{name:'Xác nhận hoàn tác bản nhập',exact:true}).getByRole('button',{name:'Hoàn tác mục chưa sửa',exact:true}).click();await expect(preview(page)).toContainText('Đã hoàn tác 1; giữ lại 2');const current=(await request(page,'/tasks')).body.tasks;expect(current.find((row:any)=>row.id===child.id)?.title).toBe('User edited P13 imported child');expect(current.some((row:any)=>row.id===parent.id)).toBe(true);expect(current.some((row:any)=>row.id===created.find((row:any)=>row.title==='Synthetic P13 independent Task').id)).toBe(false);});
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ^ Error: locator.click: Test timeout of 45000ms exceeded.
  11 | test('P13 spreadsheet export prefixes formulas and its checked metadata restores literal titles in a no-write CSV preview',async({page})=>{await login(page);const title='=Synthetic P13 formula text',created=await request(page,'/tasks','POST',{expectedRevision:0,input:{listId:'legacy-family',title,body:'Dòng 1\n漢字',isShared:false}});expect(created.status).toBe(200);await open(page);const list=(await request(page,'/catalog')).body.lists.find((row:any)=>row.id==='legacy-family');await pick(page,'Danh sách cần xuất',list.title);await pick(page,'Định dạng tệp xuất','CSV');const downloading=page.waitForEvent('download');await panel(page).getByRole('button',{name:'Tải tệp công việc',exact:true}).click();const download=await downloading,bytes=fs.readFileSync((await download.path())!);expect(bytes.toString()).toContain("'=Synthetic P13 formula text");const before=(await request(page,'/tasks')).body.tasks;await file(page,bytes,'Synthetic Roundtrip.csv');await expect(preview(page)).toContainText(title);expect((await request(page,'/tasks')).body.tasks).toEqual(before);const batches=(await request(page,'/imports')).body.items,batch=batches.find((row:any)=>row.fileName==='Synthetic Roundtrip.csv'),rows=(await request(page,'/imports/'+batch.id+'/rows')).body.items;expect(rows.find((row:any)=>row.sourceId===created.body.task.id)).toMatchObject({title,bodyPreview:'Dòng 1\n漢字'});});
  12 | test('P13 target grant revocation retires a pending mapping command and refuses its original accepted receipt replay',async({page})=>{const admin=await login(page),list=(await request(page,'/lists','POST',{expectedRevision:0,input:{title:'PRIVATE_ADMIN_IMPORT_TARGET',isShared:false}})).body.list,grant=await request(page,'/lists/'+list.id+'/grant','POST',{expectedRevision:list.revision,input:{userId:'browser-member',permission:'write'}});expect(grant.status).toBe(200);await login(page,'member');await open(page);await file(page,fixture([{id:'own-source',title:'Synthetic Member import',listId:'external'}]),'Synthetic Member Tasks.json');await expect(preview(page)).toContainText('Synthetic Member import');const batch=(await request(page,'/imports')).body.items.find((row:any)=>row.fileName==='Synthetic Member Tasks.json');await pick(page,'Danh sách đích mặc định','PRIVATE_ADMIN_IMPORT_TARGET');const calls:any[]=[];await page.route('**/api/productivity/imports/'+batch.id+'/mapping',async route=>{calls.push({key:route.request().headers()['x-request-id'],body:route.request().postDataJSON()});expect((await route.fetch()).status()).toBe(200);await route.abort('failed');});await preview(page).getByRole('button',{name:'Cập nhật bản xem trước',exact:true}).click();await expect(panel(page).getByRole('button',{name:'Kiểm tra lệnh dữ liệu đã gửi',exact:true})).toBeEnabled();expect((await request(page,'/lists/'+list.id+'/grant','POST',{expectedRevision:grant.body.list.revision,input:{userId:'browser-member',permission:null}},admin)).status).toBe(200);await expect(page.getByText('PRIVATE_ADMIN_IMPORT_TARGET',{exact:true})).toHaveCount(0);await expect(page.getByRole('button',{name:'Kiểm tra lệnh dữ liệu đã gửi',exact:true})).toHaveCount(0);expect(calls).toHaveLength(1);await page.unroute('**/api/productivity/imports/'+batch.id+'/mapping');expect((await request(page,'/imports/'+batch.id+'/mapping','POST',calls[0].body,undefined,calls[0].key)).status).toBe(404);});
  13 | test('P13 data preview fits390px in both themes and preserves unsupported ICS recurrence as a visible warning without creating Tasks',async({page})=>{await login(page);await page.setViewportSize({width:390,height:844});const ics=Buffer.from(['BEGIN:VCALENDAR','VERSION:2.0','BEGIN:VEVENT','UID:synthetic-ics','SUMMARY:Ngày gia đình 漢字','DTSTART;VALUE=DATE:20280229','RRULE:FREQ=MONTHLY;BYDAY=MO;BYSETPOS=-1','END:VEVENT','END:VCALENDAR',''].join('\r\n'));for(const theme of ['light','dark']){await page.evaluate(theme=>localStorage.setItem('family_theme',theme),theme);await page.reload();await open(page);await panel(page).getByLabel('Chọn tệp công việc',{exact:true}).setInputFiles({name:'Synthetic invalid.svg',mimeType:'image/svg+xml',buffer:Buffer.from('<svg/>')});await expect(panel(page).getByRole('alert')).toContainText('20MiB');const before=(await request(page,'/tasks')).body.tasks;await file(page,ics,'Synthetic Calendar '+theme+'.ics');await expect(preview(page)).toContainText('chưa được kích hoạt hoặc đổi sang quy tắc gần đúng');expect((await request(page,'/tasks')).body.tasks).toEqual(before);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBe(true);expect(await page.evaluate(()=>document.documentElement.classList.contains('dark'))).toBe(theme==='dark');await panel(page).screenshot({path:'reports/data/'+test.info().project.name+'/task-data-390-'+theme+'.png'});}});
  14 | 
```