from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
root=Path('/workspace/Family-Organizer');ev=Path('/workspace/family-evidence');out=root/'docs/engineering/evidence/p13-data';out.mkdir(exist_ok=True)
sha='40031f7e53eef4c9568a58948b71577459da8225';base='7e963b5';production=subprocess.check_output(['git','rev-parse','19787cb'],cwd=root,text=True).strip();h=lambda data:hashlib.sha256(data).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==sha
full=json.loads((ev/'p13-data-full.json').read_text());assert full['success'] and full['numTotalTests']==full['numPassedTests']==8749 and len(full['testResults'])==549 and full['numFailedTests']==full['numPendingTests']==full.get('numTodoTests',0)==0
cases=ET.parse(ev/'p13-data-full.junit.xml').getroot().findall('.//testcase');assert len(cases)==8749 and not any(c.find(tag)is not None for c in cases for tag in ['failure','error','skipped'])
def identities(report):
 result=collections.Counter()
 for file in report['testResults']:
  name=str(Path(file['name']).relative_to(root))
  for c in file['assertionResults']:
   assert c['status']=='passed';title=c['fullName']
   if name=='server/recoveryRetention.test.ts':title=re.sub(r'/tmp/fo test synthetic [A-Za-z0-9]+(?=/|$)','/tmp/fo test synthetic <fixture>',title)
   result[(name,title)]+=1
 return result
before=identities(json.loads((ev/'p13-attachment-full.json').read_text()));after=identities(full);assert sum(before.values())==8675 and not before-after,before-after
assert sum((after-before).values())==74
for stem in ['p13-data-full','p13-data-build-first','p13-data-browser-second','p13-data-lint-ui-report','p13-data-server-functional']+[f'p13-data-parent-{feature}'for feature in ['attachments','content','templates','notifications','collaboration','calendar']]:assert(ev/(stem+'.exit')).read_text().strip()=='0',stem
followup=subprocess.check_output(['git','diff','--name-only',production,sha],cwd=root,text=True).splitlines();assert followup==['tests/e2e/task-data.spec.ts']
browser={}
for feature,count,version in [('data',4,18),('attachments',3,17),('content',4,16),('templates',3,15),('notifications',4,14),('collaboration',3,13),('calendar',4,13)]:
 folder=root/'reports'/feature/'chromium';report=json.loads((folder/'browser.json').read_text());fixture=json.loads((folder/'fixture.json').read_text());assert report['stats']['expected']==count and report['stats']['unexpected']==report['stats']['flaky']==report['stats']['skipped']==0
 assert fixture['commitSha']==sha and fixture['seed']['productivityVersion']==version and fixture['nodeVersion']=='v24.21.0' and fixture['platform']=='linux' and all(fixture[k]for k in ['synthetic','databaseClosed','fixtureRemoved','legacyPreserved']) and fixture['integrity']=='ok' and fixture['error']is None and not fixture['networkAttempts'] and fixture['serverExitCode']==fixture['browserExitCode']==0
 for key,name in [('server','dist/server.cjs'),('index','dist/index.html')]:assert fixture['build'][key]==h((root/name).read_bytes())
 def check(suites):
  for suite in suites:
   for spec in suite.get('specs',[]):
    for t in spec['tests']:assert t['status']=='expected' and len(t['results'])==1 and t['results'][0]['status']=='passed'
   check(suite.get('suites',[]))
 check(report['suites']);cases=ET.parse(folder/'browser.junit.xml').getroot().findall('.//testcase');assert len(cases)==count and not any(c.find(tag)is not None for c in cases for tag in ['failure','error','skipped'])
 browser[feature]={'passed':count,'firstAttemptsOnly':True,'fixture':fixture}
source={}
for name in subprocess.check_output(['git','diff','--name-only',base,sha],cwd=root,text=True).splitlines():
 data=subprocess.check_output(['git','show',sha+':'+name],cwd=root);assert(root/name).read_bytes()==data,name;source[name]=h(data)
for name in ['schema.ts','migrate.ts','tagSchema.ts','pinSchema.ts','viewSchema.ts','matrixSchema.ts','boardSchema.ts','seriesSchema.ts','occurrenceSchema.ts','occurrenceSkipSchema.ts','legacyCutoverSchema.ts','notificationSchema.ts','templateSchema.ts','contentSchema.ts','taskAttachmentSchema.ts']:
 assert subprocess.check_output(['git','show',base+':server/productivity/'+name],cwd=root)==subprocess.check_output(['git','show',sha+':server/productivity/'+name],cwd=root),name
for ref in [base,sha]:
 text=subprocess.check_output(['git','show',ref+':server/productivity/structureSchema.ts'],cwd=root,text=True);sql=re.search(r'export const structureSchemaSql=`(.*?)`;',text,re.S).group(1)
 if ref==base:frozenSql=sql
 else:assert sql==frozenSql
assert h((root/'package-lock.json').read_bytes())=='17e305b217c2dbd6543d66e2e600c20251425c5b4d0eb66fa903cbd13ecc6ec7'
retained={}
def retain(file,name):
 data=file.read_bytes();target=out/(name+'.gz');target.write_bytes(gzip.compress(data,mtime=0));retained[name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes()),'uncompressedSha256':h(data)}
for file in sorted(ev.glob('p13-data-*')):
 if file.is_file()and file.suffix in ['.json','.xml','.log','.exit','.txt']:retain(file,file.name)
for feature in browser:
 for name in ['browser.json','browser.junit.xml','fixture.json','runtime.json','run.log','server.log']:retain(root/'reports'/feature/'chromium'/name,feature+'-final-'+name)
for file in(ev/'p13-data-browser-first-artifacts').rglob('*'):
 if file.is_file()and file.suffix in ['.json','.xml','.log','.md','.zip','.png']:retain(file,'browser-first-'+str(file.relative_to(ev/'p13-data-browser-first-artifacts')).replace('/','__'))
for file in(root/'reports/data/chromium').glob('task-data-390-*.png'):
 target=out/file.name;target.write_bytes(file.read_bytes());retained[file.name]={'path':str(target.relative_to(root)),'sha256':h(target.read_bytes()),'visuallyInspected':True,'scope':'Visible mobile import preview/form; screenshot extends past clipped app scroll container. Desktop journeys exercise the export controls.'}
retain(ev/'publish-p13-data.py','publish-p13-data.py')
proof={'taskId':'P13 owned Task data tools functional slice','sourceCommit':sha,'productionSource':production,'backendSource':'0818db29796cbf3d2569dd9d04cebfe3eeb066d7','fullRegressionSource':sha,'prUrl':None,'ciRunUrl':None,'qualification':'Cloud functional development only; final composed Windows pending','fullRegression':{'passed':8749,'files':549,'junitCases':8749,'failed':0,'skipped':0,'todo':0,'parentPassed':8675,'added':74,'removed':0},'lintExitCode':0,'buildExitCode':0,'buildSource':production,'fixtureOnlyFollowup':followup,'browser':browser,'sourceFiles':source,'schema':{'explicitPilotVersion':18,'defaultVersion':6,'frozen1to17Preserved':True,'packageCapsChanged':False},'review':{'independent':False,'scope':'Author review of actor-owned source previews, typed list mapping/current-create ACL before cache and inside I01, source row/tree/date/byte bounds, non-executed historical facts, shared durable jobs, batch rollback/replay/interrupt, conditional undo references/children, read-only export SQL ACL/revisions/stream checks, Blob/nonce/session/late-feedback fences and actual browser journeys; no independent-review claim.'},'developmentFailures':['Three parser suites and native import/export suites initially failed because new modules did not exist.','TypeScript checkpoints retained: nullable normalized source/checklist IDs, test queryId unknown and narrow malformed-date mock. Corrected typings without weakening runtime validation.','Native regression actually returned an accepted cached mapping receipt after target grant revocation. Fresh create/list revision authority now precedes mapping receipt lookup, with the same checks inside I01; original regression passes.','Original generic invalid-file error omitted row number. Actual failing case now reports the original logical row while refusing to echo private source text; late private feedback is fenced after logout.','First browser4 had2pass/2fail. Cancel fixture used Hủy while existing DOM/locale is Hủy bỏ; unchanged cancel/no-write/import/undo assertions now use the actual button label. That early failure left one preview and caused the later dark ICS preview to reach the genuine3-pending quota. Raw traces/DOM/network/screens retained. Quotas/assertions/timeouts/retries unchanged; final4/4 and all parents pass first attempts.'],'scope':['JSON preserves selected canonical Task fields, checklist and legacy provenance/history. It is not a full installation/media backup. CSV preserves draft fields with explicit reversible spreadsheet escape metadata; ordinary CSV never strips an apostrophe heuristically. ICS preserves dates/text; original unsupported recurrence remains opaque source facts with a warning and is not activated or approximated.','Imports create fresh private unfinished Tasks/checklist IDs, without imported creator/assignee/reward/approval/recurrence authority. Existing source facts remain in owned preview rows, never a second Notes store.','UTF8/file20MiB/10000 rows/depth5; default destination and up to100 source-list overrides, original list revisions; at most3 pending previews and100MiB retained normalized source per actor, each normalized batch at most50MiB. Preview expires24h without changing Tasks.','Shared job processes50-row transactions, yielding/resuming with one UUID mapping. Actual101 Task interruption/resume and real HTTP20MiB/shared registry are tested. Full10000 Task commit or100k-history performance is not claimed.','Undo fingerprints Task and independent FK references, excludes derived search/import provenance and checks live children. Changed children keep their ancestors. New template references retain an otherwise unchanged Task. Active jobs cannot be raced; an unknown stopped job may be explicitly undone and old payload is fenced. Replacement snapshot retires queued import work for review, without automatic replay.'],'retainedEvidence':retained,'remaining':['Final mandatory Windows Node22/24/three browsers, all parent suites, ZIP/service/performance and explicit pilot acceptance for the composed feature group. New seven feature harnesses not yet wired into mandatory Windows.','P14–P18, remaining Wallet/W18/M1/I02/I03 remain open; aggregate snapshot capacity and110k Task benchmarks unresolved.','No new PR/Actions run for this group. Actual Server2019 R02 separate/unrun. Release/tag/VPS/PC runner not performed.']}
(root/'docs/engineering/evidence/p13-data-development.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
(root/'docs/engineering/productivity-data-tools.md').write_text('''# P13 owned Task import and export

Production19787cb and fixture-only40031f7 add explicit pilot18. Default6,
frozen1–17 SQL/checksums and Windows package capability13 stay unchanged.
This is Cloud development evidence; no new-source Windows acceptance is claimed.

The Task data workspace accepts JSON/CSV/ICS files up to20MiB and10,000 rows.
It validates UTF8, title/body, typed dates/timeboxes, source list mapping and trees
up to5 levels. Preview/mapping do not write Tasks. Files and previews belong to
the authenticated actor/role. Original source facts remain opaque; import creates
fresh private unfinished Tasks and checklist IDs without executing old creator,
assignee, rewards, approvals or recurrence. Invalid rows give a logical row
number without echoing private source text. Existing Notes stay canonical.

A default list and up to100 source-list overrides carry reviewed revisions.
Current create/list authority is checked before cached mapping/commit receipts
and inside I01. A real mapping replay regression caught the original omission.
The provider retains the original Blob/revision/key through unknown ACK and view
navigation, retires revoked targets and clears private state on logout, including
late error feedback. Commit/undo use existing in-app review/confirmation.

The shared AppJobs registry owns durable processing; each command writes at most
50 Tasks, yields and resumes with the same fresh UUID/parent mapping. Actual101
Task interruption/resume, whole-batch rollback, real HTTP20MiB and registry-driven
commit/undo are tested. No second scheduler/writer is introduced. Failed/unknown
work requires review; explicit undo cannot race a live pending/leased job. Shared
snapshot18 preserves source/mapping/progress and retires queued work for review,
without automatic replay of Tasks, points or notifications.

Conditional undo compares the Task and independent FK references and checks live
children. Changed children retain their ancestors; a new template link retains
an otherwise unchanged Task. Only unchanged independent items are soft-deleted.
The preview quota is3 pending batches/100MiB retained normalized source per actor,
50MiB per normalized batch. Uncommitted preview rows expire after24h; metadata
remains and existing Tasks are not changed. Larger retention/capacity is W18.

JSON exports selected canonical Task fields/checklist and legacy history exactly;
use the full shared backup for attachment bytes and installation recovery. CSV
exports draft fields with explicit reversible spreadsheet escaping. Ordinary CSV
imports never guess that a leading apostrophe should be removed. ICS exports
calendar dates/text; unsupported source recurrence is kept with a warning rather
than activated or approximated. Exports use current SQL ACL before bodies and
recheck selected revisions/scope during streaming. No public credentials, bank
integration, external importer/provider calls or new dependencies are added.

Full8749tests549files/matchingJUnit,0failed-skipped-todo at40031f7; all8675 parent
cases plus74 retained. Lint/build0. Build19787cb is unchanged by the cancel-label
fixture follow-up. Same-build first-attempt Chromium25/25: data4/attachments3/
content4/templates3/notifications4/collaboration3/calendar4, owned18/17/16/15/14/
13/13, offline providers, normal stop/integrity/closed handles/cleanup. Both390px
visible import forms/previews were inspected; the element screenshots extend
past the app scroll viewport. Desktop journeys exercise download controls.

[Proof and retained failures](evidence/p13-data-development.json). The first
browser failure was an incorrect new fixture cancel label; its leftover preview
correctly exercised the3-pending quota later. Quotas/assertions/timeouts/retries
were preserved. Author review only. All P13 slices are usable in Cloud; final
composed Windows/pilot acceptance and remaining master tasks stay open. No full
10000-Task import/performance claim, release, tag, VPS or Server2019 acceptance.
''')
with(root/'docs/engineering/implementation-status.md').open('a')as file:file.write('''\n\n### P13 Task data tools Cloud checkpoint (2026-10-18)\n\n- Backend0818db29796cbf3d2569dd9d04cebfe3eeb066d7, production19787cb and fixture follow-up40031f7e53eef4c9568a58948b71577459da8225; source PR URL/CI run URL not created for this feature-first group. Explicit pilot18/default6/frozen1–17/packagecaps13 retained. Owned20MiB/10k JSON/CSV/ICS preview/list mapping, reviewed commit/conditionalundo via shared50-row jobs and read-only authorized exports are usable in the Task workspace. Original history/creator/reward/approval/recurrence facts are retained as opaque source, not executed; no second Notes store/dependency.\n- Full8749tests549files/matchingJUnit/0failed-skipped-todo; all8675 parents+74 retained. Lint/build0, same-build Chromium25/25 firstattempts with all seven feature fixtures/offline/normalstop/integrity/closed/cleaned. Both390visible import forms/previews inspected. Actual cached-map ACL and missing-row-feedback regressions retained/fixed; first browser cancel-label fixture failure and consequent quota refusal retained, no assertions/quotas/timeouts/retries relaxed. [Evidence](evidence/p13-data-development.json).\n- Next P14 Focus/Pomodoro, then P15–P18/remainingWallet/W18/M1/I02/I03. All P13 slices are Cloud-functional, final composed Windows/pilot acceptance still pending; new seven harnesses not yet mandatoryCI. No10000-Task commit or110kTask performance qualification, source PR/Windows/package/service claim, release/tag/VPS/PC runner. R02 Server2019 separate/unrun.\n''')
print('Validated8749full/25browser; retained',len(retained),'artifacts')
